package com.amin1fighter.coffeeroast
import android.app.*
import android.Manifest
import android.content.pm.PackageManager
import android.app.NotificationChannel
import android.app.NotificationManager
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.content.*
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.*
import android.view.*
import android.widget.*
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.roundToInt
import kotlin.math.abs

class MainActivity:AppCompatActivity(){
 private lateinit var root:FrameLayout;private val h=Handler(Looper.getMainLooper());private var ticker:Runnable?=null
 private var current:RoastSession?=null;private var startElapsed=0L;private var editingTimer:TextView?=null;private var chart:RoastChartView?=null
 override fun onCreate(b:Bundle?){super.onCreate(b);Storage.init(this);installCrashLogger();applyTheme();createNotificationChannel();if(Build.VERSION.SDK_INT>=33&&ContextCompat.checkSelfPermission(this,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS),77);root=FrameLayout(this);ViewCompat.setOnApplyWindowInsetsListener(root){v,insets->val b=insets.getInsets(WindowInsetsCompat.Type.systemBars());v.setPadding(b.left,b.top,b.right,b.bottom);insets};setContentView(root);showHome();recoverLive()}
 override fun onPause(){super.onPause();stopTicker();current?.let{if(!it.isComplete){Storage.save();showRoastNotification(it)}}}
 override fun onResume(){super.onResume();cancelRoastNotification();current?.let{if(!it.isComplete&&root.childCount>0&&editingTimer!=null)startTicker(it)}}
 override fun onDestroy(){stopTicker();super.onDestroy()}
 private fun dp(x:Int)= (x*resources.displayMetrics.density).roundToInt()
 private fun screen(title:String):LinearLayout{root.removeAllViews();editingTimer=null;val sv=ScrollView(this);val ll=LinearLayout(this);ll.orientation=LinearLayout.VERTICAL;ll.setPadding(dp(16),dp(18),dp(16),dp(30));sv.addView(ll);root.addView(sv);ll.addView(tv(title,24f,true));return ll}
 private fun tv(s:String,size:Float=16f,bold:Boolean=false)=TextView(this).apply{text=s;textSize=size;setTypeface(null,if(bold)1 else 0);setPadding(0,dp(6),0,dp(6))}
 private fun sub(s:String)=tv(s,14f,false)
 private fun btn(s:String,f:()->Unit)=Button(this).apply{text=s;setAllCaps(false);setOnClickListener{f()};layoutParams=LinearLayout.LayoutParams(-1,dp(52)).apply{topMargin=dp(7)}}
 private fun input(hint:String,type:Int=1)=EditText(this).apply{this.hint=hint;inputType=type;layoutParams=LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(4)}}
 private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
 private fun showHome(){stopTicker();val l=screen("☕ COFFEE ROAST LAB");l.addView(sub("Roast • Analyze • Cup • Manage"));l.addView(btn("Roasts"){showRoasts()});l.addView(btn("Green Beans"){showBeans()});l.addView(btn("Roasted Inventory / Resting"){showInventory()});l.addView(btn("Dashboard / Statistics"){showDashboard()});l.addView(btn("Tools & Calculators"){showTools()});l.addView(btn("Settings"){showSettings()});l.addView(btn("Backup / Restore"){showBackup()});l.addView(btn("Import legacy roast"){legacyDialog()})}
 private fun showBeans(){val l=screen("Green Beans");Storage.beans.forEach{b->val box=LinearLayout(this);box.orientation=LinearLayout.VERTICAL;box.setPadding(dp(10),dp(8),dp(10),dp(8));box.addView(tv(b.name,18f,true));box.addView(sub("${b.origin.ifBlank{"—"}} • ${b.process.ifBlank{"—"}} • ${fmt(b.stockGrams)} g"));box.addView(sub("${b.variety.ifBlank{"variety —"}} • ${b.supplier.ifBlank{"supplier —"}} • ${b.altitudeMasl?.let{"${it.toInt()} masl"}?: "altitude —"}"));box.addView(btn("Edit / Delete"){beanDialog(b)});l.addView(box)};l.addView(btn("+ Add bean"){beanDialog(null)});l.addView(btn("Back"){showHome()})}
 private fun beanDialog(old:GreenBean?){val c=LinearLayout(this);c.orientation=LinearLayout.VERTICAL;val fields=listOf("Name","Origin","Process","Notes","Supplier","Purchase date","Price","Harvest year","Altitude masl","Variety","Storage location","Stock grams");val es=fields.map{input(it,if(it in listOf("Price","Altitude masl","Stock grams"))3 else 1)};es.forEach{c.addView(it)};old?.let{listOf(it.name,it.origin,it.process,it.notes,it.supplier,it.purchaseDate,it.price.toString(),it.harvestYear,it.altitudeMasl?.toString()?: "",it.variety,it.storageLocation,it.stockGrams.toString()).zip(es).forEach{(v,e)->e.setText(v)}};val scroll=ScrollView(this).apply{addView(c)};AlertDialog.Builder(this).setTitle(if(old==null)"Add bean" else "Edit bean").setView(scroll).setPositiveButton("Save"){_,_->val name=es[0].text.toString().trim();if(name.isEmpty()){toast("Name required");return@setPositiveButton};val b=old?:GreenBean(Storage.newBeanId(),name);b.name=name;b.origin=es[1].text.toString();b.process=es[2].text.toString();b.notes=es[3].text.toString();b.supplier=es[4].text.toString();b.purchaseDate=es[5].text.toString();b.price=es[6].text.toString().toDoubleOrNull()?:0.0;b.harvestYear=es[7].text.toString();b.altitudeMasl=es[8].text.toString().toDoubleOrNull();b.variety=es[9].text.toString();b.storageLocation=es[10].text.toString();b.stockGrams=es[11].text.toString().toDoubleOrNull()?:0.0;if(old==null)Storage.addBean(b) else Storage.save();showBeans()}.setNegativeButton("Cancel",null).apply{if(old!=null)setNeutralButton("Delete"){_,_->Storage.deleteBean(old.id);showBeans()}}.show()}
 private fun showRoasts(){val l=screen("Roasts");Storage.roasts.sortedByDescending{it.globalRoastNumber}.forEach{r->val b=Storage.beanById(r.beanId);val loss=r.roastedWeightG?.let{x->RoastMath.weightLossPercent(r.greenWeightG,x)};l.addView(btn("#${r.globalRoastNumber} ${b?.name?: "?"} • batch ${r.beanBatchNumber} • ${if(r.isComplete)"complete" else "LIVE"} • loss ${loss?.let{"%.1f%%".format(it)}?: "—"}"){current=r;if(r.isComplete)showSummary(r) else showLive(r)})};l.addView(btn("+ Start roast"){if(Storage.beans.isEmpty())showBeans() else setupRoast()});l.addView(btn("Back"){showHome()})}
 private fun setupRoast(){
  val l=screen("New Roast")
  val beans=Storage.beans.toList()
  if(beans.isEmpty()){toast("Add a green bean first");showBeans();return}
  val sp=Spinner(this)
  sp.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,beans.map{"${it.name} (${fmt(it.stockGrams)}g)"})
  l.addView(sub("Bean"));l.addView(sp)
  val g=input("Green weight g",3);val d=input("Density g/L optional",3)
  val fan=input("Start fan",3);val heat=input("Start heater",3);val charge=input("Charge BT °C",3);val roaster=input("Roaster / machine name",1)
  l.addView(g);l.addView(d);l.addView(fan);l.addView(heat);l.addView(charge);l.addView(roaster)
  l.addView(btn("START ROAST"){
   try {
    val b=beans.getOrNull(sp.selectedItemPosition) ?: run { toast("Select a bean");return@btn }
    val gw=g.text.toString().trim().replace(',','.').toDoubleOrNull() ?: 0.0
    if(gw<=0){toast("Green weight must be greater than 0");return@btn}
    if(gw>b.stockGrams+0.0001){toast("Not enough green stock");return@btn}
    val cb=charge.text.toString().trim().replace(',','.').toDoubleOrNull()
    if(cb!=null && (cb<0.0 || cb>300.0)){toast("Charge BT must be 0–300°C");return@btn}
    val r=RoastSession(Storage.newRoastId(),Storage.allocateGlobalRoastNumber(),b.id,Storage.nextBatch(b),gw,
      densityGPerL=d.text.toString().trim().replace(',','.').toDoubleOrNull(),
      startFan=fan.text.toString().toIntOrNull()?:0,startHeater=heat.text.toString().toIntOrNull()?:0,
      startTimeMillis=System.currentTimeMillis(),roasterName=roaster.text.toString().trim())
    if(cb!=null) r.tempLog.add(TempPoint(0,cb,null))
    b.stockGrams-=gw;b.totalBatches+=1
    Storage.addRoast(r)
    current=r
    showLive(r)
   } catch(e:Exception){
    toast("Could not start roast: ${e.message ?: "unknown error"}")
    File(filesDir,"coffeeroast_crash.log").writeText(e.stackTraceToString())
   }
  })
  l.addView(btn("Back"){showRoasts()})
 }
 private fun recoverLive(){val r=Storage.roasts.firstOrNull{!it.isComplete};if(r!=null){current=r}}
 private fun elapsed(r:RoastSession)=if(r.startTimeMillis>0)((System.currentTimeMillis()-r.startTimeMillis)/1000).toInt() else r.tempLog.maxOfOrNull{it.elapsedSec}?:0
 private fun startTicker(r:RoastSession,refresh:()->Unit={}){stopTicker();startElapsed=SystemClock.elapsedRealtime()-elapsed(r)*1000;val run=object:Runnable{override fun run(){val sec=((SystemClock.elapsedRealtime()-startElapsed)/1000).toInt();editingTimer?.text=fmtTime(sec);refresh();ticker=this;h.postDelayed(this,1000)}};ticker=run;h.post(run)}
 private fun stopTicker(){ticker?.let{h.removeCallbacks(it)};ticker=null}
 private fun showLive(r:RoastSession){
  stopTicker()
  getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
  val l=screen("LIVE ROAST #${r.globalRoastNumber}")
  editingTimer=tv(fmtTime(elapsed(r)),34f,true);l.addView(editingTimer)
  val b=Storage.beanById(r.beanId)
  l.addView(sub("${b?.name?:"?"} • ${r.roasterName.ifBlank{"roaster —"}} • Temperature log every ${Storage.settings.logIntervalSec}s"))

  val live=tv("",20f,true);l.addView(live)
  val chartView=RoastChartView(this).apply{session=r}
  chartView.layoutParams=LinearLayout.LayoutParams(-1,dp(360))
  l.addView(chartView)

  val logTitle=tv("Temperature log — edit any past 30-second point",17f,true)
  l.addView(logTitle)
  val logContainer=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
  l.addView(logContainer)

  fun redrawLog(){
    logContainer.removeAllViews()
    val now=elapsed(r)
    val interval=Storage.settings.logIntervalSec.coerceIn(5,300)
    val maxSlot=(now/interval)*interval
    val existing=r.tempLog.associateBy{it.elapsedSec}
    var sec=0
    while(sec<=maxSlot){
      addTempRow(logContainer,r,sec,existing[sec],chartView){redrawLog()}
      sec+=interval
    }
    val custom=r.tempLog.filter{it.elapsedSec>maxSlot}.sortedBy{it.elapsedSec}
    custom.forEach{p->addTempRow(logContainer,r,p.elapsedSec,p,chartView){redrawLog()}}
    if(maxSlot<now || r.tempLog.none{it.elapsedSec==now}){
      l // keep closure alive
    }
  }

  var lastRenderedSlot=-1
  fun refresh(){
    val last=r.tempLog.maxByOrNull{it.elapsedSec}
    val now=elapsed(r)
    val rr=RoastMath.stableRor(r.tempLog,60)
    val btNow=last?.bt
    val etaDE=btNow?.let{RoastMath.etaToTempSec(now,it,rr,Storage.settings.dryEndTargetC)}
    val etaFC=btNow?.let{RoastMath.etaToTempSec(now,it,rr,Storage.settings.firstCrackTargetC)}
    val etaDrop=btNow?.let{RoastMath.etaToTempSec(now,it,rr,Storage.settings.dropTargetC)}
    live.text="BT ${btNow?.let{temp(it)}?:"—"}    ET ${last?.et?.let{temp(it)}?:"—"}\n"+
      "RoR ${rr?.let{"%.2f".format(it)}?:"—"} °C/min"+
      "${if(rr!=null&&rr<Storage.settings.lowRorWarning)"   ⚠ LOW RoR" else ""}\n"+
      "DE ETA ${etaDE?.let{fmtTime(it)}?:"—"}   FC ETA ${etaFC?.let{fmtTime(it)}?:"—"}   DROP ETA ${etaDrop?.let{fmtTime(it)}?:"—"}"
    chartView.invalidate()
    editingTimer?.text=fmtTime(now)
    val slot=(now/Storage.settings.logIntervalSec.coerceIn(5,300))*Storage.settings.logIntervalSec.coerceIn(5,300)
    if(slot!=lastRenderedSlot){lastRenderedSlot=slot;redrawLog()}
  }

  l.addView(btn("Add / edit current temperature"){sampleDialog(r){redrawLog();refresh()}})
  l.addView(btn("Turning Point"){r.turningPointSec=elapsed(r);Storage.save();haptic();refresh()})
  l.addView(btn("DRY END"){r.dryEndSec=elapsed(r);Storage.save();haptic();refresh()})
  l.addView(btn("FIRST CRACK"){r.firstCrackSec=elapsed(r);Storage.save();haptic();refresh()})
  l.addView(btn("Fan / Heater change"){changeDialog(r){redrawLog();refresh()}})
  l.addView(btn("Roast notes"){notesDialog(r)})
  l.addView(btn("END ROAST / DROP"){r.dropSec=elapsed(r);r.isComplete=true;r.roastedRemainingG=r.roastedWeightG;Storage.save();stopTicker();getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);showSummary(r)})
  l.addView(btn("Back to home (roast continues)"){showHome()})
  refresh()
  startTicker(r,::refresh)
 }

 private fun addTempRow(container:LinearLayout,r:RoastSession,sec:Int,p:TempPoint?,chart:RoastChartView,onSaved:()->Unit){
  val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
  val time=tv(fmtTime(sec),16f,true);time.layoutParams=LinearLayout.LayoutParams(dp(62),-2)
  val bt=input("BT",3);bt.setText(p?.bt?.toString()?:"")
  val et=input("ET",3);et.setText(p?.et?.toString()?:"")
  bt.layoutParams=LinearLayout.LayoutParams(0,dp(52),1f);et.layoutParams=LinearLayout.LayoutParams(0,dp(52),1f)
  val save=btn("Save"){
    val bv=bt.text.toString().trim().replace(",",".").toDoubleOrNull()
    val ev=et.text.toString().trim().replace(",",".").toDoubleOrNull()
    if(bv==null){toast("BT is required for ${fmtTime(sec)}");return@btn}
    if(bv !in 0.0..300.0 || (ev!=null && ev !in 0.0..300.0)){toast("Temperature must be 0–300°C");return@btn}
    r.tempLog.removeAll{it.elapsedSec==sec}
    r.tempLog.add(TempPoint(sec,bv,ev));r.tempLog.sortBy{it.elapsedSec};Storage.save();chart.invalidate();onSaved()
  }
  save.layoutParams=LinearLayout.LayoutParams(dp(62),dp(52))
  row.addView(time);row.addView(bt);row.addView(et);row.addView(save);container.addView(row)
 }

 private fun sampleDialog(r:RoastSession,onSaved:()->Unit){
  val c=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
  val bt=input("BT °C",3);val et=input("ET °C optional",3);val t=input("Elapsed mm:ss",1)
  t.setText(fmtTime(elapsed(r)))
  c.addView(bt);c.addView(et);c.addView(t)
  AlertDialog.Builder(this).setTitle("Add / edit temperature").setView(c).setPositiveButton("Save"){_,_->
    val sec=RoastMath.parseTime(t.text.toString())?:return@setPositiveButton
    val v=bt.text.toString().trim().replace(",",".").toDoubleOrNull()
    val e=et.text.toString().trim().replace(",",".").toDoubleOrNull()
    if(v==null||v !in 0.0..300.0||(e!=null&&e !in 0.0..300.0)){toast("Invalid temperature");return@setPositiveButton}
    r.tempLog.removeAll{it.elapsedSec==sec};r.tempLog.add(TempPoint(sec,v,e));r.tempLog.sortBy{it.elapsedSec};Storage.save();onSaved()
  }.setNegativeButton("Cancel",null).show()
 }

 private fun changeDialog(r:RoastSession,onSaved:()->Unit){
  val c=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
  val type=Spinner(this);type.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,arrayOf("Fan","Heater"))
  val level=input("Level",2);val time=input("Elapsed mm:ss",1);time.setText(fmtTime(elapsed(r)))
  c.addView(sub("Change is recorded separately and plotted on the roast graph"));c.addView(type);c.addView(level);c.addView(time)
  AlertDialog.Builder(this).setTitle("Fan / Heater change").setView(c).setPositiveButton("Save"){_,_->
    val sec=RoastMath.parseTime(time.text.toString())?:return@setPositiveButton
    val bt=r.tempLog.minByOrNull{abs(it.elapsedSec-sec)}?.bt?:0.0
    val lv=level.text.toString().trim().toIntOrNull()
    if(lv==null){toast("Level must be a number");return@setPositiveButton}
    val q=SettingChange(sec,bt,lv)
    if(type.selectedItemPosition==0)r.fanChanges.add(q)else r.heaterChanges.add(q)
    Storage.save();onSaved()
  }.setNegativeButton("Cancel",null).show()
 }

 private fun notesDialog(r:RoastSession){val e=input("Roast notes",1);e.setText(r.notes);AlertDialog.Builder(this).setTitle("Notes").setView(e).setPositiveButton("Save"){_,_->r.notes=e.text.toString();Storage.save()}.setNegativeButton("Cancel",null).show()}
 private fun showSummary(r:RoastSession){stopTicker();getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);val l=screen("Roast #${r.globalRoastNumber} Summary");val b=Storage.beanById(r.beanId);l.addView(sub("${b?.name?: "?"} • ${date(r.startTimeMillis)}"));val w=input("Roasted weight g",3);w.setText(r.roastedWeightG?.toString()?: "");l.addView(w);val ref=Spinner(this);ref.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf("No reference")+Storage.roasts.filter{it.id!=r.id&&it.beanId==r.beanId}.map{"#${it.globalRoastNumber}"});l.addView(sub("Reference curve"));l.addView(ref);l.addView(btn("Save weight / reference"){r.roastedWeightG=w.text.toString().toDoubleOrNull();r.roastedRemainingG=r.roastedWeightG;val rr=Storage.roasts.filter{it.id!=r.id&&it.beanId==r.beanId};if(ref.selectedItemPosition>0)r.referenceRoastId=rr.getOrNull(ref.selectedItemPosition-1)?.id;Storage.save();showSummary(r)});val loss=r.roastedWeightG?.let{RoastMath.weightLossPercent(r.greenWeightG,it)};val dtr=RoastMath.dtr(0,r.firstCrackSec,r.dropSec);val ph=RoastMath.phasePercents(r.turningPointSec?:0,r.dryEndSec,r.firstCrackSec,r.dropSec);l.addView(tv("Weight loss: ${loss?.let{"%.2f%%".format(it)}?: "—"}   DTR: ${dtr?.let{"%.1f%%".format(it)}?: "—"}",19f,true));l.addView(sub("Dry ${ph.first?.let{"%.1f%%".format(it)}?: "—"} • Maillard ${ph.second?.let{"%.1f%%".format(it)}?: "—"} • Development ${ph.third?.let{"%.1f%%".format(it)}?: "—"}"));l.addView(btn("Cupping / tasting score"){tastingDialog(r)});l.addView(btn("Roasted inventory / rest"){restDialog(r)});chart=RoastChartView(this);chart!!.layoutParams=LinearLayout.LayoutParams(-1,dp(430));chart!!.session=r;chart!!.references=(r.referenceRoastId?.let{id->listOfNotNull(Storage.roasts.firstOrNull{it.id==id})}?:Storage.roasts.filter{it.id!=r.id&&it.beanId==r.beanId}.sortedByDescending{it.startTimeMillis}.take(3));l.addView(chart);
 l.addView(btn("Chart smoothing (1 / 3 / 5 samples)"){chart!!.smoothing=when(chart!!.smoothing){1->3;3->5;else->1};chart!!.invalidate();toast("Smoothing: ${chart!!.smoothing}")});l.addView(btn("Overlay: choose reference"){chooseReference(r)});l.addView(btn("Export Artisan TSV"){exportArtisan(r)});l.addView(btn("Export CSV"){exportCsv(r)});l.addView(btn("PDF report"){exportPdf(r)});l.addView(btn("Delete roast"){AlertDialog.Builder(this).setMessage("Delete this roast? Green stock will not be restored automatically.").setPositiveButton("Delete"){_,_->Storage.deleteRoast(r.id);showRoasts()}.setNegativeButton("Cancel",null).show()});l.addView(btn("Back"){showRoasts()})}
 private fun chooseReference(r:RoastSession){val xs=Storage.roasts.filter{it.id!=r.id&&it.beanId==r.beanId};val names=xs.map{"#${it.globalRoastNumber}"};AlertDialog.Builder(this).setTitle("Reference").setItems(arrayOf("None")+names.toTypedArray()){_,i->r.referenceRoastId=if(i==0)null else xs[i-1].id;Storage.save();showSummary(r)}.show()}
 private fun tastingDialog(r:RoastSession){val t=r.tasting?:TastingScore();val c=LinearLayout(this);c.orientation=LinearLayout.VERTICAL;val labels=listOf("Fragrance","Flavor","Aftertaste","Acidity","Body","Balance","Sweetness","Clean Cup","Uniformity","Overall");val vals=listOf(t.fragrance,t.flavor,t.aftertaste,t.acidity,t.body,t.balance,t.sweetness,t.cleanCup,t.uniformity,t.overall);val es=labels.mapIndexed{i,n->input("$n (6-10)",3).apply{setText(if(vals[i]==0.0)"" else vals[i].toString());c.addView(this)}};val notes=input("Tasting notes",1);notes.setText(t.notes);c.addView(notes);AlertDialog.Builder(this).setTitle("Cupping / tasting score").setView(c).setPositiveButton("Save"){_,_->val a=es.map{it.text.toString().toDoubleOrNull()?:0.0};r.tasting=TastingScore(a[0],a[1],a[2],a[3],a[4],a[5],a[6],a[7],a[8],a[9],notes.text.toString());Storage.save();toast("Score ${"%.1f".format(r.tasting!!.total())}/100")}.setNegativeButton("Cancel",null).show()}
 private fun restDialog(r:RoastSession){val c=input("Rest days",2);c.setText(r.restingDays.toString());AlertDialog.Builder(this).setTitle("Resting inventory").setView(c).setPositiveButton("Save"){_,_->r.restingDays=c.text.toString().toIntOrNull()?:7;r.roastedRemainingG=r.roastedWeightG;Storage.save();showSummary(r)}.setNegativeButton("Cancel",null).show()}

 private fun showInventory(){val l=screen("Roasted Inventory");Storage.roasts.filter{it.isComplete&&it.roastedWeightG!=null}.sortedByDescending{it.startTimeMillis}.forEach{r->val b=Storage.beanById(r.beanId);val age=((System.currentTimeMillis()-r.startTimeMillis)/86400000L).toInt();val ready=age>=r.restingDays;val rem=r.roastedRemainingG?:r.roastedWeightG?:0.0;l.addView(sub("#${r.globalRoastNumber} ${b?.name?: "?"} • ${fmt(rem)}g remaining • ${if(ready)"READY / peak window" else "$age/${r.restingDays} days resting"}"))};l.addView(btn("Back"){showHome()})}
 private fun showDashboard(){val l=screen("Dashboard");val complete=Storage.roasts.filter{it.isComplete};val losses=complete.mapNotNull{r->r.roastedWeightG?.let{x->RoastMath.weightLossPercent(r.greenWeightG,x)}};val dtrs=complete.mapNotNull{RoastMath.dtr(0,it.firstCrackSec,it.dropSec)};l.addView(tv("Roasts: ${complete.size}",20f,true));l.addView(sub("Average weight loss: ${losses.averageOrNull()?.let{"%.2f%%".format(it)}?: "—"}"));l.addView(sub("Average DTR: ${dtrs.averageOrNull()?.let{"%.2f%%".format(it)}?: "—"}"));val scored=complete.filter{it.tasting!=null};l.addView(sub("Cupped roasts: ${scored.size} • average score: ${scored.map{it.tasting!!.total()}.averageOrNull()?.let{"%.1f".format(it)}?: "—"}"));Storage.beans.forEach{b->val n=complete.count{it.beanId==b.id};l.addView(sub("${b.name}: $n roasts • ${fmt(b.stockGrams)}g green stock"))};l.addView(btn("Export dashboard CSV"){exportDashboardCsv()});l.addView(btn("Back"){showHome()})}
 private fun showTools(){val l=screen("Tools & Calculators");l.addView(btn("Green weight for target roasted"){calcDialog("Target roasted g","Expected loss %"){g,loss->if(loss<100)toast("Green needed: ${"%.1f".format(g/(1-loss/100))} g")}});l.addView(btn("Brew ratio calculator"){calcDialog2()});l.addView(btn("Independent stopwatch"){stopwatch()});l.addView(btn("Unit converter"){unitConverter()});l.addView(btn("Charge temperature heuristic"){chargeCalculator()});l.addView(btn("Blend builder"){blendDialog()});l.addView(btn("Back"){showHome()})}
 private fun calcDialog(a:String,b:String,done:(Double,Double)->Unit){val c=LinearLayout(this);c.orientation=LinearLayout.VERTICAL;val x=input(a,3);val y=input(b,3);c.addView(x);c.addView(y);AlertDialog.Builder(this).setTitle("Calculator").setView(c).setPositiveButton("Calculate"){_,_->done(x.text.toString().toDoubleOrNull()?:0.0,y.text.toString().toDoubleOrNull()?:0.0)}.setNegativeButton("Cancel",null).show()}
 private fun unitConverter(){
  val c=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
  val g=input("grams",3); val oz=input("ounces",3)
  c.addView(g); c.addView(oz)
  AlertDialog.Builder(this).setTitle("g ↔ oz").setView(c).setPositiveButton("Convert"){_,_->
   val gv=g.text.toString().toDoubleOrNull(); val ov=oz.text.toString().toDoubleOrNull()
   if(gv!=null) toast("${gv} g = ${"%.2f".format(gv/28.3495)} oz")
   else if(ov!=null) toast("${ov} oz = ${"%.1f".format(ov*28.3495)} g")
   else toast("Enter grams or ounces")
  }.setNegativeButton("Cancel",null).show()
 }
 private fun chargeCalculator(){
  val c=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
  val weight=input("Batch weight g",3); val density=input("Density g/L",3); val base=input("Base charge °C",3)
  c.addView(weight); c.addView(density); c.addView(base)
  AlertDialog.Builder(this).setTitle("Charge temperature heuristic").setMessage("Heuristic only; calibrate against your own roaster and bean.").setView(c).setPositiveButton("Calculate"){_,_->
   val w=weight.text.toString().toDoubleOrNull() ?: 0.0
   val d=density.text.toString().toDoubleOrNull() ?: 700.0
   val b=base.text.toString().toDoubleOrNull() ?: 200.0
   val suggested=b+(d-700.0)*0.02-(w-250.0)*0.03
   toast("Suggested starting point: ${"%.0f".format(suggested)}°C")
  }.setNegativeButton("Cancel",null).show()
 }
 private fun calcDialog2(){
  val c=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
  val cups=input("Cups",2); val dose=input("g per cup",3); val ratio=input("Water ratio 1:x",3)
  c.addView(cups); c.addView(dose); c.addView(ratio)
  AlertDialog.Builder(this).setTitle("Brew calculator").setView(c).setPositiveButton("Calculate"){_,_->
   val cupsValue=cups.text.toString().toDoubleOrNull() ?: 0.0
   val doseValue=dose.text.toString().toDoubleOrNull() ?: 0.0
   val ratioValue=ratio.text.toString().toDoubleOrNull() ?: 16.0
   val coffee=cupsValue*doseValue
   toast("${"%.1f".format(coffee)}g coffee • ${"%.0f".format(coffee*ratioValue)}g water")
  }.setNegativeButton("Cancel",null).show()
 }
 private fun stopwatch(){val d=AlertDialog.Builder(this);val t=TextView(this);t.textSize=30f;t.gravity=Gravity.CENTER;var s=0;val rr=object:Runnable{override fun run(){t.text=fmtTime(s++);h.postDelayed(this,1000)}};h.post(rr);d.setTitle("Stopwatch").setView(t).setNegativeButton("Close"){_,_->h.removeCallbacks(rr)}.show()}
 private fun blendDialog(){val c=LinearLayout(this);c.orientation=LinearLayout.VERTICAL;val rows=Storage.beans.map{b->val e=input("${b.name} %",3);c.addView(e);b to e};AlertDialog.Builder(this).setTitle("Pre-roast blend builder").setMessage("Enter percentages; total should be 100%.").setView(c).setPositiveButton("Check"){_,_->val sum=rows.sumOf{it.second.text.toString().toDoubleOrNull()?:0.0};toast("Blend total: ${"%.1f".format(sum)}%")}.setNegativeButton("Cancel",null).show()}
 private fun showSettings(){val l=screen("Settings");val unit=Spinner(this);unit.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,arrayOf("°C","°F"));unit.setSelection(if(Storage.settings.temperatureUnit=="F")1 else 0);l.addView(sub("Temperature"));l.addView(unit);val wu=Spinner(this);wu.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,arrayOf("g","oz"));wu.setSelection(if(Storage.settings.weightUnit=="oz")1 else 0);l.addView(sub("Weight"));l.addView(wu);val interval=input("Logging interval seconds",2);interval.setText(Storage.settings.logIntervalSec.toString());val de=input("Dry end target °C",3);de.setText(Storage.settings.dryEndTargetC.toString());val fc=input("First crack target °C",3);fc.setText(Storage.settings.firstCrackTargetC.toString());val ror=input("Low RoR warning °C/min",3);ror.setText(Storage.settings.lowRorWarning.toString());val drop=input("Estimated drop target °C",3);drop.setText(Storage.settings.dropTargetC.toString());val rest=input("Default rest days",2);rest.setText(Storage.settings.defaultRestDays.toString());val theme=Spinner(this);theme.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,arrayOf("System","Light","Dark"));theme.setSelection(when(Storage.settings.theme){"dark"->2;"light"->1;else->0});l.addView(interval);l.addView(de);l.addView(fc);l.addView(ror);l.addView(drop);l.addView(rest);l.addView(sub("Theme"));l.addView(theme);l.addView(btn("Save settings"){Storage.settings.temperatureUnit=if(unit.selectedItemPosition==1)"F" else "C";Storage.settings.weightUnit=if(wu.selectedItemPosition==1)"oz" else "g";Storage.settings.logIntervalSec=(interval.text.toString().toIntOrNull()?:30).coerceIn(1,600);Storage.settings.dryEndTargetC=de.text.toString().toDoubleOrNull()?:150.0;Storage.settings.firstCrackTargetC=fc.text.toString().toDoubleOrNull()?:200.0;Storage.settings.lowRorWarning=ror.text.toString().toDoubleOrNull()?:10.0;Storage.settings.dropTargetC=drop.text.toString().toDoubleOrNull()?:205.0;Storage.settings.defaultRestDays=rest.text.toString().toIntOrNull()?:7;Storage.settings.theme=when(theme.selectedItemPosition){1->"light";2->"dark";else->"system"};Storage.save()
 AppCompatDelegate.setDefaultNightMode(when(Storage.settings.theme){"dark"->AppCompatDelegate.MODE_NIGHT_YES;"light"->AppCompatDelegate.MODE_NIGHT_NO;else->AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM});toast("Saved");showHome()});l.addView(btn("Back"){showHome()})}
 private fun installCrashLogger(){Thread.setDefaultUncaughtExceptionHandler{_,e->try{File(filesDir,"coffeeroast_crash.log").writeText(e.stackTraceToString())}catch(_:Exception){};android.os.Process.killProcess(android.os.Process.myPid())}}
 private fun applyTheme(){AppCompatDelegate.setDefaultNightMode(when(Storage.settings.theme){"dark"->AppCompatDelegate.MODE_NIGHT_YES;"light"->AppCompatDelegate.MODE_NIGHT_NO;else->AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM})}
 private fun createNotificationChannel(){if(Build.VERSION.SDK_INT>=26)getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("roast_live","Live Roast",NotificationManager.IMPORTANCE_LOW))}
 private fun showRoastNotification(r:RoastSession){if(Build.VERSION.SDK_INT>=33&&ContextCompat.checkSelfPermission(this,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return;val i=Intent(this,MainActivity::class.java).apply{flags=Intent.FLAG_ACTIVITY_SINGLE_TOP};val pi=PendingIntent.getActivity(this,1,i,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE);val sec=elapsed(r);getSystemService(NotificationManager::class.java).notify(42,NotificationCompat.Builder(this,"roast_live").setSmallIcon(android.R.drawable.ic_popup_sync).setContentTitle("Coffee Roast #${r.globalRoastNumber}").setContentText("Roast in progress • ${fmtTime(sec)} • tap to return").setOngoing(true).setContentIntent(pi).build())}
 private fun cancelRoastNotification(){getSystemService(NotificationManager::class.java).cancel(42)}
 private fun showBackup(){val l=screen("Backup / Restore");l.addView(sub("Schema ${Storage.SCHEMA}. Backups include all JSON roast data; photos can be added in a future media schema without changing the core format."));l.addView(btn("Create backup ZIP"){val f=File(cacheDir,"CoffeeRoast-backup-${stamp()}.zip");Storage.exportBackup(this,f);share(f,"application/zip")});l.addView(btn("Restore backup ZIP"){startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="application/zip";addCategory(Intent.CATEGORY_OPENABLE)},88)});l.addView(btn("Share crash log"){val f=File(filesDir,"coffeeroast_crash.log");if(f.exists())share(f,"text/plain")else toast("No crash log saved")});l.addView(btn("Export raw JSON"){val f=File(cacheDir,"coffeeroast-${stamp()}.json");f.writeText(Storage.rawJson());share(f,"application/json")});l.addView(btn("Back"){showHome()})}
 override fun onActivityResult(req:Int,res:Int,data:Intent?){super.onActivityResult(req,res,data);if(req==88&&res==RESULT_OK&&data?.data!=null){val u=data.data!!;val f=File(cacheDir,"restore.zip");contentResolver.openInputStream(u)!!.use{input->f.outputStream().use{input.copyTo(it)}};Storage.importBackup(this,f);showHome()}}
 private fun exportArtisan(r:RoastSession){
  val f=File(cacheDir,"artisan_roast_${r.globalRoastNumber}.tsv")
  val events=mapOf(
   r.dryEndSec to "DRY END",
   r.firstCrackSec to "FIRST CRACK",
   r.dropSec to "DROP",
   r.turningPointSec to "TURNING POINT"
  )
  f.writeText(buildString {
   append("time(sec)\tBT\tET\tEvent\n")
   r.tempLog.sortedBy{it.elapsedSec}.forEach { p ->
    val et=p.et?.toString() ?: ""
    val event=events[p.elapsedSec] ?: ""
    append(p.elapsedSec).append('\t').append(p.bt).append('\t').append(et).append('\t').append(event).append('\n')
   }
  })
  share(f,"text/tab-separated-values")
 }
 private fun exportCsv(r:RoastSession){
  val f=File(cacheDir,"roast_${r.globalRoastNumber}.csv")
  val rr=RoastMath.rorSeries(r.tempLog).toMap()
  val dr=RoastMath.deltaRor(r.tempLog).toMap()
  f.writeText(buildString {
   append("time_sec,BT,ET,RoR,DeltaRoR\n")
   r.tempLog.sortedBy{it.elapsedSec}.forEach { p ->
    val et=p.et?.toString() ?: ""
    val ror=rr[p.elapsedSec]?.toString() ?: ""
    val delta=dr[p.elapsedSec]?.toString() ?: ""
    append(p.elapsedSec).append(',').append(p.bt).append(',').append(et).append(',').append(ror).append(',').append(delta).append('\n')
   }
  })
  share(f,"text/csv")
 }
 private fun exportDashboardCsv(){
  val f=File(cacheDir,"coffee_roast_dashboard.csv")
  f.writeText(buildString {
   append("roast,bean,date,green_g,roasted_g,loss_pct,DTR,score\n")
   Storage.roasts.filter{it.isComplete}.forEach { r ->
    val b=Storage.beanById(r.beanId)
    val beanName=(b?.name ?: "").replace("\"","\"\"")
    val roasted=r.roastedWeightG?.toString() ?: ""
    val loss=r.roastedWeightG?.let{RoastMath.weightLossPercent(r.greenWeightG,it)?.toString()} ?: ""
    val dtr=RoastMath.dtr(0,r.firstCrackSec,r.dropSec)?.toString() ?: ""
    val score=r.tasting?.total()?.toString() ?: ""
    append(r.globalRoastNumber).append(',')
      .append('\"').append(beanName).append('\"').append(',')
      .append(date(r.startTimeMillis)).append(',')
      .append(r.greenWeightG).append(',').append(roasted).append(',')
      .append(loss).append(',').append(dtr).append(',').append(score).append('\n')
   }
  })
  share(f,"text/csv")
 }
 private fun exportPdf(r:RoastSession){val f=File(cacheDir,"roast_${r.globalRoastNumber}.pdf");val doc=PdfDocument();val page=doc.startPage(PdfDocument.PageInfo.Builder(595,842,1).create());val c=page.canvas;val p=Paint().apply{textSize=22f;color=Color.BLACK};c.drawText("Coffee Roast Lab — Roast #${r.globalRoastNumber}",35f,45f,p);p.textSize=13f;val b=Storage.beanById(r.beanId);val lines=listOf("Bean: ${b?.name}","Date: ${date(r.startTimeMillis)}","Green: ${r.greenWeightG} g   Roasted: ${r.roastedWeightG?: "—"} g","Weight loss: ${r.roastedWeightG?.let{RoastMath.weightLossPercent(r.greenWeightG,it)?.let{"%.2f%%".format(it)}}?: "—"}","DTR: ${RoastMath.dtr(0,r.firstCrackSec,r.dropSec)?.let{"%.2f%%".format(it)}?: "—"}","TP ${r.turningPointSec?.let{fmtTime(it)}?: "—"}   DE ${r.dryEndSec?.let{fmtTime(it)}?: "—"}   FC ${r.firstCrackSec?.let{fmtTime(it)}?: "—"}   DROP ${r.dropSec?.let{fmtTime(it)}?: "—"}","Cupping score: ${r.tasting?.total()?.let{"%.1f".format(it)}?: "—"}","Notes: ${r.notes}");lines.forEachIndexed{i,s->c.drawText(s,35f,80f+i*25,p)}
 val cv=RoastChartView(this);cv.session=r;cv.layout(25,350,570,780);val bmp=Bitmap.createBitmap(545,430,Bitmap.Config.ARGB_8888);cv.draw(Canvas(bmp));c.drawBitmap(bmp,null,RectF(25f,350f,570f,780f),p);doc.finishPage(page);f.outputStream().use{doc.writeTo(it)};doc.close();share(f,"application/pdf")}
 private fun legacyDialog(){val e=input("Paste legacy roast text",1);e.minLines=10;AlertDialog.Builder(this).setTitle("Legacy import").setView(e).setPositiveButton("Import"){_,_->val lines=e.text.toString().lines();if(lines.isEmpty())return@setPositiveButton;val bean=Storage.beans.firstOrNull()?:run{val b=GreenBean(Storage.newBeanId(),"Imported");Storage.addBean(b);b};val r=RoastSession(Storage.newRoastId(),Storage.allocateGlobalRoastNumber(),bean.id,Storage.nextBatch(bean),0.0,isHistorical=true,startTimeMillis=System.currentTimeMillis());lines.forEach{line->val m=Regex("""(\d+:\d+|\d+)\D+([0-9]+(?:\.[0-9]+)?)""").find(line);if(m!=null){val sec=RoastMath.parseTime(m.groupValues[1])?:0;r.tempLog.add(TempPoint(sec,m.groupValues[2].toDouble()))}};r.isComplete=true;Storage.addRoast(r);showSummary(r)}.setNegativeButton("Cancel",null).show()}
 private fun share(f:File,mime:String){val u=FileProvider.getUriForFile(this,"$packageName.fileprovider",f);startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply{type=mime;putExtra(Intent.EXTRA_STREAM,u);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)},"Share"))}
 private fun haptic(){window.decorView.performHapticFeedback(3)}
 private fun temp(c:Double)=if(Storage.settings.temperatureUnit=="F")"%.1f°F".format(c*9/5+32) else"%.1f°C".format(c)
 private fun fmt(g:Double)=if(Storage.settings.weightUnit=="oz")"%.1f".format(g/28.3495) else"%.1f".format(g)
 private fun fmtTime(s:Int)="${s/60}:${(s%60).toString().padStart(2,'0')}"
 private fun date(ms:Long)=SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).format(Date(ms))
 private fun stamp()=SimpleDateFormat("yyyyMMdd-HHmmss",Locale.US).format(Date())
 private fun DoubleArray.averageOrNull():Double?=if(isEmpty())null else average()
 private fun List<Double>.averageOrNull():Double?=if(isEmpty())null else average()
}
