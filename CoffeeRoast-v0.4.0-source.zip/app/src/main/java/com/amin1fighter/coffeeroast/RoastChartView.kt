package com.amin1fighter.coffeeroast
import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import kotlin.math.ceil
class RoastChartView @JvmOverloads constructor(c:Context,a:AttributeSet?=null):View(c,a){
 var session:RoastSession?=null; var references:List<RoastSession> = emptyList(); var smoothing=1
 private val bt=paint("#D84315",5f);private val et=paint("#6D4C41",3f);private val rr=paint("#2E7D32",3f);private val dr=paint("#1565C0",2f);private val grid=paint("#8D8D8D",1f);private val txt=paint("#5D4037",16f)
 private fun paint(c:String,w:Float)=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.parseColor(c);strokeWidth=w;style=Paint.Style.STROKE}
 private fun t(c:String,w:Float=1f)=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.parseColor(c);strokeWidth=w;style=Paint.Style.STROKE}
 override fun onDraw(c:Canvas){super.onDraw(c);c.drawColor(Color.TRANSPARENT);val s=session?:return;val all=(listOf(s)+references).map{if(smoothing>1)RoastMath.smooth(it.tempLog,smoothing) else it.tempLog}.filter{it.size>1};if(all.isEmpty())return
  val left=62f;val top=45f;val right=18f;val bottom=38f;val w=width-left-right;val h=height-top-bottom;val maxTime=ceil(all.maxOf{it.last().elapsedSec}/30.0).toInt().coerceAtLeast(1)*30;val temps=all.flatMap{it.map{p->listOfNotNull(p.bt,p.et)}};val mn=(temps.minOrNull()?:0.0).let{kotlin.math.floor(k/10)*10};val mx=(temps.maxOrNull()?:220.0).let{kotlin.math.ceil(k/10)*10}.coerceAtLeast(mn+20)
  fun x(sec:Int)=left+sec.toFloat()/maxTime*w;fun y(v:Double)=top+h-((v-mn)/(mx-mn)).toFloat()*h
  var v=mn;while(v<=mx){c.drawLine(left,y(v),left+w,y(v),grid);c.drawText("${v.toInt()}°",4f,y(v)+5,txt);v+=10};var sec=0;while(sec<=maxTime){c.drawLine(x(sec),top,x(sec),top+h,grid);c.drawText("${sec/60}:${(sec%60).toString().padStart(2,'0')}",x(sec)-14,top+h+25,txt);sec+=30}
  all.forEachIndexed{idx,log->val bp=if(idx==0)bt else Paint(bt).apply{color=Color.argb(90,216,67,21)};for(i in 1 until log.size)c.drawLine(x(log[i-1].elapsedSec),y(log[i-1].bt),x(log[i].elapsedSec),y(log[i].bt),bp);if(idx==0)for(i in 1 until log.size){val a=log[i-1].et;val b=log[i].et;if(a!=null&&b!=null)c.drawLine(x(log[i-1].elapsedSec),y(a),x(log[i].elapsedSec),y(b),et)}}
  val rs=RoastMath.rorSeries(s.tempLog);if(rs.size>1){val maxR=maxOf(10.0,rs.maxOf{it.second});for(i in 1 until rs.size)c.drawLine(x(rs[i-1].first),top+h-(rs[i-1].second/maxR*h*.28f),x(rs[i].first),top+h-(rs[i].second/maxR*h*.28f),rr)}
  val ds=RoastMath.deltaRor(s.tempLog);if(ds.size>1){val scale=maxOf(5.0,ds.maxOf{ kotlin.math.abs(it.second)});for(i in 1 until ds.size)c.drawLine(x(ds[i-1].first),top+h/2-(ds[i-1].second/scale*h/2*.25f),x(ds[i].first),top+h/2-(ds[i].second/scale*h/2*.25f),dr)}
  fun marker(q:Int?,label:String){if(q!=null){c.drawLine(x(q),top,x(q),top+h,grid);c.drawText("$label ${q/60}:${(q%60).toString().padStart(2,'0')}",x(q)+3,top+18,txt)}}
  marker(s.turningPointSec,"TP");marker(s.dryEndSec,"DE");marker(s.firstCrackSec,"FC");marker(s.dropSec,"DROP");c.drawText("BT",left,20f,bt);c.drawText("RoR",left+45,20f,rr);c.drawText("ΔRoR",left+90,20f,dr)
 }
}
