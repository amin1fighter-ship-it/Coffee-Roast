package com.amin1fighter.coffeeroast
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object Storage {
 const val SCHEMA=4; private const val FILE="coffeeroast_data.json"
 var beans=mutableListOf<GreenBean>(); var roasts=mutableListOf<RoastSession>(); var settings=AppSettings()
 private var nb=1L; private var nr=1L; private var ng=1; private lateinit var file:File; private var loaded=false
 fun init(c:Context){if(loaded)return;file=File(c.filesDir,FILE);load();loaded=true}
 fun newBeanId()=nb++; fun newRoastId()=nr++
 fun allocateGlobalRoastNumber():Int { val x=ng; ng++; return x }
 fun nextBatch(bean:GreenBean)= (roasts.filter{it.beanId==bean.id}.maxOfOrNull{it.beanBatchNumber}?:0)+1
 fun addBean(b:GreenBean){beans.add(b);save()}; fun deleteBean(id:Long){beans.removeAll{it.id==id};save()}
 fun addRoast(r:RoastSession){roasts.add(r);save()}; fun deleteRoast(id:Long){roasts.removeAll{it.id==id};save()}
 fun beanById(id:Long)=beans.firstOrNull{it.id==id}
 fun save(){val j=toJson();val tmp=File(file.parentFile,"$FILE.tmp");tmp.writeText(j.toString());if(!tmp.renameTo(file)){file.delete();tmp.renameTo(file)}}
 private fun toJson():JSONObject{val root=JSONObject().put("schemaVersion",SCHEMA).put("nextBeanId",nb).put("nextRoastId",nr).put("nextGlobalRoastNumber",ng)
  root.put("settings",JSONObject().put("temperatureUnit",settings.temperatureUnit).put("weightUnit",settings.weightUnit).put("language",settings.language).put("logIntervalSec",settings.logIntervalSec).put("dryEndTargetC",settings.dryEndTargetC).put("firstCrackTargetC",settings.firstCrackTargetC).put("lowRorWarning",settings.lowRorWarning).put("theme",settings.theme).put("defaultRestDays",settings.defaultRestDays))
  val ba=JSONArray();beans.forEach{b->ba.put(JSONObject().apply{put("id",b.id);put("name",b.name);put("origin",b.origin);put("process",b.process);put("notes",b.notes);put("supplier",b.supplier);put("purchaseDate",b.purchaseDate);put("price",b.price);put("harvestYear",b.harvestYear);put("altitudeMasl",b.altitudeMasl?:JSONObject.NULL);put("variety",b.variety);put("storageLocation",b.storageLocation);put("stockGrams",b.stockGrams);put("totalBatches",b.totalBatches)})};root.put("beans",ba)
  val ra=JSONArray();roasts.forEach{r->ra.put(roastJson(r))};root.put("roasts",ra);return root}
 private fun roastJson(r:RoastSession)=JSONObject().apply{
  put("id",r.id);put("globalRoastNumber",r.globalRoastNumber);put("beanId",r.beanId);put("beanBatchNumber",r.beanBatchNumber);put("greenWeightG",r.greenWeightG);put("roastedWeightG",r.roastedWeightG?:JSONObject.NULL);put("densityGPerL",r.densityGPerL?:JSONObject.NULL);put("startFan",r.startFan);put("startHeater",r.startHeater)
  put("dryEndSec",r.dryEndSec?:JSONObject.NULL);put("turningPointSec",r.turningPointSec?:JSONObject.NULL);put("firstCrackSec",r.firstCrackSec?:JSONObject.NULL);put("dropSec",r.dropSec?:JSONObject.NULL);put("startTimeMillis",r.startTimeMillis);put("isComplete",r.isComplete);put("isHistorical",r.isHistorical);put("roasterName",r.roasterName);put("notes",r.notes);put("referenceRoastId",r.referenceRoastId?:JSONObject.NULL);put("restingDays",r.restingDays);put("roastedRemainingG",r.roastedRemainingG?:JSONObject.NULL)
  put("tasting",r.tasting?.let{tastingJson(it)}?:JSONObject.NULL);put("fanChanges",changes(r.fanChanges));put("heaterChanges",changes(r.heaterChanges));put("tempLog",JSONArray().apply{r.tempLog.forEach{put(JSONObject().put("elapsedSec",it.elapsedSec).put("bt",it.bt).put("et",it.et?:JSONObject.NULL))}})
 }
 private fun tastingJson(t:TastingScore)=JSONObject().apply{put("fragrance",t.fragrance);put("flavor",t.flavor);put("aftertaste",t.aftertaste);put("acidity",t.acidity);put("body",t.body);put("balance",t.balance);put("sweetness",t.sweetness);put("cleanCup",t.cleanCup);put("uniformity",t.uniformity);put("overall",t.overall);put("notes",t.notes)}
 private fun changes(x:List<SettingChange>)=JSONArray().apply{x.forEach{put(JSONObject().put("elapsedSec",it.elapsedSec).put("btAtChange",it.btAtChange).put("level",it.level))}}
 private fun load(){try{if(!file.exists())return;val root=JSONObject(file.readText());val v=root.optInt("schemaVersion",1); // v1-v4 are backward compatible
   nb=root.optLong("nextBeanId",1);nr=root.optLong("nextRoastId",1);ng=root.optInt("nextGlobalRoastNumber",1)
   val s=root.optJSONObject("settings");if(s!=null){settings=AppSettings(s.optString("temperatureUnit","C"),s.optString("weightUnit","g"),s.optString("language","en"),s.optInt("logIntervalSec",30),s.optDouble("dryEndTargetC",150.0),s.optDouble("firstCrackTargetC",200.0),s.optDouble("lowRorWarning",10.0),s.optString("theme","system"),s.optInt("defaultRestDays",7))}
   val ba=root.optJSONArray("beans");beans=mutableListOf();for(i in 0 until (ba?.length()?:0)){val o=ba!!.getJSONObject(i);beans.add(GreenBean(o.getLong("id"),o.optString("name"),o.optString("origin"),o.optString("process"),o.optString("notes"),o.optString("supplier"),o.optString("purchaseDate"),o.optDouble("price"),o.optString("harvestYear"),if(o.isNull("altitudeMasl"))null else o.optDouble("altitudeMasl"),o.optString("variety"),o.optString("storageLocation"),o.optDouble("stockGrams"),o.optInt("totalBatches")))}
   val ra=root.optJSONArray("roasts");roasts=mutableListOf();for(i in 0 until (ra?.length()?:0)){val o=ra!!.getJSONObject(i);val r=RoastSession(o.getLong("id"),o.optInt("globalRoastNumber"),o.getLong("beanId"),o.optInt("beanBatchNumber"),o.optDouble("greenWeightG"),if(o.isNull("roastedWeightG"))null else o.optDouble("roastedWeightG"),if(o.isNull("densityGPerL"))null else o.optDouble("densityGPerL"),o.optInt("startFan"),o.optInt("startHeater"));r.dryEndSec=ni(o,"dryEndSec");r.turningPointSec=ni(o,"turningPointSec");r.firstCrackSec=ni(o,"firstCrackSec");r.dropSec=ni(o,"dropSec");r.startTimeMillis=o.optLong("startTimeMillis");r.isComplete=o.optBoolean("isComplete");r.isHistorical=o.optBoolean("isHistorical");r.roasterName=o.optString("roasterName");r.notes=o.optString("notes");r.referenceRoastId=nl(o,"referenceRoastId");r.restingDays=o.optInt("restingDays",settings.defaultRestDays);r.roastedRemainingG=if(o.isNull("roastedRemainingG"))null else o.optDouble("roastedRemainingG")
    val t=o.optJSONObject("tasting");if(t!=null)r.tasting=TastingScore(t.optDouble("fragrance"),t.optDouble("flavor"),t.optDouble("aftertaste"),t.optDouble("acidity"),t.optDouble("body"),t.optDouble("balance"),t.optDouble("sweetness"),t.optDouble("cleanCup"),t.optDouble("uniformity"),t.optDouble("overall"),t.optString("notes"))
    loadChanges(o.optJSONArray("fanChanges"),r.fanChanges);loadChanges(o.optJSONArray("heaterChanges"),r.heaterChanges);val ta=o.optJSONArray("tempLog");for(k in 0 until (ta?.length()?:0)){val q=ta!!.getJSONObject(k);r.tempLog.add(TempPoint(q.optInt("elapsedSec"),q.optDouble("bt"),if(q.isNull("et")||!q.has("et"))null else q.optDouble("et")))};roasts.add(r)}
   // Repair counters and legacy batch numbering.
   nb=maxOf(nb,(beans.maxOfOrNull{it.id}?:0)+1);nr=maxOf(nr,(roasts.maxOfOrNull{it.id}?:0)+1);ng=maxOf(ng,(roasts.maxOfOrNull{it.globalRoastNumber}?:0)+1)
   beans.forEach{it.totalBatches=roasts.count{r->r.beanId==it.id}}
   if(v<SCHEMA)save()
 }catch(_:Exception){recoverFromBackup()}}
 private fun ni(o:JSONObject,k:String)=if(o.isNull(k))null else o.optInt(k)
 private fun nl(o:JSONObject,k:String)=if(o.isNull(k))null else o.optLong(k)
 private fun loadChanges(a:JSONArray?,out:MutableList<SettingChange>){for(i in 0 until (a?.length()?:0)){val o=a!!.getJSONObject(i);out.add(SettingChange(o.optInt("elapsedSec"),o.optDouble("btAtChange"),o.optInt("level")))}}
 private fun recoverFromBackup(){beans=mutableListOf();roasts=mutableListOf()}
 fun exportBackup(context:Context,out:File){ZipOutputStream(out.outputStream()).use{z->z.putNextEntry(ZipEntry(FILE));z.write(toJson().toString().toByteArray());z.closeEntry()}}
 fun importBackup(context:Context,src:File){ZipInputStream(src.inputStream()).use{z->var e=z.nextEntry;while(e!=null){if(e.name==FILE){val text=z.readBytes().toString(Charsets.UTF_8);val tmp=File(file.parentFile,"$FILE.import");tmp.writeText(text);tmp.renameTo(file);load();break};e=z.nextEntry}}}
 fun rawJson()=toJson().toString()
}
