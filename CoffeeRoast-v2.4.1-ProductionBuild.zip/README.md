# Coffee Roast Pro

Android roast logging app.

## Versioning

The app version is controlled by Gradle properties:

- `APP_VERSION_NAME=2.4.1`
- `APP_VERSION_CODE=20401`

For releases, use a Git tag such as `v2.4.1`. The release workflow derives the version automatically.

## Build

Debug build:

```bash
gradle assembleDebug
```

The GitHub Actions build uses JDK 17 + Gradle 8.7 and builds the actual project directly.
It does **not** unzip a temporary project over the repository.

## Real app updates

Do not use a newly generated signing key for each release. Android updates require the same signing identity.

Add these GitHub repository secrets:

- `ANDROID_KEYSTORE_BASE64`
- `ANDROID_KEYSTORE_PASSWORD`
- `ANDROID_KEY_ALIAS`
- `ANDROID_KEY_PASSWORD`

Then push a tag:

```bash
git tag v2.4.1
git push origin v2.4.1
```

The release workflow builds a signed APK and attaches it to the GitHub Release.

### Important

The current CSV export is a roast-data CSV, not a native Artisan `.alog` profile. Artisan compatibility should be implemented as a separate export layer rather than pretending this CSV is a native Artisan file.
