# Changelog

## 2.4.1
- Fixed Kotlin compile-breaking literal newlines in status/CSV strings.
- Removed temporary ZIP extraction from CI.
- Added real Gradle versioning through `APP_VERSION_NAME` and `APP_VERSION_CODE`.
- Added a tag-based signed release workflow.
- Prevented inventory deduction until CSV export succeeds.
- Documented persistent Android signing for future updates.
