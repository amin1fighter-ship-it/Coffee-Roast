package com.amin1fighter.coffeeroast

import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.max
import kotlin.math.min

class RoastChartView(context: Context) : View(context) {
    var points: List<Point> = emptyList()
    var dry: Double? = null
    var fc: Double? = null
    var drop: Double? = null

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.parseColor("#FBF9F5"))
        if (points.size < 2) {
            paint.color = Color.GRAY
            paint.textSize = 28f
            paint.textAlign = Paint.Align.CENTER
            canvas.drawText("No roast data points yet", width / 2f, height / 2f, paint)
            return
        }

        val left = 70f
        val right = width - 30f
        val top = 40f
        val bottom = height - 60f
        val maxTime = max(60.0, points.maxOf { it.sec })
        val minTemp = min(50.0, points.minOf { min(it.bt, it.et) })
        val maxTemp = max(220.0, points.maxOf { max(it.bt, it.et) })

        fun x(t: Double) = left + (t / maxTime) * (right - left)
        fun y(v: Double) = bottom - ((v - minTemp) / (maxTemp - minTemp)) * (bottom - top)

        fun curve(selector: (Point) -> Double, colorInt: Int, widthPx: Float) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = widthPx
            paint.color = colorInt
            val path = Path()
            points.forEachIndexed { i, p ->
                val px = x(p.sec).toFloat()
                val py = y(selector(p)).toFloat()
                if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
            }
            canvas.drawPath(path, paint)
        }

        curve({ it.bt }, Color.parseColor("#2C1A14"), 5f)
        curve({ it.et }, Color.parseColor("#C68B59"), 3f)

        paint.textSize = 22f
        paint.style = Paint.Style.FILL
        paint.color = Color.parseColor("#2C1A14")
        paint.textAlign = Paint.Align.LEFT
        canvas.drawText("BT deg C", left, 28f, paint)
        paint.color = Color.parseColor("#C68B59")
        canvas.drawText("ET deg C", left + 80f, 28f, paint)

        fun marker(sec: Double?, label: String, colorHex: String) {
            if (sec == null) return
            paint.color = Color.parseColor(colorHex)
            paint.strokeWidth = 3f
            canvas.drawLine(x(sec).toFloat(), top, x(sec).toFloat(), bottom, paint)
            paint.textSize = 20f
            paint.style = Paint.Style.FILL
            canvas.drawText(label, x(sec).toFloat() - 15f, bottom + 35f, paint)
        }

        marker(dry, "DRY", "#3498DB")
        marker(fc, "FC", "#E67E22")
        marker(drop, "DROP", "#E74C3C")

        paint.textSize = 18f
        paint.color = Color.GRAY
        canvas.drawText(maxTemp.toInt().toString(), 10f, top + 10f, paint)
        canvas.drawText(minTemp.toInt().toString(), 10f, bottom, paint)
    }
}
