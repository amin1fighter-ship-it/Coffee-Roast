package com.amin1fighter.coffeeroast

data class Point(
    val sec: Double,
    val bt: Double,
    val et: Double,
    val fan: Int?,
    val heater: Int?
)

object RoastMath {
    fun instantRor(points: List<Point>, i: Int): Double {
        if (i <= 0 || i >= points.size) return 0.0
        val a = points[i - 1]
        val b = points[i]
        val dt = b.sec - a.sec
        return if (dt <= 0.0) 0.0 else (b.bt - a.bt) * 60.0 / dt
    }

    fun smoothRor(points: List<Point>, i: Int, span: Int = 4): Double {
        if (i < 1) return 0.0
        val start = maxOf(1, i - span + 1)
        return (start..i).map { instantRor(points, it) }.average()
    }

    fun phase(sec: Double, dry: Double?, fc: Double?, drop: Double?): String =
        when {
            dry == null || sec < dry -> "DRYING"
            fc == null || sec < fc -> "MAILLARD"
            drop == null || sec < drop -> "DEVELOPMENT"
            else -> "END"
        }

    fun percent(start: Double?, end: Double?, total: Double): Double =
        if (start == null || end == null || total <= 0) 0.0
        else ((end - start) / total * 100.0).coerceIn(0.0, 100.0)

    fun weightLoss(green: Double, roasted: Double): Double =
        if (green <= 0) 0.0 else (green - roasted) / green * 100.0
}
