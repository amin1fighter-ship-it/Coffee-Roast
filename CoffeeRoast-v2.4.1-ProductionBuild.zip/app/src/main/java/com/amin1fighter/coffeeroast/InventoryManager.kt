package com.amin1fighter.coffeeroast

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

class InventoryManager(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("green_beans_pref", Context.MODE_PRIVATE)

    fun getBeans(): List<GreenBean> {
        val jsonStr = prefs.getString("beans_list", "[]") ?: "[]"
        val list = mutableListOf<GreenBean>()
        try {
            val array = JSONArray(jsonStr)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(
                    GreenBean(
                        id = obj.optString("id", System.currentTimeMillis().toString()),
                        name = obj.optString("name", "Unknown Bean"),
                        origin = obj.optString("origin", ""),
                        process = obj.optString("process", ""),
                        varietal = obj.optString("varietal", ""),
                        stockGrams = obj.optDouble("stockGrams", 0.0),
                        pricePerKg = obj.optDouble("pricePerKg", 0.0)
                    )
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return list
    }

    fun saveBeans(list: List<GreenBean>) {
        val array = JSONArray()
        for (bean in list) {
            val obj = JSONObject().apply {
                put("id", bean.id)
                put("name", bean.name)
                put("origin", bean.origin)
                put("process", bean.process)
                put("varietal", bean.varietal)
                put("stockGrams", bean.stockGrams)
                put("pricePerKg", bean.pricePerKg)
            }
            array.put(obj)
        }
        prefs.edit().putString("beans_list", array.toString()).apply()
    }

    fun addBean(bean: GreenBean) {
        val current = getBeans().toMutableList()
        current.add(bean)
        saveBeans(current)
    }

    fun deductStock(beanId: String, usedGrams: Double): Boolean {
        if (usedGrams <= 0) return false
        val current = getBeans().toMutableList()
        val index = current.indexOfFirst { it.id == beanId }
        if (index != -1) {
            val bean = current[index]
            bean.stockGrams = (bean.stockGrams - usedGrams).coerceAtLeast(0.0)
            saveBeans(current)
            return true
        }
        return false
    }

    fun deleteBean(beanId: String) {
        val current = getBeans().filter { it.id != beanId }
        saveBeans(current)
    }
}
