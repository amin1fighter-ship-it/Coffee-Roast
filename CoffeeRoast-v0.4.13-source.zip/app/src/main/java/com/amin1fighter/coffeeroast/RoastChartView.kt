package com.amin1fighter.coffeeroast

import android.content.Context
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import kotlin.math.ceil
import kotlin.math.max

/** Roast chart: temperature is the main panel, RoR on the same plot, fan/heater strip below. */
class RoastChartView @JvmOverloads constructor(c: Context, a: AttributeSet? = null) : View(c, a) {
    var session: RoastSession? = null
    var references: List<RoastSession> = emptyList()
    var smoothing: Int = 1
    /** PDF-only time-axis label interval. Live chart keeps its native 30s grid. */
    var pdfTimeLabelStepSec: Int? = null

    private val isDark: Boolean
        get() = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES

    private fun paint(color: String, width: Float) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = Color.parseColor(color)
        strokeWidth = width
        style = Paint.Style.STROKE
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val s = session ?: return
        val current = clean(s.tempLog)
        val refs = references.map { clean(it.tempLog) }.filter { it.size > 1 }
        if (current.size < 2 && refs.isEmpty()) return

        val btPaint = paint(if (isDark) "#FF8A65" else "#D84315", 5f)
        val etPaint = paint(if (isDark) "#BCAAA4" else "#6D4C41", 3f)
        val refPaint = paint(if (isDark) "#9E9E9E" else "#9E9E9E", 2f)
        val gridPaint = paint(if (isDark) "#424242" else "#D0D0D0", 1f)
        val eventPaint = paint(if (isDark) "#BDBDBD" else "#555555", 1.5f)
        val fanPaint = paint(if (isDark) "#64B5F6" else "#1565C0", 2.5f)
        val heaterPaint = paint(if (isDark) "#FFB74D" else "#EF6C00", 2.5f)
        val rorPaint = paint(if (isDark) "#81C784" else "#2E7D32", 3f)
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (isDark) Color.parseColor("#E0E0E0") else Color.parseColor("#4E342E")
            textSize = 14f
        }
        val smallText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (isDark) Color.parseColor("#BDBDBD") else Color.DKGRAY
            textSize = 12f
        }

        val left = 58f
        val right = 48f
        val top = 46f
        val plotBottom = height * 0.76f
        val controlTop = plotBottom + 22f
        val plotW = width - left - right
        if (plotW <= 0f || plotBottom <= top) return

        val logs = listOf(current) + refs
        val maxElapsed = logs.maxOfOrNull { it.lastOrNull()?.elapsedSec ?: 0 } ?: 0
        val maxTime = ceil(max(30, maxElapsed) / 30.0).toInt() * 30
        val highest = logs.flatMap { it.flatMap { p -> listOfNotNull(p.bt, p.et) } }.maxOrNull() ?: 220.0
        val maxTemp = if (highest <= 220.0) 220.0 else ceil(highest / 20.0) * 20.0

        fun x(sec: Int) = left + (sec.coerceIn(0, maxTime).toFloat() / maxTime) * plotW
        fun yt(v: Double): Float =
            plotBottom - (v.coerceIn(0.0, maxTemp) / maxTemp).toFloat() * (plotBottom - top)

        var t = 0.0
        while (t <= maxTemp + 0.1) {
            c.drawLine(left, yt(t), left + plotW, yt(t), gridPaint)
            c.drawText("${t.toInt()}°", 3f, yt(t) + 5f, textPaint)
            t += 20.0
        }
        c.drawText("TEMPERATURE", left, 19f, textPaint)
        c.drawText("BT", left + 120f, 19f, btPaint)
        c.drawText("ET", left + 160f, 19f, etPaint)
        if (refs.isNotEmpty()) c.drawText("REF", left + 205f, 19f, refPaint)

        refs.forEach { drawBt(c, it, ::x, ::yt, refPaint) }
        drawBt(c, current, ::x, ::yt, btPaint)
        drawEt(c, current, ::x, ::yt, etPaint)

        val rr = RoastMath.rorSeries(current, 60)
        if (rr.size >= 2) {
            val rrMax = maxOf(20.0, ceil((rr.maxOf { it.second }.coerceAtLeast(0.0) + 2.0) / 5.0) * 5.0)
            val rrMin = minOf(-5.0, kotlin.math.floor((rr.minOf { it.second }) / 5.0) * 5.0)
            fun yr(v: Double): Float =
                plotBottom - ((v - rrMin) / (rrMax - rrMin)).coerceIn(0.0, 1.0).toFloat() * (plotBottom - top)
            c.drawText("RoR °C/min", left + plotW - 78f, 19f, rorPaint)
            c.drawText("${rrMax.toInt()}", left + plotW + 5f, yt(maxTemp) + 5f, smallText)
            c.drawText("0", left + plotW + 5f, yr(0.0) + 5f, smallText)
            c.drawText("${rrMin.toInt()}", left + plotW + 5f, plotBottom + 5f, smallText)
            c.drawLine(left, yr(0.0), left + plotW, yr(0.0), gridPaint)
            for (i in 1 until rr.size) {
                c.drawLine(
                    x(rr[i - 1].first), yr(rr[i - 1].second),
                    x(rr[i].first), yr(rr[i].second), rorPaint
                )
            }
        }

        fun marker(sec: Int?, label: String) {
            if (sec == null || sec !in 0..maxTime) return
            c.drawLine(x(sec), top, x(sec), plotBottom, eventPaint)
            c.drawText("$label ${fmt(sec)}", x(sec) + 3f, top + 15f, smallText)
        }
        marker(s.turningPointSec, "TP")
        marker(s.dryEndSec, "DE")
        marker(s.firstCrackSec, "FC")
        marker(s.secondCrackSec, "SC")
        marker(s.dropSec, "DROP")

        val labelStep = pdfTimeLabelStepSec?.coerceAtLeast(30) ?: 30
        var sec = 0
        while (sec <= maxTime) {
            c.drawLine(x(sec), top, x(sec), plotBottom, gridPaint)
            if (sec % labelStep == 0) {
                val label = fmt(sec)
                val tw = smallText.measureText(label)
                c.drawText(label, x(sec) - tw / 2f, plotBottom + 16f, smallText)
            }
            sec += 30
        }

        c.drawText("CONTROLS", 3f, controlTop + 12f, textPaint)
        c.drawLine(left, controlTop + 2f, left + plotW, controlTop + 2f, gridPaint)
        c.drawLine(left, controlTop + 20f, left + plotW, controlTop + 20f, gridPaint)
        c.drawText("Fan", 3f, controlTop + 7f, fanPaint)
        c.drawText("Heater", 3f, controlTop + 25f, heaterPaint)
        s.fanChanges.sortedBy { it.elapsedSec }.forEach { q ->
            val xx = x(q.elapsedSec)
            c.drawLine(xx, controlTop - 1f, xx, controlTop + 10f, fanPaint)
            c.drawText("F${q.level}", xx + 2f, controlTop + 10f, smallText)
        }
        s.heaterChanges.sortedBy { it.elapsedSec }.forEach { q ->
            val xx = x(q.elapsedSec)
            c.drawLine(xx, controlTop + 17f, xx, controlTop + 29f, heaterPaint)
            c.drawText("H${q.level}", xx + 2f, controlTop + 29f, smallText)
        }
    }

    private fun clean(source: List<TempPoint>): List<TempPoint> {
        val sorted = source.sortedBy { it.elapsedSec }
        val filtered = sorted.filter {
            it.elapsedSec >= 0 && it.bt.isFinite() && it.bt in 0.0..300.0 &&
                (it.et == null || (it.et!!.isFinite() && it.et!! in 0.0..300.0))
        }
        return if (smoothing > 1) RoastMath.smooth(filtered, smoothing) else filtered
    }

    private fun drawBt(
        c: Canvas, log: List<TempPoint>,
        x: (Int) -> Float, y: (Double) -> Float, p: Paint
    ) {
        for (i in 1 until log.size) {
            c.drawLine(x(log[i - 1].elapsedSec), y(log[i - 1].bt), x(log[i].elapsedSec), y(log[i].bt), p)
        }
    }

    private fun drawEt(
        c: Canvas, log: List<TempPoint>,
        x: (Int) -> Float, y: (Double) -> Float, etPaint: Paint
    ) {
        for (i in 1 until log.size) {
            val a = log[i - 1].et
            val b = log[i].et
            if (a != null && b != null) {
                c.drawLine(x(log[i - 1].elapsedSec), y(a), x(log[i].elapsedSec), y(b), etPaint)
            }
        }
    }

    private fun fmt(sec: Int) = "${sec / 60}:${(sec % 60).toString().padStart(2, '0')}"
}
