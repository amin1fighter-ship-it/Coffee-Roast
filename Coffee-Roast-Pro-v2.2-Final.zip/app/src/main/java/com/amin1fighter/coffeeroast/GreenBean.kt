package com.amin1fighter.coffeeroast

data class GreenBean(
    val id: String,
    val name: String,
    val origin: String = "",
    val process: String = "",
    val varietal: String = "",
    var stockGrams: Double = 0.0,
    val pricePerKg: Double = 0.0
) {
    fun stockStatus(): String = when {
        stockGrams <= 0.0 -> "🔴 Out of Stock"
        stockGrams < 1000.0 -> "🟡 Low Stock (${String.format("%.0f", stockGrams)}g)"
        else -> "🟢 Available (${String.format("%.1f", stockGrams / 1000.0)} kg)"
    }
}
