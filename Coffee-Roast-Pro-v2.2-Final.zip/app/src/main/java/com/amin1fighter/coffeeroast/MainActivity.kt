package com.amin1fighter.coffeeroast

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.*
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var inventoryManager: InventoryManager
    private val points = mutableListOf<Point>()
    private var dry: Double? = null
    private var fc: Double? = null
    private var drop: Double? = null

    private lateinit var mainContentLayout: LinearLayout
    private lateinit var roastViewLayout: LinearLayout
    private lateinit var inventoryViewLayout: LinearLayout

    private lateinit var beanSpinner: Spinner
    private lateinit var chart: RoastChartView
    private lateinit var status: TextView
    private lateinit var time: EditText
    private lateinit var bt: EditText
    private lateinit var et: EditText
    private lateinit var fan: EditText
    private lateinit var heater: EditText
    private lateinit var greenWeight: EditText
    private lateinit var roastedWeight: EditText
    private lateinit var name: EditText

    private lateinit var invName: EditText
    private lateinit var invOrigin: EditText
    private lateinit var invProcess: EditText
    private lateinit var invVarietal: EditText
    private lateinit var invStockGrams: EditText
    private lateinit var invPriceKg: EditText
    private lateinit var inventoryListContainer: LinearLayout

    private var availableBeans = listOf<GreenBean>()
    private var selectedBean: GreenBean? = null
    private var pendingCsv = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        inventoryManager = InventoryManager(this)
        buildUi()
        loadInventoryData()
    }

    private fun field(hintStr: String): EditText =
        EditText(this).apply {
            hint = hintStr
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setBackgroundColor(Color.parseColor("#FFFFFF"))
            setPadding(16, 16, 16, 16)
        }

    private fun textField(hintStr: String): EditText =
        EditText(this).apply {
            hint = hintStr
            setBackgroundColor(Color.parseColor("#FFFFFF"))
            setPadding(16, 16, 16, 16)
        }

    private fun styledButton(labelStr: String, bgColorHex: String, textColorHex: String = "#FFFFFF", action: () -> Unit): Button =
        Button(this).apply {
            text = labelStr
            setTextColor(Color.parseColor(textColorHex))
            setBackgroundColor(Color.parseColor(bgColorHex))
            typeface = Typeface.DEFAULT_BOLD
            setOnClickListener { action() }
        }

    private fun cardView(content: View): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
            setPadding(20, 20, 20, 20)
            val params = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 10, 0, 16) }
            layoutParams = params
            addView(content)
        }

    private fun buildUi() {
        val rootScroll = ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#FBF9F5"))
        }

        val mainRoot = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 16, 16, 24)
        }

        val header = TextView(this).apply {
            text = "☕ Coffee Roast Pro"
            textSize = 24f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.parseColor("#2C1A14"))
            setPadding(8, 8, 8, 16)
        }
        mainRoot.addView(header)

        val tabLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 0, 0, 16)
        }
        val btnRoastTab = styledButton("🔥 Roast Logger", "#2C1A14") {
            roastViewLayout.visibility = View.VISIBLE
            inventoryViewLayout.visibility = View.GONE
        }
        val btnInvTab = styledButton("🌱 Green Beans", "#4B7B47") {
            roastViewLayout.visibility = View.GONE
            inventoryViewLayout.visibility = View.VISIBLE
            refreshInventoryList()
        }
        tabLayout.addView(btnRoastTab, LinearLayout.LayoutParams(0, -2, 1f))
        tabLayout.addView(btnInvTab, LinearLayout.LayoutParams(0, -2, 1f))
        mainRoot.addView(tabLayout)

        mainContentLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        roastViewLayout = buildRoastView()
        inventoryViewLayout = buildInventoryView()

        mainContentLayout.addView(roastViewLayout)
        mainContentLayout.addView(inventoryViewLayout)
        inventoryViewLayout.visibility = View.GONE

        mainRoot.addView(mainContentLayout)
        rootScroll.addView(mainRoot)
        setContentView(rootScroll)
    }

    private fun buildRoastView(): LinearLayout {
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val selectorBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        selectorBox.addView(TextView(this).apply {
            text = "Select Green Coffee Bean:"
            textSize = 14f
            setTextColor(Color.parseColor("#2C1A14"))
        })
        beanSpinner = Spinner(this)
        selectorBox.addView(beanSpinner)
        layout.addView(cardView(selectorBox))

        val batchBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        name = textField("Batch / Roast Profile Name")
        greenWeight = field("Green Weight (g)")
        roastedWeight = field("Roasted Weight (g)")

        batchBox.addView(name)
        batchBox.addView(greenWeight)
        batchBox.addView(roastedWeight)
        layout.addView(cardView(batchBox))

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        time = field("Time (s)")
        bt = field("BT °C")
        et = field("ET °C")
        fan = field("Fan")
        heater = field("Heater")
        listOf(time, bt, et, fan, heater).forEach {
            row.addView(it, LinearLayout.LayoutParams(0, -2, 1f))
        }
        layout.addView(cardView(row))

        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        controls.addView(styledButton("+ ADD LOG", "#2C1A14") { addPoint() }, LinearLayout.LayoutParams(0, -2, 1.2f))
        controls.addView(styledButton("DRY", "#3498DB") { dry = points.lastOrNull()?.sec; refresh() }, LinearLayout.LayoutParams(0, -2, 1f))
        controls.addView(styledButton("FC", "#E67E22") { fc = points.lastOrNull()?.sec; refresh() }, LinearLayout.LayoutParams(0, -2, 1f))
        controls.addView(styledButton("DROP", "#E74C3C") { drop = points.lastOrNull()?.sec; refresh() }, LinearLayout.LayoutParams(0, -2, 1f))
        layout.addView(controls)

        chart = RoastChartView(this)
        layout.addView(cardView(chart).apply {
            layoutParams = LinearLayout.LayoutParams(-1, 550)
        })

        status = TextView(this).apply {
            textSize = 15f
            setTextColor(Color.parseColor("#2C1A14"))
            setPadding(12, 12, 12, 12)
            setBackgroundColor(Color.parseColor("#FFFFFF"))
        }
        layout.addView(status)

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(styledButton("💾 EXPORT & DEDUCT STOCK", "#4B7B47") { exportAndDeduct() }, LinearLayout.LayoutParams(0, -2, 1.5f))
        actions.addView(styledButton("CLEAR", "#7F8C8D") { clearAll() }, LinearLayout.LayoutParams(0, -2, 1f))
        layout.addView(actions)

        return layout
    }

    private fun buildInventoryView(): LinearLayout {
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val formTitle = TextView(this).apply {
            text = "🌱 Add New Green Coffee Bean"
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.parseColor("#2C1A14"))
        }
        layout.addView(formTitle)

        invName = textField("Coffee Bean Name (e.g. Colombia Chiroso)")
        invOrigin = textField("Origin / Farm (e.g. Huila, Colombia)")
        invProcess = textField("Process (e.g. Washed / Anaerobic)")
        invVarietal = textField("Varietal (e.g. Caturra / Sidra)")
        invStockGrams = field("Initial Stock (Grams)")
        invPriceKg = field("Price per Kg ($)")

        val formBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        listOf(invName, invOrigin, invProcess, invVarietal, invStockGrams, invPriceKg).forEach {
            formBox.addView(it)
        }
        val btnAdd = styledButton("➕ SAVE GREEN BEAN TO INVENTORY", "#4B7B47") {
            saveNewGreenBean()
        }
        formBox.addView(btnAdd)
        layout.addView(cardView(formBox))

        val listTitle = TextView(this).apply {
            text = "📦 Current Green Bean Stock"
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.parseColor("#2C1A14"))
            setPadding(0, 16, 0, 8)
        }
        layout.addView(listTitle)

        inventoryListContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        layout.addView(inventoryListContainer)

        return layout
    }

    private fun loadInventoryData() {
        availableBeans = inventoryManager.getBeans()
        val names = if (availableBeans.isEmpty()) listOf("No Green Beans (Add in Green Beans tab)")
        else availableBeans.map { "${it.name} - ${it.stockStatus()}" }

        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, names)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        beanSpinner.adapter = adapter

        beanSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, pos: Int, p3: Long) {
                if (availableBeans.isNotEmpty() && pos in availableBeans.indices) {
                    selectedBean = availableBeans[pos]
                    if (name.text.isEmpty()) name.setText(selectedBean?.name)
                }
            }
            override fun onNothingSelected(p0: AdapterView<*>?) {}
        }
    }

    private fun saveNewGreenBean() {
        val bName = invName.text.toString().trim()
        val grams = invStockGrams.text.toString().toDoubleOrNull() ?: 0.0
        if (bName.isEmpty()) {
            Toast.makeText(this, "Please enter a bean name", Toast.LENGTH_SHORT).show()
            return
        }

        val bean = GreenBean(
            id = System.currentTimeMillis().toString(),
            name = bName,
            origin = invOrigin.text.toString().trim(),
            process = invProcess.text.toString().trim(),
            varietal = invVarietal.text.toString().trim(),
            stockGrams = grams,
            pricePerKg = invPriceKg.text.toString().toDoubleOrNull() ?: 0.0
        )

        inventoryManager.addBean(bean)
        Toast.makeText(this, "Green bean saved to inventory!", Toast.LENGTH_SHORT).show()

        invName.text.clear()
        invOrigin.text.clear()
        invProcess.text.clear()
        invVarietal.text.clear()
        invStockGrams.text.clear()
        invPriceKg.text.clear()

        loadInventoryData()
        refreshInventoryList()
    }

    private fun refreshInventoryList() {
        inventoryListContainer.removeAllViews()
        val beans = inventoryManager.getBeans()

        if (beans.isEmpty()) {
            inventoryListContainer.addView(TextView(this).apply {
                text = "No green coffee beans in inventory."
                setTextColor(Color.GRAY)
                setPadding(16, 16, 16, 16)
            })
            return
        }

        for (bean in beans) {
            val itemBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            val tName = TextView(this).apply {
                text = bean.name
                textSize = 16f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.parseColor("#2C1A14"))
            }
            val tStatus = TextView(this).apply {
                text = bean.stockStatus()
                textSize = 14f
                setPadding(0, 4, 0, 4)
            }
            val tDetails = TextView(this).apply {
                text = "Origin: ${bean.origin.ifEmpty { "—" }} | Process: ${bean.process.ifEmpty { "—" }} | Varietal: ${bean.varietal.ifEmpty { "—" }}"
                textSize = 12f
                setTextColor(Color.GRAY)
            }

            val btnDel = styledButton("Delete", "#E74C3C") {
                inventoryManager.deleteBean(bean.id)
                loadInventoryData()
                refreshInventoryList()
            }

            itemBox.addView(tName)
            itemBox.addView(tStatus)
            itemBox.addView(tDetails)
            itemBox.addView(btnDel)

            inventoryListContainer.addView(cardView(itemBox))
        }
    }

    private fun addPoint() {
        val t = time.text.toString().toDoubleOrNull() ?: return
        val b = bt.text.toString().toDoubleOrNull() ?: return
        val e = et.text.toString().toDoubleOrNull() ?: 0.0
        val f = fan.text.toString().toIntOrNull()
        val h = heater.text.toString().toIntOrNull()
        points.add(Point(t, b, e, f, h))
        refresh()
    }

    private fun refresh() {
        chart.points = points
        chart.dry = dry
        chart.fc = fc
        chart.drop = drop
        chart.invalidate()

        if (points.isEmpty()) {
            status.text = "No roast points recorded yet."
            return
        }

        val i = points.lastIndex
        val p = points[i]
        val ror = RoastMath.instantRor(points, i)
        val smooth = RoastMath.smoothRor(points, i)
        val total = drop ?: p.sec
        val dryPct = RoastMath.percent(0.0, dry, total)
        val maiPct = RoastMath.percent(dry, fc, total)
        val devPct = RoastMath.percent(fc, drop, total)
        val loss = RoastMath.weightLoss(
            greenWeight.text.toString().toDoubleOrNull() ?: 0.0,
            roastedWeight.text.toString().toDoubleOrNull() ?: 0.0
        )

        status.text = String.format(
            Locale.US,
            "BT %.1f°C | RoR %.1f°C/min | Smooth %.1f°C/min
" +
                    "Phase: %s | Dry %.1f%% | Maillard %.1f%% | Dev %.1f%%
" +
                    "Weight Loss: %.1f%% | Fan: %s | Heater: %s",
            p.bt, ror, smooth,
            RoastMath.phase(p.sec, dry, fc, drop),
            dryPct, maiPct, devPct, loss,
            p.fan?.toString() ?: "—",
            p.heater?.toString() ?: "—"
        )
    }

    private fun exportAndDeduct() {
        if (points.isEmpty()) {
            Toast.makeText(this, "Add roast points before exporting!", Toast.LENGTH_SHORT).show()
            return
        }

        val gWeight = greenWeight.text.toString().toDoubleOrNull() ?: 0.0
        selectedBean?.let { bean ->
            if (gWeight > 0) {
                val success = inventoryManager.deductStock(bean.id, gWeight)
                if (success) {
                    Toast.makeText(this, "Deducted ${gWeight}g from ${bean.name} inventory!", Toast.LENGTH_LONG).show()
                    loadInventoryData()
                }
            }
        }

        val roastName = name.text.toString().ifBlank { "roast_profile" }
        pendingCsv = buildString {
            append("Time_sec,BT_C,ET_C,RoR_C_min,RoR_Smoothed_C_min,Fan,Heater,Event,Phase
")
            points.forEachIndexed { i, p ->
                val event = when (p.sec) {
                    dry -> "DRY_END"
                    fc -> "FC_START"
                    drop -> "DROP"
                    else -> ""
                }
                append(String.format(
                    Locale.US,
                    "%.2f,%.2f,%.2f,%.3f,%.3f,%s,%s,%s,%s
",
                    p.sec, p.bt, p.et,
                    RoastMath.instantRor(points, i),
                    RoastMath.smoothRor(points, i),
                    p.fan?.toString() ?: "",
                    p.heater?.toString() ?: "",
                    event,
                    RoastMath.phase(p.sec, dry, fc, drop)
                ))
            }
        }

        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            type = "text/csv"
            putExtra(Intent.EXTRA_TITLE, "$roastName.csv")
        }
        startActivityForResult(intent, 42)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 42 && resultCode == RESULT_OK && data?.data != null) {
            contentResolver.openOutputStream(data.data!!)?.use {
                it.write(pendingCsv.toByteArray(Charsets.UTF_8))
            }
            Toast.makeText(this, "Roast CSV Exported Successfully!", Toast.LENGTH_SHORT).show()
        }
    }

    private fun clearAll() {
        points.clear()
        dry = null
        fc = null
        drop = null
        refresh()
    }
}
