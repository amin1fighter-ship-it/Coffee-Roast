# Coffee Roast Lab 0.5.0

## Post-roast physical analysis

- Added separate post-roast density storage (`roastedDensityGPerL`).
- Existing pre-roast green density (`densityGPerL`) is preserved unchanged.
- Density method is recorded as `bulk` or `particle`.
- Measurement timestamp is stored so the user can standardize the protocol; the UI explicitly supports the user's ~24 h post-drop measurement workflow.
- Added roast-level reference bands for weight loss: Very Light, Light, Light-Medium, Medium, Medium-Dark, Dark, Very Dark. These are broad working reference bands, not universal standards.
- Added density retention/reduction analysis.
- Estimated bean volume expansion is calculated only for particle/true density, never for bulk density.
- Roast summary now shows the physical analysis and measurement timing.
- Dashboard CSV and PDF include density fields.

## Data safety

Storage schema is migrated from 7 to 8 with nullable/defaulted fields, so existing roast records remain readable. Existing storage hardening/backup logic is retained.

## Build verification

This source package does not contain a Gradle wrapper. The current environment has no `gradle` executable, so a full Android APK build was not claimed here. Core Kotlin roast-math tests were compiled and executed successfully.
