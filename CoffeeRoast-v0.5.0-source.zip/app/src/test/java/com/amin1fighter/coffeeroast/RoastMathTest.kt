package com.amin1fighter.coffeeroast

import org.junit.Assert.*
import org.junit.Test

class RoastMathTest {
    @Test
    fun parsesTime() {
        assertEquals(69, RoastMath.parseTime("1:09"))
        assertNull(RoastMath.parseTime("9:99"))
        assertEquals(0, RoastMath.parseTime("0:00"))
        assertEquals(125, RoastMath.parseTime("2:05"))
    }

    @Test
    fun dtr() {
        assertEquals(20.0, RoastMath.dtr(0, 480, 600)!!, 0.001)
        assertNull(RoastMath.dtr(0, null, 600))
    }

    @Test
    fun weightLoss() {
        assertEquals(12.5, RoastMath.weightLossPercent(200.0, 175.0)!!, 0.001)
        assertNull(RoastMath.weightLossPercent(0.0, 10.0))
    }

    @Test
    fun ror() {
        val l = listOf(TempPoint(0, 100.0), TempPoint(60, 110.0))
        assertEquals(10.0, RoastMath.currentRor(l)!!, 0.001)
    }

    @Test
    fun fahrenheitTemperatureConversion() {
        assertEquals(212.0, RoastMath.celsiusToDisplay(100.0, "F"), 0.001)
        assertEquals(100.0, RoastMath.celsiusToDisplay(100.0, "C"), 0.001)
    }

    @Test
    fun fahrenheitRorConversion() {
        assertEquals(18.0, RoastMath.celsiusRorToDisplay(10.0, "F"), 0.001)
        assertEquals(10.0, RoastMath.celsiusRorToDisplay(10.0, "C"), 0.001)
    }

    @Test
    fun eta() {
        assertEquals(600, RoastMath.etaToTempSec(300, 150.0, 10.0, 200.0))
        assertNull(RoastMath.etaToTempSec(300, 150.0, 0.0, 200.0))
    }

    @Test
    fun phasePercents() {
        val p = RoastMath.phasePercents(0, 240, 480, 600)
        assertEquals(40.0, p.first!!, 0.001)
        assertEquals(40.0, p.second!!, 0.001)
        assertEquals(20.0, p.third!!, 0.001)
    }

    @Test
    fun postRoastDensityAnalysis() {
        assertEquals(50.0, RoastMath.densityRetentionPercent(700.0, 350.0)!!, 0.001)
        assertEquals(50.0, RoastMath.densityReductionPercent(700.0, 350.0)!!, 0.001)
        assertNull(RoastMath.densityReductionPercent(null, 350.0))
    }

    @Test
    fun trueDensityExpansionUsesMassAndDensity() {
        assertEquals(70.0, RoastMath.estimatedVolumeExpansionPercent(200.0, 170.0, 1200.0, 600.0, "particle")!!, 0.001)
        assertNull(RoastMath.estimatedVolumeExpansionPercent(200.0, 170.0, 1200.0, 600.0, "bulk"))
    }

    @Test
    fun weightLossReferenceBands() {
        val medium = RoastMath.weightLossReference("medium")
        assertEquals(15.0, medium.low, 0.001)
        assertEquals(19.0, medium.high, 0.001)
        assertEquals("Medium-Dark", RoastMath.roastLevelLabel("medium_dark"))
    }

    @Test
    fun validateMarkersOk() {
        assertNull(RoastMath.validateMarkers(60, 240, 480, null, 600))
    }

    @Test
    fun validateMarkersRejectsOutOfOrder() {
        assertNotNull(RoastMath.validateMarkers(300, 240, null, null, null))
        assertNotNull(RoastMath.validateMarkers(null, null, 500, null, 400))
    }
}
