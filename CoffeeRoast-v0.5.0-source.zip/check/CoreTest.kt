import com.amin1fighter.coffeeroast.*
fun main() {
    fun a(name:String, actual:Double?, expected:Double) { require(actual != null && kotlin.math.abs(actual-expected)<1e-6) { "$name: $actual != $expected" } }
    a("loss", RoastMath.weightLossPercent(200.0,170.0), 15.0)
    a("retention", RoastMath.densityRetentionPercent(700.0,350.0), 50.0)
    a("reduction", RoastMath.densityReductionPercent(700.0,350.0), 50.0)
    a("expansion", RoastMath.estimatedVolumeExpansionPercent(200.0,170.0,1200.0,600.0,"particle"), 70.0)
    require(RoastMath.estimatedVolumeExpansionPercent(200.0,170.0,700.0,350.0,"bulk") == null)
    require(RoastMath.weightLossReference("medium").low == 15.0)
    println("CORE TESTS PASS")
}
