package com.amin1fighter.coffeeroast

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import kotlin.math.ceil
import kotlin.math.floor

/** Professional roast chart: 30s time grid, 10C temperature grid, BT mandatory, ET optional. */
class RoastChartView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {
    var session: RoastSession? = null
        set(value) { field = value; invalidate() }

    private val btPaint = Paint().apply { color=Color.parseColor("#D84315"); strokeWidth=5f; style=Paint.Style.STROKE; isAntiAlias=true }
    private val etPaint = Paint().apply { color=Color.parseColor("#6D4C41"); strokeWidth=4f; style=Paint.Style.STROKE; isAntiAlias=true }
    private val rorPaint = Paint().apply { color=Color.parseColor("#2E7D32"); strokeWidth=3f; style=Paint.Style.STROKE; isAntiAlias=true }
    private val markerPaint = Paint().apply { color=Color.parseColor("#8D6E63"); strokeWidth=2f; style=Paint.Style.STROKE; isAntiAlias=true }
    private val gridPaint = Paint().apply { color=Color.parseColor("#E8E2DD"); strokeWidth=1f; isAntiAlias=true }
    private val axisPaint = Paint().apply { color=Color.parseColor("#5D4037"); strokeWidth=2f; isAntiAlias=true }
    private val labelPaint = Paint().apply { color=Color.parseColor("#6D4C41"); textSize=18f; isAntiAlias=true }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas); canvas.drawColor(Color.WHITE)
        val s=session ?: return; val log=s.tempLog.sortedBy{it.elapsedSec}; if(log.size<2)return
        val padLeft=58f; val padRight=28f; val padTop=34f; val padBottom=42f
        val w=width-padLeft-padRight; val h=height-padTop-padBottom; if(w<=0||h<=0)return
        val maxTime=ceil(log.last().elapsedSec/30.0).toInt().coerceAtLeast(1)*30
        val allTemps=log.flatMap{listOfNotNull(it.bt,it.et)}
        val minTemp=(floor((allTemps.minOrNull()?:0.0)/10.0)*10.0).coerceAtMost(0.0)
        val maxTemp=(ceil((allTemps.maxOrNull()?:100.0)/10.0)*10.0).coerceAtLeast(minTemp+10.0)
        fun x(sec:Int)=padLeft+(sec.toFloat()/maxTime)*w
        fun y(temp:Double)=padTop+h-((temp-minTemp)/(maxTemp-minTemp)).toFloat()*h

        var t=minTemp
        while(t<=maxTemp+0.1){ val yy=y(t); canvas.drawLine(padLeft,yy,padLeft+w,yy,gridPaint); canvas.drawText("${t.toInt()}°",5f,yy+6f,labelPaint); t+=10.0 }
        var sec=0
        while(sec<=maxTime){ val xx=x(sec); canvas.drawLine(xx,padTop,xx,padTop+h,gridPaint); canvas.drawText(fmtTime(sec),xx-15f,padTop+h+27f,labelPaint); sec+=30 }
        canvas.drawLine(padLeft,padTop,padLeft,padTop+h,axisPaint); canvas.drawLine(padLeft,padTop+h,padLeft+w,padTop+h,axisPaint)

        for(i in 1 until log.size){ val a=log[i-1]; val b=log[i]; canvas.drawLine(x(a.elapsedSec),y(a.bt),x(b.elapsedSec),y(b.bt),btPaint); if(a.et!=null&&b.et!=null)canvas.drawLine(x(a.elapsedSec),y(a.et),x(b.elapsedSec),y(b.et),etPaint) }
        val rors = mutableListOf<Pair<Int, Double>>()
        for (i in log.indices) {
            val ror = RoastMath.currentRor(log.subList(0, i + 1))
            if (ror != null) {
                rors.add(log[i].elapsedSec to ror)
            }
        }

        if (rors.size >= 2) {
            val minRor = 0.0
            val maxRor = maxOf(
                10.0,
                ceil(rors.maxOf { it.second } / 2.0) * 2.0
            )

            fun yr(v: Double): Float {
                return padTop + h -
                    ((v - minRor) / (maxRor - minRor)).toFloat() * h
            }

            for (i in 1 until rors.size) {
                canvas.drawLine(
                    x(rors[i - 1].first),
                    yr(rors[i - 1].second),
                    x(rors[i].first),
                    yr(rors[i].second),
                    rorPaint
                )
            }
        }
        s.dryEndSec?.let{canvas.drawLine(x(it),padTop,x(it),padTop+h,markerPaint)}
        s.firstCrackSec?.let{canvas.drawLine(x(it),padTop,x(it),padTop+h,markerPaint)}
        s.dropSec?.let{canvas.drawLine(x(it),padTop,x(it),padTop+h,markerPaint)}
        btPaint.style=Paint.Style.FILL; canvas.drawText("BT",padLeft+8f,20f,btPaint); btPaint.style=Paint.Style.STROKE
        if(log.any{it.et!=null}){etPaint.style=Paint.Style.FILL;canvas.drawText("ET",padLeft+52f,20f,etPaint);etPaint.style=Paint.Style.STROKE}
        rorPaint.style=Paint.Style.FILL;canvas.drawText("RoR",padLeft+92f,20f,rorPaint);rorPaint.style=Paint.Style.STROKE
    }
    private fun fmtTime(sec:Int):String="${sec/60}:${(sec%60).toString().padStart(2,'0')}"
}
