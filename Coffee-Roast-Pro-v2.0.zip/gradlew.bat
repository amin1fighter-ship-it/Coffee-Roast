@echo off
rem Gradle wrapper script for Windows
gradle %*
