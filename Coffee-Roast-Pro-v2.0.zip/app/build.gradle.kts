plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val customVersionCode = providers.gradleProperty("versionCode").orNull?.toInt() ?: 1

android {
    namespace = "com.amin1fighter.coffeeroast"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.amin1fighter.coffeeroast"
        minSdk = 26
        targetSdk = 35
        versionCode = customVersionCode
        versionName = "1.0.$customVersionCode"
    }

    signingConfigs {
        create("release") {
            val storeFileObj = file("release.keystore")
            if (storeFileObj.exists()) {
                storeFile = storeFileObj
                storePassword = providers.gradleProperty("KEYSTORE_PASSWORD").orNull ?: "coffeeroast123"
                keyAlias = providers.gradleProperty("KEY_ALIAS").orNull ?: "coffeeroast"
                keyPassword = providers.gradleProperty("KEY_PASSWORD").orNull ?: "coffeeroast123"
            }
        }
    }

    buildTypes {
        getByName("release") {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            val storeFileObj = file("release.keystore")
            if (storeFileObj.exists()) {
                signingConfig = signingConfigs.getByName("release")
            } else {
                signingConfig = signingConfigs.getByName("debug")
            }
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    // Standard Android framework classes used
}
