# Coffee Roast Lab v0.5.3

A local-first Android roast logging and analysis app for specialty coffee.

## Analytical model
- **Brew Intent:** Filter / Espresso / Omni / Other; user-selected and never inferred from roast data.
- **Roast Degree:** analyzed separately using weight-loss indication and, when available, roast-color measurement.
- **Development:** analyzed from FC→Drop time, DTR, post-FC RoR and thermal behavior; DTR alone is not a quality verdict.
- **Thermal controls:** Heater/Fan are recorded as control actions. RoR is a temperature slope, not direct energy.
- **Density:** green/roasted density, retention/reduction and true-density expansion when the method supports it. Bulk density is not treated as true bean-volume expansion.
- **Brew performance/Cupping:** kept separate from roast-curve inference.

## Data safety
Storage is local-first and schema 9. Existing v0.5.0/v0.5.1 data remains readable, with migration for old `specialty` intent and missing initial control events.

## Exports
Artisan-compatible TSV, CSV, dashboard CSV, PDF and JSON backup are supported.

## Build
Gradle 8.9 + JDK 17. Version `0.5.3` / versionCode `50300`.
