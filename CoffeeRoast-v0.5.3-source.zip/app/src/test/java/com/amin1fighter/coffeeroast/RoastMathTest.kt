package com.amin1fighter.coffeeroast

import org.junit.Assert.*
import org.junit.Test

class RoastMathTest {
    @Test
    fun parsesTime() {
        assertEquals(69, RoastMath.parseTime("1:09"))
        assertNull(RoastMath.parseTime("9:99"))
        assertEquals(0, RoastMath.parseTime("0:00"))
        assertEquals(125, RoastMath.parseTime("2:05"))
    }

    @Test
    fun dtr() {
        assertEquals(20.0, RoastMath.dtr(0, 480, 600)!!, 0.001)
        assertNull(RoastMath.dtr(0, null, 600))
    }

    @Test
    fun weightLoss() {
        assertEquals(12.5, RoastMath.weightLossPercent(200.0, 175.0)!!, 0.001)
        assertNull(RoastMath.weightLossPercent(0.0, 10.0))
    }

    @Test
    fun ror() {
        val l = listOf(TempPoint(0, 100.0), TempPoint(60, 110.0))
        assertEquals(10.0, RoastMath.currentRor(l)!!, 0.001)
    }

    @Test
    fun fahrenheitTemperatureConversion() {
        assertEquals(212.0, RoastMath.celsiusToDisplay(100.0, "F"), 0.001)
        assertEquals(100.0, RoastMath.celsiusToDisplay(100.0, "C"), 0.001)
    }

    @Test
    fun fahrenheitRorConversion() {
        assertEquals(18.0, RoastMath.celsiusRorToDisplay(10.0, "F"), 0.001)
        assertEquals(10.0, RoastMath.celsiusRorToDisplay(10.0, "C"), 0.001)
    }

    @Test
    fun eta() {
        assertEquals(600, RoastMath.etaToTempSec(300, 150.0, 10.0, 200.0))
        assertNull(RoastMath.etaToTempSec(300, 150.0, 0.0, 200.0))
    }

    @Test
    fun phasePercents() {
        val p = RoastMath.phasePercents(0, 240, 480, 600)
        assertEquals(40.0, p.first!!, 0.001)
        assertEquals(40.0, p.second!!, 0.001)
        assertEquals(20.0, p.third!!, 0.001)
    }

    @Test
    fun postRoastDensityAnalysis() {
        assertEquals(50.0, RoastMath.densityRetentionPercent(700.0, 350.0)!!, 0.001)
        assertEquals(50.0, RoastMath.densityReductionPercent(700.0, 350.0)!!, 0.001)
        assertNull(RoastMath.densityReductionPercent(null, 350.0))
    }

    @Test
    fun trueDensityExpansionUsesMassAndDensity() {
        assertEquals(70.0, RoastMath.estimatedVolumeExpansionPercent(200.0, 170.0, 1200.0, 600.0, "particle")!!, 0.001)
        assertNull(RoastMath.estimatedVolumeExpansionPercent(200.0, 170.0, 1200.0, 600.0, "bulk"))
    }

    @Test
    fun weightLossReferenceBands() {
        val medium = RoastMath.weightLossReference("medium")
        assertEquals(15.0, medium.low, 0.001)
        assertEquals(19.0, medium.high, 0.001)
        assertEquals("Medium-Dark", RoastMath.roastLevelLabel("medium_dark"))
    }

    @Test
    fun validateMarkersOk() {
        assertNull(RoastMath.validateMarkers(60, 240, 480, null, 600))
    }

    @Test
    fun validateMarkersRejectsOutOfOrder() {
        assertNotNull(RoastMath.validateMarkers(300, 240, null, null, null))
        assertNotNull(RoastMath.validateMarkers(null, null, 500, null, 400))
    }
    @Test
    fun brewIntentIsNotInferredFromRoastData() {
        assertEquals("Espresso", RoastMath.styleLabel("espresso"))
        assertEquals("Filter", RoastMath.styleLabel("filter"))
        assertEquals("Omni", RoastMath.styleLabel("omni"))
        assertEquals("Other", RoastMath.styleLabel("other"))
        assertEquals("Not recorded", RoastMath.styleLabel("not_recorded"))
    }

    @Test
    fun etCoverageAndControlResponse() {
        val r = RoastSession(1, 1, 1, 1, 150.0, startFan = 12, startHeater = 13)
        r.tempLog.addAll(listOf(
            TempPoint(0, 30.0, 32.0),
            TempPoint(30, 50.0, null),
            TempPoint(60, 70.0, 72.0),
            TempPoint(90, 82.0, null),
            TempPoint(120, 95.0, 96.0),
            TempPoint(150, 106.0, null),
            TempPoint(180, 116.0, 117.0)
        ))
        r.fanChanges.add(SettingChange(60, 70.0, 10))
        assertEquals(57.142857, RoastMath.etCoveragePercent(r.tempLog)!!, 0.001)
        assertEquals(1, RoastMath.controlThermalResponses(r).size)
    }

    @Test
    fun bulkDensityNeverProducesTrueExpansion() {
        assertNull(RoastMath.estimatedVolumeExpansionPercent(150.0, 130.0, 680.0, 360.0, "bulk"))
    }

}
