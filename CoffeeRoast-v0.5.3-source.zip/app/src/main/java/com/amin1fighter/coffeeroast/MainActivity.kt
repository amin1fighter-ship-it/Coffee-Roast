package com.amin1fighter.coffeeroast

import android.Manifest
import android.app.AlertDialog
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.drawable.GradientDrawable
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.WindowManager
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {
    private lateinit var root: FrameLayout
    private val h = Handler(Looper.getMainLooper())
    private var ticker: Runnable? = null
    private var notificationTicker: Runnable? = null
    private var current: RoastSession? = null
    private var editingTimer: TextView? = null
    private var chart: RoastChartView? = null

    private val restoreLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@registerForActivityResult
        try {
            val f = File(cacheDir, "restore.zip")
            contentResolver.openInputStream(uri)!!.use { input ->
                f.outputStream().use { input.copyTo(it) }
            }
            Storage.importBackup(this, f)
            toast("Backup restored")
            showHome()
        } catch (e: Exception) {
            toast("Restore failed: ${e.message ?: "error"}")
            File(filesDir, "coffeeroast_import_error.log").writeText(e.stackTraceToString())
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        installCrashLogger()
        try {
            Storage.init(this)
        } catch (e: Exception) {
            try { File(filesDir, "coffeeroast_init_error.log").writeText(e.stackTraceToString()) } catch (_: Exception) {}
        }
        try { applyTheme() } catch (_: Exception) {}
        try { createNotificationChannel() } catch (_: Exception) {}
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 77)
        }
        root = FrameLayout(this)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }
        setContentView(root)
        if (!recoverLive()) showHome()
    }

    override fun onPause() {
        super.onPause()
        // Keep a lightweight ticker so live notification time stays current.
        current?.let {
            if (!it.isComplete) {
                saveSafe("pause")
                showRoastNotification(it)
                startNotificationTicker(it)
            } else {
                stopTicker()
                stopNotificationTicker()
            }
        } ?: run {
            stopTicker()
            stopNotificationTicker()
        }
    }

    override fun onResume() {
        super.onResume()
        stopNotificationTicker()
        cancelRoastNotification()
        current?.let {
            if (!it.isComplete && root.childCount > 0 && editingTimer != null) {
                startTicker(it)
            }
        }
    }

    override fun onDestroy() {
        stopTicker()
        super.onDestroy()
    }

    // Coffee Grind Analyzer / Coffee Roast Lab shared visual language.
    private val roastBg = Color.parseColor("#0D0B09")
    private val roastSurface = Color.parseColor("#171310")
    private val roastSurface2 = Color.parseColor("#211B15")
    private val roastBorder = Color.parseColor("#4A3920")
    private val roastGold = Color.parseColor("#D89A2B")
    private val roastGoldBright = Color.parseColor("#F0B84B")
    private val roastText = Color.parseColor("#FFF8E8")
    private val roastMuted = Color.parseColor("#B9ADA0")

    private fun dp(x: Int) = (x * resources.displayMetrics.density).roundToInt()

    private fun rounded(fill: Int, stroke: Int = Color.TRANSPARENT, strokeWidth: Int = 0, radius: Int = 14): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(radius).toFloat()
            setColor(fill)
            if (stroke != Color.TRANSPARENT && strokeWidth > 0) setStroke(dp(strokeWidth), stroke)
        }

    private fun screen(title: String): LinearLayout {
        root.removeAllViews()
        editingTimer = null
        val sv = ScrollView(this)
        val ll = LinearLayout(this)
        ll.orientation = LinearLayout.VERTICAL
        ll.setPadding(dp(16), dp(18), dp(16), dp(30))
        sv.setBackgroundColor(roastBg)
        ll.setBackgroundColor(roastBg)
        sv.addView(ll)
        root.addView(sv)
        ll.addView(tv(title, 24f, true).apply {
            setTextColor(roastText)
            setPadding(0, dp(4), 0, dp(2))
        })
        ll.addView(android.view.View(this).apply {
            setBackgroundColor(roastBorder)
            layoutParams = LinearLayout.LayoutParams(-1, dp(1)).apply {
                topMargin = dp(8)
                bottomMargin = dp(10)
            }
        })
        return ll
    }

    private fun tv(s: String, size: Float = 16f, bold: Boolean = false) = TextView(this).apply {
        text = s
        textSize = size
        setTypeface(null, if (bold) 1 else 0)
        setTextColor(if (bold) roastText else roastMuted)
        setPadding(0, dp(6), 0, dp(6))
    }

    private fun sub(s: String) = tv(s, 14f, false)

    private fun btn(s: String, f: () -> Unit) = Button(this).apply {
        text = s
        setAllCaps(false)
        textSize = 15f
        setTextColor(roastGoldBright)
        background = rounded(roastSurface, roastBorder, 1, 14)
        backgroundTintList = null
        stateListAnimator = null
        elevation = 0f
        minHeight = 0
        minimumHeight = 0
        setPadding(dp(16), 0, dp(16), 0)
        setOnClickListener { f() }
        layoutParams = LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(7) }
    }

    private fun primaryBtn(s: String, f: () -> Unit) = Button(this).apply {
        text = s
        setAllCaps(false)
        textSize = 15f
        setTextColor(Color.parseColor("#241A0B"))
        background = rounded(roastGold, Color.parseColor("#E6A936"), 1, 14)
        backgroundTintList = null
        stateListAnimator = null
        elevation = 0f
        minHeight = 0
        minimumHeight = 0
        setOnClickListener { f() }
        layoutParams = LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(9) }
    }

    private fun input(hint: String, type: Int = 1) = EditText(this).apply {
        this.hint = hint
        inputType = type
        textSize = 15f
        setTextColor(roastText)
        setHintTextColor(Color.parseColor("#80766D"))
        background = rounded(roastSurface2, roastBorder, 1, 12)
        backgroundTintList = null
        setPadding(dp(14), dp(4), dp(14), dp(4))
        layoutParams = LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(6) }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    /** Persist and warn the user if disk write failed. */
    private fun saveSafe(label: String = "save"): Boolean {
        return try {
            val ok = Storage.save()
            if (!ok) toast("ذخیره نشد ($label): ${Storage.lastStatus}")
            ok
        } catch (e: Exception) {
            toast("خطای ذخیره ($label): ${e.message}")
            try { File(filesDir, "coffeeroast_save_error.log").writeText(e.stackTraceToString()) } catch (_: Exception) {}
            false
        }
    }

    /** Convert display-unit temperature to storage Celsius. */
    private fun toCelsius(display: Double): Double =
        if (Storage.settings.temperatureUnit == "F") (display - 32.0) * 5.0 / 9.0 else display

    /** Convert storage Celsius to display unit. */
    private fun fromCelsius(c: Double): Double =
        if (Storage.settings.temperatureUnit == "F") c * 9.0 / 5.0 + 32.0 else c

    private fun unitLabel() = if (Storage.settings.temperatureUnit == "F") "°F" else "°C"

    private fun showHome() {
        stopTicker()
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        // If a live roast is in progress, keep the notification clock running
        val live = Storage.roasts.filter { !it.isComplete }.maxByOrNull { it.startTimeMillis }
        if (live != null) {
            current = live
            startNotificationTicker(live)
            showRoastNotification(live)
        } else {
            stopNotificationTicker()
            cancelRoastNotification()
        }
        val l = screen("☕  COFFEE ROAST LAB")
        l.addView(sub("Precision in Every Roast  ·  v0.5.3"))
        l.addView(sub(Storage.dataSummary()))
        if (live != null) {
            l.addView(btn("▶ Resume LIVE roast #${live.globalRoastNumber}") {
                current = live
                showLive(live)
            })
        }
        l.addView(btn("Roasts") { showRoasts() })
        l.addView(btn("Green Beans") { showBeans() })
        l.addView(btn("Roasted Inventory / Resting") { showInventory() })
        l.addView(btn("Dashboard / Statistics") { showDashboard() })
        l.addView(btn("Tools & Calculators") { showTools() })
        l.addView(btn("Settings") { showSettings() })
        l.addView(btn("Backup / Restore") { showBackup() })
        l.addView(btn("Import legacy roast") { legacyDialog() })
    }

    private fun showBeans() {
        val l = screen("Green Beans")
        Storage.beans.forEach { b ->
            val box = LinearLayout(this)
            box.orientation = LinearLayout.VERTICAL
            box.setPadding(dp(10), dp(8), dp(10), dp(8))
            box.addView(tv(b.name, 18f, true))
            box.addView(sub("${b.origin.ifBlank { "—" }} • ${b.process.ifBlank { "—" }} • ${fmt(b.stockGrams)} g"))
            box.addView(
                sub(
                    "${b.variety.ifBlank { "variety —" }} • ${b.supplier.ifBlank { "supplier —" }} • " +
                        (b.altitudeMasl?.let { "${it.toInt()} masl" } ?: "altitude —")
                )
            )
            box.addView(btn("Edit / Delete") { beanDialog(b) })
            l.addView(box)
        }
        l.addView(btn("+ Add bean") { beanDialog(null) })
        l.addView(btn("Back") { showHome() })
    }

    private fun beanDialog(old: GreenBean?) {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        val fields = listOf(
            "Name", "Origin", "Process", "Notes", "Supplier", "Purchase date",
            "Price", "Harvest year", "Altitude masl", "Variety", "Storage location", "Stock grams"
        )
        val es = fields.map { input(it, if (it in listOf("Price", "Altitude masl", "Stock grams")) 3 else 1) }
        es.forEach { c.addView(it) }
        old?.let {
            listOf(
                it.name, it.origin, it.process, it.notes, it.supplier, it.purchaseDate,
                it.price.toString(), it.harvestYear, it.altitudeMasl?.toString() ?: "",
                it.variety, it.storageLocation, it.stockGrams.toString()
            ).zip(es).forEach { (v, e) -> e.setText(v) }
        }
        val scroll = ScrollView(this).apply { addView(c) }
        AlertDialog.Builder(this)
            .setTitle(if (old == null) "Add bean" else "Edit bean")
            .setView(scroll)
            .setPositiveButton("Save") { _, _ ->
                val name = es[0].text.toString().trim()
                if (name.isEmpty()) {
                    toast("Name required")
                    return@setPositiveButton
                }
                val b = old ?: GreenBean(Storage.newBeanId(), name)
                b.name = name
                b.origin = es[1].text.toString()
                b.process = es[2].text.toString()
                b.notes = es[3].text.toString()
                b.supplier = es[4].text.toString()
                b.purchaseDate = es[5].text.toString()
                b.price = es[6].text.toString().toDoubleOrNull() ?: 0.0
                b.harvestYear = es[7].text.toString()
                b.altitudeMasl = es[8].text.toString().toDoubleOrNull()
                b.variety = es[9].text.toString()
                b.storageLocation = es[10].text.toString()
                b.stockGrams = es[11].text.toString().toDoubleOrNull() ?: 0.0
                if (old == null) { if (!Storage.addBean(b)) toast("ذخیره نشد: ${Storage.lastStatus}") } else saveSafe()
                showBeans()
            }
            .setNegativeButton("Cancel", null)
            .apply {
                if (old != null) {
                    setNeutralButton("Delete") { _, _ ->
                        val n = Storage.roasts.count { it.beanId == old.id }
                        if (n > 0) {
                            AlertDialog.Builder(this@MainActivity)
                                .setMessage(
                                    "This bean has $n roast(s). Deleting removes those roasts too. " +
                                        "Incomplete roasts will restore green stock."
                                )
                                .setPositiveButton("Delete all") { _, _ ->
                                    if (!Storage.deleteBean(old.id)) toast("حذف ذخیره نشد: ${Storage.lastStatus}")
                                    showBeans()
                                }
                                .setNegativeButton("Cancel", null)
                                .show()
                        } else {
                            if (!Storage.deleteBean(old.id)) toast("حذف ذخیره نشد: ${Storage.lastStatus}")
                            showBeans()
                        }
                    }
                }
            }
            .show()
    }

    private fun showRoasts() {
        val l = screen("Roasts")
        Storage.roasts.sortedByDescending { it.globalRoastNumber }.forEach { r ->
            val b = Storage.beanById(r.beanId)
            val loss = r.roastedWeightG?.let { x -> RoastMath.weightLossPercent(r.greenWeightG, x) }
            l.addView(
                btn(
                    "#${r.globalRoastNumber} ${b?.name ?: "?"} • batch ${r.beanBatchNumber} • " +
                        "${if (r.isComplete) "complete" else "LIVE"} • loss ${loss?.let { "%.1f%%".format(it) } ?: "—"}"
                ) {
                    current = r
                    if (r.isComplete) showSummary(r) else showLive(r)
                }
            )
        }
        l.addView(btn("+ Start roast") {
            if (Storage.beans.isEmpty()) showBeans() else setupRoast()
        })
        l.addView(btn("Back") { showHome() })
    }

    private fun setupRoast() {
        val l = screen("New Roast")
        val beans = Storage.beans.toList()
        if (beans.isEmpty()) {
            toast("Add a green bean first")
            showBeans()
            return
        }
        val sp = Spinner(this)
        sp.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item,
            beans.map { "${it.name} (${fmt(it.stockGrams)}g)" }
        )
        l.addView(sub("Bean"))
        l.addView(sp)
        val styleSp = Spinner(this)
        styleSp.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item,
            arrayOf("Filter", "Espresso", "Omni", "Other")
        )
        l.addView(sub("Target roast style"))
        l.addView(styleSp)
        val levelSp = Spinner(this)
        val levelCodes = listOf("very_light", "light", "light_medium", "medium", "medium_dark", "dark", "very_dark")
        levelSp.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item,
            levelCodes.map { RoastMath.roastLevelLabel(it) }
        )
        levelSp.setSelection(3)
        l.addView(sub("Reference roast level for post-roast analysis"))
        l.addView(levelSp)
        val g = input("Green weight g", 3)
        val d = input("Density g/L optional", 3)
        val fan = input("Start fan", 3)
        val heat = input("Start heater", 3)
        val charge = input("Charge BT ${unitLabel()}", 3)
        val roaster = input("Roaster / machine name", 1)
        l.addView(g)
        l.addView(d)
        val dropHint = tv("", 14f, false)
        fun updateDropHint() {
            val dens = d.text.toString().trim().replace(',', '.').toDoubleOrNull()
            val bean = beans.getOrNull(sp.selectedItemPosition)
            val process = bean?.process ?: ""
            dropHint.text = if (dens != null && dens > 0.0) {
                val (lo, hi) = RoastMath.suggestedDropRangeC(dens, process)
                "Working drop reference: ${"%.0f".format(lo)}–${"%.0f".format(hi)} °C • machine/reference aid only"
            } else {
                "Working drop reference appears after green density is entered"
            }
        }
        d.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) { updateDropHint() }
        })
        sp.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, v: android.view.View?, pos: Int, id: Long) {
                updateDropHint()
            }
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        }
        updateDropHint()
        l.addView(dropHint)
        l.addView(fan)
        l.addView(heat)
        l.addView(charge)
        l.addView(roaster)
        l.addView(primaryBtn("START ROAST") {
            try {
                val b = beans.getOrNull(sp.selectedItemPosition) ?: run {
                    toast("Select a bean")
                    return@btn
                }
                val gw = g.text.toString().trim().replace(',', '.').toDoubleOrNull() ?: 0.0
                if (gw <= 0) {
                    toast("Green weight must be greater than 0")
                    return@btn
                }
                if (gw > b.stockGrams + 0.0001) {
                    toast("Not enough green stock")
                    return@btn
                }
                val chargeDisplay = charge.text.toString().trim().replace(',', '.').toDoubleOrNull()
                val cb = chargeDisplay?.let { toCelsius(it) }
                if (cb != null && (cb < 0.0 || cb > 300.0)) {
                    toast("Charge BT must be 0–300°C")
                    return@btn
                }
                val nowWall = System.currentTimeMillis()
                val nowMono = SystemClock.elapsedRealtime()
                val styleCode = when (styleSp.selectedItemPosition) {
                    1 -> "espresso"
                    2 -> "omni"
                    3 -> "other"
                    else -> "filter"
                }
                val r = RoastSession(
                    Storage.newRoastId(),
                    Storage.allocateGlobalRoastNumber(),
                    b.id,
                    Storage.nextBatch(b),
                    gw,
                    densityGPerL = d.text.toString().trim().replace(',', '.').toDoubleOrNull(),
                    startFan = fan.text.toString().toIntOrNull() ?: 0,
                    startHeater = heat.text.toString().toIntOrNull() ?: 0,
                    startTimeMillis = nowWall,
                    startElapsedRealtime = nowMono,
                    stockReserved = true,
                    roasterName = roaster.text.toString().trim(),
                    targetStyle = styleCode,
                    roastLevel = levelCodes.getOrElse(levelSp.selectedItemPosition) { "medium" }
                )
                val initialBt = cb ?: 0.0
                r.tempLog.add(TempPoint(0, initialBt, null))
                // Persist the actual starting control state as a timeline event.
                // Import already creates these 0:00 entries; live roast must do the same.
                r.fanChanges.add(SettingChange(0, initialBt, r.startFan))
                r.heaterChanges.add(SettingChange(0, initialBt, r.startHeater))
                b.stockGrams -= gw
                b.totalBatches += 1
                if (!Storage.addRoast(r)) {
                    // Storage.addRoast is transactional; restore the in-memory inventory
                    // if the new roast could not be persisted.
                    b.stockGrams += gw
                    b.totalBatches = (Storage.roasts.count { it.beanId == b.id })
                    toast("ذخیره رست نشد: ${Storage.lastStatus}")
                    return@btn
                }
                current = r
                showLive(r)
            } catch (e: Exception) {
                toast("Could not start roast: ${e.message ?: "unknown error"}")
                File(filesDir, "coffeeroast_crash.log").writeText(e.stackTraceToString())
            }
        })
        l.addView(btn("Back") { showRoasts() })
    }

    /** Returns true if a live roast UI was opened. */
    private fun recoverLive(): Boolean {
        val r = Storage.roasts.filter { !it.isComplete }.maxByOrNull { it.startTimeMillis } ?: return false
        // If monotonic base is missing (old data), re-anchor from wall clock so elapsed stays continuous.
        if (r.startElapsedRealtime <= 0L && r.startTimeMillis > 0L) {
            val wallElapsedSec = ((System.currentTimeMillis() - r.startTimeMillis) / 1000).coerceAtLeast(0)
            r.startElapsedRealtime = SystemClock.elapsedRealtime() - wallElapsedSec * 1000L
            saveSafe()
        }
        current = r
        showLive(r)
        return true
    }

    /** Monotonic elapsed seconds since charge. Falls back to temp log for historical imports. */
    private fun elapsed(r: RoastSession): Int {
        if (r.startElapsedRealtime > 0L) {
            return ((SystemClock.elapsedRealtime() - r.startElapsedRealtime) / 1000).toInt().coerceAtLeast(0)
        }
        if (!r.isComplete && r.startTimeMillis > 0L) {
            return ((System.currentTimeMillis() - r.startTimeMillis) / 1000).toInt().coerceAtLeast(0)
        }
        return r.tempLog.maxOfOrNull { it.elapsedSec } ?: 0
    }

    private fun startTicker(r: RoastSession, refresh: () -> Unit = {}) {
        stopTicker()
        val run = object : Runnable {
            override fun run() {
                val sec = elapsed(r)
                editingTimer?.text = fmtTime(sec)
                refresh()
                if (sec > 0 && sec % 30 == 0) {
                    try {
                        saveSafe()
                    } catch (e: Exception) {
                        File(filesDir, "coffeeroast_save_error.log").writeText(e.stackTraceToString())
                    }
                }
                ticker = this
                h.postDelayed(this, 1000)
            }
        }
        ticker = run
        h.post(run)
    }

    private fun stopTicker() {
        ticker?.let { h.removeCallbacks(it) }
        ticker = null
    }

    private fun startNotificationTicker(r: RoastSession) {
        stopNotificationTicker()
        val run = object : Runnable {
            override fun run() {
                if (r.isComplete) {
                    stopNotificationTicker()
                    cancelRoastNotification()
                    return
                }
                showRoastNotification(r)
                notificationTicker = this
                h.postDelayed(this, 1000)
            }
        }
        notificationTicker = run
        h.post(run)
    }

    private fun stopNotificationTicker() {
        notificationTicker?.let { h.removeCallbacks(it) }
        notificationTicker = null
    }

    private fun setMarker(r: RoastSession, kind: String) {
        val sec = elapsed(r)
        val tp = if (kind == "TP") sec else r.turningPointSec
        val de = if (kind == "DE") sec else r.dryEndSec
        val fc = if (kind == "FC") sec else r.firstCrackSec
        val sc = if (kind == "SC") sec else r.secondCrackSec
        val drop = if (kind == "DROP") sec else r.dropSec
        val err = RoastMath.validateMarkers(tp, de, fc, sc, drop)
        if (err != null) {
            toast(err)
            return
        }
        when (kind) {
            "TP" -> r.turningPointSec = sec
            "DE" -> r.dryEndSec = sec
            "FC" -> r.firstCrackSec = sec
            "SC" -> r.secondCrackSec = sec
            "DROP" -> r.dropSec = sec
        }
        saveSafe()
        haptic()
    }

    /**
     * Drop is special because the BT sensor is not directly connected to the app.
     * Capture the real drop timestamp FIRST, then ask for the final BT. The time
     * spent typing the temperature must never be added to the roast duration.
     */
    private fun dropDialog(r: RoastSession, onDone: () -> Unit) {
        val dropSec = elapsed(r)
        val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val bt = input("Final BT ${unitLabel()}", 3)
        val lastBt = r.tempLog.maxByOrNull { it.elapsedSec }?.bt
        if (lastBt != null) bt.setText("%.1f".format(fromCelsius(lastBt)))
        c.addView(tv("Drop time: ${fmtTime(dropSec)} (captured now)", 16f, true))
        c.addView(sub("Enter the actual BT at the moment you removed the beans."))
        c.addView(bt)
        AlertDialog.Builder(this)
            .setTitle("Record Drop")
            .setView(c)
            .setPositiveButton("SAVE DROP") { _, _ ->
                val display = bt.text.toString().trim().replace(",", ".").toDoubleOrNull()
                if (display == null) {
                    toast("Enter the final BT")
                    return@setPositiveButton
                }
                val btC = toCelsius(display)
                if (btC !in 0.0..300.0) {
                    toast("Temperature must be 0–300°C equivalent")
                    return@setPositiveButton
                }

                val err = RoastMath.validateMarkers(
                    r.turningPointSec, r.dryEndSec, r.firstCrackSec, r.secondCrackSec, dropSec
                )
                if (err != null) {
                    toast(err)
                    return@setPositiveButton
                }

                // The final BT is a real manual observation at the exact captured drop time.
                r.dropSec = dropSec
                r.tempLog.removeAll { it.elapsedSec == dropSec }
                r.tempLog.add(TempPoint(dropSec, btC, null))
                r.tempLog.sortBy { it.elapsedSec }
                if (!saveSafe("drop")) return@setPositiveButton
                haptic()
                onDone()
            }
            .setNegativeButton("CANCEL", null)
            .show()
    }

    private fun showLive(r: RoastSession) {
        stopTicker()
        stopNotificationTicker()
        cancelRoastNotification()
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val l = screen("LIVE ROAST #${r.globalRoastNumber}")
        editingTimer = tv(fmtTime(elapsed(r)), 34f, true)
        l.addView(editingTimer)
        val b = Storage.beanById(r.beanId)
        l.addView(
            sub(
                "${b?.name ?: "?"} • ${r.roasterName.ifBlank { "roaster —" }} • " +
                    "Temperature log every ${Storage.settings.logIntervalSec}s"
            )
        )

        val live = tv("", 26f, true)
        l.addView(live)
        val chartView = RoastChartView(this).apply { session = r }
        chartView.layoutParams = LinearLayout.LayoutParams(-1, dp(320))
        l.addView(chartView)

        val logContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        l.addView(tv("Temperature log — edit any past interval point", 17f, true))
        l.addView(logContainer)

        fun redrawLog() {
            logContainer.removeAllViews()
            val now = elapsed(r)
            val interval = Storage.settings.logIntervalSec.coerceIn(5, 300)
            val maxSlot = (now / interval) * interval
            val existing = r.tempLog.associateBy { it.elapsedSec }
            val times = linkedSetOf<Int>()
            var sec = 0
            while (sec <= maxSlot) {
                times.add(sec)
                sec += interval
            }
            // Keep every manually entered point (e.g. 4:15) even if it is not on the interval grid
            r.tempLog.forEach { p ->
                if (p.elapsedSec >= 0) times.add(p.elapsedSec)
            }
            times.sorted().forEach { tSec ->
                addTempRow(logContainer, r, tSec, existing[tSec], chartView) { redrawLog() }
            }
        }

        var lastRenderedSlot = -1
        var lastLogSize = -1
        fun refresh() {
            val last = r.tempLog.maxByOrNull { it.elapsedSec }
            val now = elapsed(r)
            val rr = RoastMath.predictionRor(r.tempLog)
            val btNow = last?.bt
            val etaDE = btNow?.let { RoastMath.etaToTempSec(now, it, rr, Storage.settings.dryEndTargetC) }
            val etaFC = btNow?.let { RoastMath.etaToTempSec(now, it, rr, Storage.settings.firstCrackTargetC) }
            val etaDrop = btNow?.let { RoastMath.etaToTempSec(now, it, rr, Storage.settings.dropTargetC) }
            val displayRor = rr?.let { RoastMath.celsiusRorToDisplay(it, Storage.settings.temperatureUnit) }
            val displayRorUnit = if (Storage.settings.temperatureUnit == "F") "°F/min" else "°C/min"
            live.text =
                "BT  ${btNow?.let { temp(it) } ?: "—"}     ET  ${last?.et?.let { temp(it) } ?: "—"}\n" +
                    "RoR ${displayRor?.let { "%.2f".format(it) } ?: "—"} $displayRorUnit  " +
                    "${if (rr != null && rr < Storage.settings.lowRorWarning) "⚠ LOW RoR" else ""}\n" +
                    "DE ${etaDE?.let { fmtTime(it) } ?: "—"}     FC ${etaFC?.let { fmtTime(it) } ?: "—"}     " +
                    "DROP ${etaDrop?.let { fmtTime(it) } ?: "—"}\n" +
                    "ETA uses median RoR from last 30/60/90s"
            chartView.invalidate()
            editingTimer?.text = fmtTime(now)
            val interval = Storage.settings.logIntervalSec.coerceIn(5, 300)
            val slot = (now / interval) * interval
            // Rebuild rows when the interval advances OR log size changed (manual sample)
            val logSize = r.tempLog.size
            if (slot != lastRenderedSlot || logSize != lastLogSize) {
                lastRenderedSlot = slot
                lastLogSize = logSize
                redrawLog()
            }
        }

        l.addView(btn("Add / edit current temperature") {
            sampleDialog(r) {
                redrawLog()
                refresh()
            }
        })
        l.addView(btn("Turning Point") {
            setMarker(r, "TP")
            refresh()
        })
        l.addView(btn("DRY END") {
            setMarker(r, "DE")
            refresh()
        })
        l.addView(btn("FIRST CRACK") {
            setMarker(r, "FC")
            refresh()
        })
        l.addView(btn("SECOND CRACK") {
            setMarker(r, "SC")
            refresh()
        })
        l.addView(btn("Fan / Heater change") {
            changeDialog(r) {
                redrawLog()
                refresh()
            }
        })
        l.addView(btn("Roast notes") { notesDialog(r) })
        l.addView(primaryBtn("END ROAST / DROP — SAVE NOW") {
            // Capture the real ending time before asking for the manual final BT.
            dropDialog(r) {
                r.isComplete = true
                try {
                    if (!saveSafe("complete roast")) {
                        r.isComplete = false
                        return@dropDialog
                    }
                    toast("Roast #${r.globalRoastNumber} saved")
                    stopTicker()
                    stopNotificationTicker()
                    cancelRoastNotification()
                    window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    showSummary(r)
                } catch (e: Exception) {
                    r.isComplete = false
                    toast("SAVE FAILED — roast kept in memory: ${e.message ?: "storage error"}")
                    File(filesDir, "coffeeroast_save_error.log").writeText(e.stackTraceToString())
                }
            }
        })
        l.addView(btn("Back to home (roast continues)") {
            try {
                saveSafe()
            } catch (_: Exception) {
            }
            showHome()
        })
        redrawLog()
        lastLogSize = r.tempLog.size
        refresh()
        startTicker(r, ::refresh)
    }

    private fun addTempRow(
        container: LinearLayout,
        r: RoastSession,
        sec: Int,
        p: TempPoint?,
        chart: RoastChartView,
        onSaved: () -> Unit
    ) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val time = tv(fmtTime(sec), 16f, true)
        time.layoutParams = LinearLayout.LayoutParams(dp(62), -2)
        val bt = input("BT ${unitLabel()}", 3)
        val et = input("ET ${unitLabel()}", 3)
        bt.setText(p?.bt?.let { "%.1f".format(fromCelsius(it)) } ?: "")
        et.setText(p?.et?.let { "%.1f".format(fromCelsius(it)) } ?: "")
        bt.layoutParams = LinearLayout.LayoutParams(0, dp(52), 1f)
        et.layoutParams = LinearLayout.LayoutParams(0, dp(52), 1f)
        val save = btn("Save") {
            val bvDisplay = bt.text.toString().trim().replace(",", ".").toDoubleOrNull()
            val evDisplay = et.text.toString().trim().replace(",", ".").toDoubleOrNull()
            if (bvDisplay == null) {
                toast("BT is required for ${fmtTime(sec)}")
                return@btn
            }
            val bv = toCelsius(bvDisplay)
            val ev = evDisplay?.let { toCelsius(it) }
            if (bv !in 0.0..300.0 || (ev != null && ev !in 0.0..300.0)) {
                toast("Temperature must be 0–300°C equivalent")
                return@btn
            }
            r.tempLog.removeAll { it.elapsedSec == sec }
            r.tempLog.add(TempPoint(sec, bv, ev))
            r.tempLog.sortBy { it.elapsedSec }
            saveSafe()
            chart.invalidate()
            onSaved()
        }
        save.layoutParams = LinearLayout.LayoutParams(dp(62), dp(52))
        row.addView(time)
        row.addView(bt)
        row.addView(et)
        row.addView(save)
        container.addView(row)
    }

    private fun sampleDialog(r: RoastSession, onSaved: () -> Unit) {
        val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val bt = input("BT ${unitLabel()}", 3)
        val et = input("ET ${unitLabel()} optional", 3)
        val t = input("Elapsed mm:ss", 1)
        t.setText(fmtTime(elapsed(r)))
        c.addView(bt)
        c.addView(et)
        c.addView(t)
        AlertDialog.Builder(this)
            .setTitle("Add / edit temperature")
            .setView(c)
            .setPositiveButton("Save") { _, _ ->
                val sec = RoastMath.parseTime(t.text.toString()) ?: return@setPositiveButton
                val vDisplay = bt.text.toString().trim().replace(",", ".").toDoubleOrNull()
                val eDisplay = et.text.toString().trim().replace(",", ".").toDoubleOrNull()
                if (vDisplay == null) {
                    toast("Invalid temperature")
                    return@setPositiveButton
                }
                val v = toCelsius(vDisplay)
                val e = eDisplay?.let { toCelsius(it) }
                if (v !in 0.0..300.0 || (e != null && e !in 0.0..300.0)) {
                    toast("Temperature must be 0–300°C equivalent")
                    return@setPositiveButton
                }
                r.tempLog.removeAll { it.elapsedSec == sec }
                r.tempLog.add(TempPoint(sec, v, e))
                r.tempLog.sortBy { it.elapsedSec }
                saveSafe()
                onSaved()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun changeDialog(r: RoastSession, onSaved: () -> Unit) {
        val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val type = Spinner(this)
        type.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, arrayOf("Fan", "Heater")
        )
        val level = input("Level", 2)
        val time = input("Elapsed mm:ss", 1)
        time.setText(fmtTime(elapsed(r)))
        c.addView(sub("Change is recorded separately and plotted on the roast graph"))
        c.addView(type)
        c.addView(level)
        c.addView(time)
        AlertDialog.Builder(this)
            .setTitle("Fan / Heater change")
            .setView(c)
            .setPositiveButton("Save") { _, _ ->
                val sec = RoastMath.parseTime(time.text.toString()) ?: return@setPositiveButton
                val bt = r.tempLog.minByOrNull { abs(it.elapsedSec - sec) }?.bt ?: 0.0
                val lv = level.text.toString().trim().toIntOrNull()
                if (lv == null) {
                    toast("Level must be a number")
                    return@setPositiveButton
                }
                val q = SettingChange(sec, bt, lv)
                if (type.selectedItemPosition == 0) r.fanChanges.add(q) else r.heaterChanges.add(q)
                saveSafe()
                onSaved()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun notesDialog(r: RoastSession) {
        val e = input("Roast notes", 1)
        e.setText(r.notes)
        AlertDialog.Builder(this)
            .setTitle("Notes")
            .setView(e)
            .setPositiveButton("Save") { _, _ ->
                r.notes = e.text.toString()
                saveSafe()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }


    private fun densityMeasurementDialog(r: RoastSession) {
        val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val d = input("Roasted density g/L", 3)
        d.setText(r.roastedDensityGPerL?.toString() ?: "")
        val type = Spinner(this)
        type.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item,
            arrayOf("Bulk density", "Particle / true density")
        )
        type.setSelection(if (r.densityType.equals("particle", true)) 1 else 0)
        val measured = TextView(this).apply { textSize = 14f; setPadding(dp(8), dp(8), dp(8), dp(8)) }
        fun updateAge() {
            val dropWall = if (r.dropSec != null) r.startTimeMillis + r.dropSec!! * 1000L else r.startTimeMillis
            val hours = ((System.currentTimeMillis() - dropWall).coerceAtLeast(0L)) / 3600000.0
            measured.text = "Time since drop: ${"%.1f".format(hours)} h • Your protocol: measure at ~24 h"
        }
        updateAge()
        c.addView(d)
        c.addView(sub("Measurement type"))
        c.addView(type)
        c.addView(measured)
        c.addView(sub("Use the same measurement method and container protocol for green and roasted coffee. Bulk density must not be used to infer bean volume expansion."))
        AlertDialog.Builder(this)
            .setTitle("Post-roast density")
            .setView(c)
            .setPositiveButton("Save measurement") { _, _ ->
                val value = d.text.toString().trim().replace(',', '.').toDoubleOrNull()
                if (value == null || value <= 0.0) {
                    toast("Enter a valid roasted density")
                    return@setPositiveButton
                }
                r.roastedDensityGPerL = value
                r.densityType = if (type.selectedItemPosition == 1) "particle" else "bulk"
                r.densityMeasuredAtMillis = System.currentTimeMillis()
                if (!saveSafe("density")) return@setPositiveButton
                showSummary(r)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun densityAnalysisText(r: RoastSession): String {
        val green = r.densityGPerL
        val roasted = r.roastedDensityGPerL
        val reduction = RoastMath.densityReductionPercent(green, roasted)
        val retention = RoastMath.densityRetentionPercent(green, roasted)
        val expansion = RoastMath.estimatedVolumeExpansionPercent(
            r.greenWeightG, r.roastedWeightG, green, roasted, r.densityType
        )
        val level = RoastMath.roastLevelLabel(r.roastLevel)
        val band = RoastMath.weightLossReference(r.roastLevel)
        val loss = r.roastedWeightG?.let { RoastMath.weightLossPercent(r.greenWeightG, it) }
        val lossStatus = loss?.let {
            when {
                it < band.low -> "below reference"
                it <= band.high -> "within reference"
                else -> "above reference"
            }
        } ?: "inconclusive"
        val densityStatus = RoastMath.densityAssessment(green, roasted)
        val ageHours = if (r.densityMeasuredAtMillis != null && r.dropSec != null) {
            ((r.densityMeasuredAtMillis!! - (r.startTimeMillis + r.dropSec!! * 1000L)).coerceAtLeast(0L)) / 3600000.0
        } else null
        return buildString {
            append("Post-roast physical analysis\n")
            append("Reference level: $level • Weight loss: ${loss?.let { "%.2f%%".format(it) } ?: "—"} ($lossStatus; ref ${"%.0f".format(band.low)}–${"%.0f".format(band.high)}%)\n")
            append("Density: ${green?.let { "%.1f".format(it) } ?: "—"} → ${roasted?.let { "%.1f".format(it) } ?: "—"} g/L")
            if (reduction != null) append(" • reduction ${"%.1f%%".format(reduction)} • retention ${"%.1f%%".format(retention)}")
            append("\nDensity assessment: $densityStatus")
            if (expansion != null) append("\nEstimated bean volume expansion: ${"%.1f%%".format(expansion)}")
            if (r.densityType.equals("bulk", true)) append("\nNote: bulk density reflects packing/void space; it is not direct bean volume expansion.")
            if (ageHours != null) append("\nMeasurement age: ${"%.1f".format(ageHours)} h${if (ageHours < 20.0) " — repeat at ~24 h for your standard protocol" else ""}")
            append("\nInterpretation: weight loss should generally rise with roast severity; absolute density is origin/size/method dependent, so the paired green→roasted change is more useful than a universal roasted-density target.")
        }
    }

    private fun thermalAnalysisText(r: RoastSession): String {
        val etCoverage = RoastMath.etCoveragePercent(r.tempLog)
        val controls = RoastMath.controlThermalResponses(r, 60)
        val measured = controls.filter { it.beforeRor != null && it.afterRor != null }
        return buildString {
            append("Thermal observations\n")
            append("ET coverage: ${etCoverage?.let { "%.0f%%".format(it) } ?: "—"}")
            if (etCoverage != null && etCoverage < 50.0) append(" • ET data limited")
            append("\nRoR is a temperature slope, not direct energy input; fan/heater entries are control actions.")
            if (measured.isNotEmpty()) {
                append("\nControl response (60 s): ")
                measured.take(6).forEachIndexed { i, q ->
                    if (i > 0) append(" • ")
                    append("${q.control} ${q.level} ${fmtTime(q.elapsedSec)}")
                    append(" ΔRoR ${q.deltaRor?.let { "%+.1f".format(it) } ?: "—"}")
                }
                if (measured.size > 6) append(" • +${measured.size - 6} more")
            } else {
                append("\nControl-response comparison: insufficient paired RoR data")
            }
        }
    }

    private fun developmentAnalysisText(r: RoastSession): String {
        val dtr = RoastMath.dtr(0, r.firstCrackSec, r.dropSec)
        val devTime = if (r.firstCrackSec != null && r.dropSec != null) r.dropSec!! - r.firstCrackSec!! else null
        val endRor = RoastMath.developmentRorAtDrop(r.tempLog, r.firstCrackSec, r.dropSec)
        return buildString {
            append("Development observations\n")
            append("Development time: ${devTime?.let { fmtTime(it) } ?: "—"} • DTR: ${dtr?.let { "%.1f%%".format(it) } ?: "—"}")
            append("\nPost-FC pattern: ${RoastMath.developmentPattern(r.tempLog, r.firstCrackSec, r.dropSec)}")
            append("\nEnd-of-development RoR: ${endRor?.let { "%.1f °C/min".format(it) } ?: "—"}")
            append("\nDTR is descriptive; it is not used alone to label quality or underdevelopment.")
        }
    }

    private fun showSummary(r: RoastSession) {
        stopTicker()
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val l = screen("Roast #${r.globalRoastNumber} Summary")
        val b = Storage.beanById(r.beanId)
        l.addView(sub("${b?.name ?: "?"} • ${date(r.startTimeMillis)}"))
        val w = input("Roasted weight g (optional)", 3)
        w.setText(r.roastedWeightG?.toString() ?: "")
        l.addView(w)
        val ref = Spinner(this)
        ref.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item,
            listOf("No reference") + Storage.roasts.filter { it.id != r.id && it.beanId == r.beanId }
                .map { "#${it.globalRoastNumber}" }
        )
        l.addView(sub("Reference curve"))
        l.addView(ref)
        l.addView(primaryBtn("SAVE ROAST / WEIGHT") {
            val raw = w.text.toString().trim().replace(",", ".")
            val parsed = if (raw.isBlank()) null else raw.toDoubleOrNull()
            if (raw.isNotBlank() && (parsed == null || parsed <= 0.0 || parsed > r.greenWeightG * 1.05)) {
                toast("Enter a valid roasted weight, or leave it blank")
                return@btn
            }
            r.roastedWeightG = parsed
            r.roastedRemainingG = parsed
            val rr = Storage.roasts.filter { it.id != r.id && it.beanId == r.beanId }
            if (ref.selectedItemPosition > 0) r.referenceRoastId = rr.getOrNull(ref.selectedItemPosition - 1)?.id
            try {
                saveSafe()
                toast("Roast #${r.globalRoastNumber} saved")
                showSummary(r)
            } catch (e: Exception) {
                toast("SAVE FAILED: ${e.message ?: "storage error"}")
                File(filesDir, "coffeeroast_save_error.log").writeText(e.stackTraceToString())
            }
        })
        val loss = r.roastedWeightG?.let { RoastMath.weightLossPercent(r.greenWeightG, it) }
        val dtr = RoastMath.dtr(0, r.firstCrackSec, r.dropSec)
        val ph = RoastMath.phasePercents(0, r.dryEndSec, r.firstCrackSec, r.dropSec)
        val dropBt = r.tempLog.filter { r.dropSec != null && it.elapsedSec <= r.dropSec!! }
            .maxByOrNull { it.elapsedSec }?.bt
            ?: r.tempLog.maxByOrNull { it.elapsedSec }?.bt
        val intended = RoastMath.styleLabel(r.targetStyle)
        val process = Storage.beanById(r.beanId)?.process ?: ""
        val suggestedRange = r.densityGPerL?.takeIf { it > 0.0 }?.let { RoastMath.suggestedDropRangeC(it, process) }
        l.addView(
            tv(
                "Weight loss: ${loss?.let { "%.2f%%".format(it) } ?: "—"}   " +
                    "DTR: ${dtr?.let { "%.1f%%".format(it) } ?: "—"}",
                19f, true
            )
        )
        l.addView(
            sub(
                "Dry ${ph.first?.let { "%.1f%%".format(it) } ?: "—"} • " +
                    "Maillard ${ph.second?.let { "%.1f%%".format(it) } ?: "—"} • " +
                    "Development ${ph.third?.let { "%.1f%%".format(it) } ?: "—"}"
            )
        )
        l.addView(tv("Brew intent: $intended", 17f, true))
        l.addView(sub("Analytical roast degree: weight-loss indication only; roast color not recorded"))
        l.addView(sub("Reference roast level: ${RoastMath.roastLevelLabel(r.roastLevel)}"))
        l.addView(sub(
            suggestedRange?.let { "Working drop reference: ${"%.0f".format(it.first)}–${"%.0f".format(it.second)} °C (machine/reference aid, not a universal roast-level rule)" }
                ?: "Working drop reference: — (green density not recorded)"
        ))
        l.addView(btn("Post-roast density measurement") { densityMeasurementDialog(r) })
        l.addView(tv(densityAnalysisText(r), 15f, false))
        l.addView(tv(thermalAnalysisText(r), 15f, false))
        l.addView(tv(developmentAnalysisText(r), 15f, false))
        l.addView(
            sub(
                "TP ${r.turningPointSec?.let { fmtTime(it) } ?: "—"}  " +
                    "DE ${r.dryEndSec?.let { fmtTime(it) } ?: "—"}  " +
                    "FC ${r.firstCrackSec?.let { fmtTime(it) } ?: "—"}  " +
                    "SC ${r.secondCrackSec?.let { fmtTime(it) } ?: "—"}  " +
                    "DROP ${r.dropSec?.let { fmtTime(it) } ?: "—"}"
            )
        )
        l.addView(btn("Cupping / tasting score") { tastingDialog(r) })
        l.addView(btn("Roasted inventory / rest") { restDialog(r) })
        chart = RoastChartView(this)
        chart!!.layoutParams = LinearLayout.LayoutParams(-1, dp(300))
        chart!!.session = r
        chart!!.references = (
            r.referenceRoastId?.let { id -> listOfNotNull(Storage.roasts.firstOrNull { it.id == id }) }
                ?: Storage.roasts.filter { it.id != r.id && it.beanId == r.beanId }
                    .sortedByDescending { it.startTimeMillis }.take(3)
            )
        l.addView(chart)
        l.addView(btn("Chart smoothing (1 / 3 / 5 samples)") {
            chart!!.smoothing = when (chart!!.smoothing) {
                1 -> 3
                3 -> 5
                else -> 1
            }
            chart!!.invalidate()
            toast("Smoothing: ${chart!!.smoothing}")
        })
        l.addView(btn("Overlay: choose reference") { chooseReference(r) })
        l.addView(btn("Export Artisan TSV") { exportArtisan(r) })
        l.addView(btn("Export CSV") { exportCsv(r) })
        l.addView(btn("PDF report") { exportPdf(r) })
        l.addView(btn("Delete roast") {
            AlertDialog.Builder(this)
                .setMessage(
                    if (!r.isComplete)
                        "Delete this incomplete roast? Green stock will be restored."
                    else
                        "Delete this completed roast? Green stock will not be restored."
                )
                .setPositiveButton("Delete") { _, _ ->
                    Storage.deleteRoast(r.id)
                    showRoasts()
                }
                .setNegativeButton("Cancel", null)
                .show()
        })
        l.addView(btn("Back") { showRoasts() })
    }

    private fun chooseReference(r: RoastSession) {
        val xs = Storage.roasts.filter { it.id != r.id && it.beanId == r.beanId }
        val names = xs.map { "#${it.globalRoastNumber}" }
        AlertDialog.Builder(this)
            .setTitle("Reference")
            .setItems(arrayOf("None") + names.toTypedArray()) { _, i ->
                r.referenceRoastId = if (i == 0) null else xs[i - 1].id
                saveSafe()
                showSummary(r)
            }
            .show()
    }

    private fun tastingDialog(r: RoastSession) {
        val t = r.tasting ?: TastingScore()
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        val labels = listOf(
            "Fragrance", "Flavor", "Aftertaste", "Acidity", "Body",
            "Balance", "Sweetness", "Clean Cup", "Uniformity", "Overall"
        )
        val vals = listOf(
            t.fragrance, t.flavor, t.aftertaste, t.acidity, t.body,
            t.balance, t.sweetness, t.cleanCup, t.uniformity, t.overall
        )
        val es = labels.mapIndexed { i, n ->
            input("$n (6-10)", 3).apply {
                setText(if (vals[i] == 0.0) "" else vals[i].toString())
                c.addView(this)
            }
        }
        val notes = input("Tasting notes", 1)
        notes.setText(t.notes)
        c.addView(notes)
        AlertDialog.Builder(this)
            .setTitle("Cupping / tasting score")
            .setView(c)
            .setPositiveButton("Save") { _, _ ->
                val a = es.map { it.text.toString().toDoubleOrNull() ?: 0.0 }
                r.tasting = TastingScore(
                    a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], notes.text.toString()
                )
                saveSafe()
                toast("Score ${"%.1f".format(r.tasting!!.total())}/100")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun restDialog(r: RoastSession) {
        val c = input("Rest days", 2)
        c.setText(r.restingDays.toString())
        AlertDialog.Builder(this)
            .setTitle("Resting inventory")
            .setView(c)
            .setPositiveButton("Save") { _, _ ->
                r.restingDays = c.text.toString().toIntOrNull() ?: 7
                r.roastedRemainingG = r.roastedWeightG
                saveSafe()
                showSummary(r)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showInventory() {
        val l = screen("Roasted Inventory")
        Storage.roasts.filter { it.isComplete && it.roastedWeightG != null }
            .sortedByDescending { it.startTimeMillis }
            .forEach { r ->
                val b = Storage.beanById(r.beanId)
                val age = ((System.currentTimeMillis() - r.startTimeMillis) / 86400000L).toInt()
                val ready = age >= r.restingDays
                val rem = r.roastedRemainingG ?: r.roastedWeightG ?: 0.0
                l.addView(
                    sub(
                        "#${r.globalRoastNumber} ${b?.name ?: "?"} • ${fmt(rem)}g remaining • " +
                            if (ready) "READY / peak window" else "$age/${r.restingDays} days resting"
                    )
                )
            }
        l.addView(btn("Back") { showHome() })
    }

    private fun showDashboard() {
        val l = screen("Dashboard")
        val complete = Storage.roasts.filter { it.isComplete }
        val losses = complete.mapNotNull { r ->
            r.roastedWeightG?.let { x -> RoastMath.weightLossPercent(r.greenWeightG, x) }
        }
        val dtrs = complete.mapNotNull { RoastMath.dtr(0, it.firstCrackSec, it.dropSec) }
        l.addView(tv("Roasts: ${complete.size}", 20f, true))
        l.addView(sub("Average weight loss: ${losses.averageOrNull()?.let { "%.2f%%".format(it) } ?: "—"}"))
        l.addView(sub("Average DTR: ${dtrs.averageOrNull()?.let { "%.2f%%".format(it) } ?: "—"}"))
        val scored = complete.filter { it.tasting != null }
        l.addView(
            sub(
                "Cupped roasts: ${scored.size} • average score: " +
                    (scored.map { it.tasting!!.total() }.averageOrNull()?.let { "%.1f".format(it) } ?: "—")
            )
        )
        Storage.beans.forEach { b ->
            val n = complete.count { it.beanId == b.id }
            l.addView(sub("${b.name}: $n roasts • ${fmt(b.stockGrams)}g green stock"))
        }
        l.addView(btn("Export dashboard CSV") { exportDashboardCsv() })
        l.addView(btn("Back") { showHome() })
    }

    private fun showTools() {
        val l = screen("Tools & Calculators")
        l.addView(btn("Green weight for target roasted") {
            calcDialog("Target roasted g", "Expected loss %") { g, loss ->
                if (loss < 100) toast("Green needed: ${"%.1f".format(g / (1 - loss / 100))} g")
            }
        })
        l.addView(btn("Brew ratio calculator") { calcDialog2() })
        l.addView(btn("Independent stopwatch") { stopwatch() })
        l.addView(btn("Unit converter") { unitConverter() })
        l.addView(btn("Charge temperature heuristic") { chargeCalculator() })
        l.addView(btn("Blend builder") { blendDialog() })
        l.addView(btn("Back") { showHome() })
    }

    private fun calcDialog(a: String, b: String, done: (Double, Double) -> Unit) {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        val x = input(a, 3)
        val y = input(b, 3)
        c.addView(x)
        c.addView(y)
        AlertDialog.Builder(this)
            .setTitle("Calculator")
            .setView(c)
            .setPositiveButton("Calculate") { _, _ ->
                done(
                    x.text.toString().toDoubleOrNull() ?: 0.0,
                    y.text.toString().toDoubleOrNull() ?: 0.0
                )
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun unitConverter() {
        val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val g = input("grams", 3)
        val oz = input("ounces", 3)
        c.addView(g)
        c.addView(oz)
        AlertDialog.Builder(this)
            .setTitle("g ↔ oz")
            .setView(c)
            .setPositiveButton("Convert") { _, _ ->
                val gv = g.text.toString().toDoubleOrNull()
                val ov = oz.text.toString().toDoubleOrNull()
                when {
                    gv != null -> toast("${gv} g = ${"%.2f".format(gv / 28.3495)} oz")
                    ov != null -> toast("${ov} oz = ${"%.1f".format(ov * 28.3495)} g")
                    else -> toast("Enter grams or ounces")
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun chargeCalculator() {
        val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val weight = input("Batch weight g", 3)
        val density = input("Density g/L", 3)
        val base = input("Base charge °C", 3)
        c.addView(weight)
        c.addView(density)
        c.addView(base)
        AlertDialog.Builder(this)
            .setTitle("Charge temperature heuristic")
            .setMessage("Heuristic only; calibrate against your own roaster and bean.")
            .setView(c)
            .setPositiveButton("Calculate") { _, _ ->
                val w = weight.text.toString().toDoubleOrNull() ?: 0.0
                val d = density.text.toString().toDoubleOrNull() ?: 700.0
                val b = base.text.toString().toDoubleOrNull() ?: 200.0
                val suggested = b + (d - 700.0) * 0.02 - (w - 250.0) * 0.03
                toast("Suggested starting point: ${"%.0f".format(suggested)}°C")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun calcDialog2() {
        val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val cups = input("Cups", 2)
        val dose = input("g per cup", 3)
        val ratio = input("Water ratio 1:x", 3)
        c.addView(cups)
        c.addView(dose)
        c.addView(ratio)
        AlertDialog.Builder(this)
            .setTitle("Brew calculator")
            .setView(c)
            .setPositiveButton("Calculate") { _, _ ->
                val cupsValue = cups.text.toString().toDoubleOrNull() ?: 0.0
                val doseValue = dose.text.toString().toDoubleOrNull() ?: 0.0
                val ratioValue = ratio.text.toString().toDoubleOrNull() ?: 16.0
                val coffee = cupsValue * doseValue
                toast("${"%.1f".format(coffee)}g coffee • ${"%.0f".format(coffee * ratioValue)}g water")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun stopwatch() {
        val d = AlertDialog.Builder(this)
        val t = TextView(this)
        t.textSize = 30f
        t.gravity = Gravity.CENTER
        var s = 0
        val rr = object : Runnable {
            override fun run() {
                t.text = fmtTime(s++)
                h.postDelayed(this, 1000)
            }
        }
        h.post(rr)
        d.setTitle("Stopwatch")
            .setView(t)
            .setNegativeButton("Close") { _, _ -> h.removeCallbacks(rr) }
            .show()
    }

    private fun blendDialog() {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        val rows = Storage.beans.map { b ->
            val e = input("${b.name} %", 3)
            c.addView(e)
            b to e
        }
        AlertDialog.Builder(this)
            .setTitle("Pre-roast blend builder")
            .setMessage("Enter percentages; total should be 100%.")
            .setView(c)
            .setPositiveButton("Check") { _, _ ->
                val sum = rows.sumOf { it.second.text.toString().toDoubleOrNull() ?: 0.0 }
                toast("Blend total: ${"%.1f".format(sum)}%")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showSettings() {
        val l = screen("Settings")
        val unit = Spinner(this)
        unit.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, arrayOf("°C", "°F")
        )
        unit.setSelection(if (Storage.settings.temperatureUnit == "F") 1 else 0)
        l.addView(sub("Temperature unit (storage always °C; display converts)"))
        l.addView(unit)
        val wu = Spinner(this)
        wu.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, arrayOf("g", "oz")
        )
        wu.setSelection(if (Storage.settings.weightUnit == "oz") 1 else 0)
        l.addView(sub("Weight"))
        l.addView(wu)
        val interval = input("Logging interval seconds", 2)
        interval.setText(Storage.settings.logIntervalSec.toString())
        val de = input("Dry end target °C", 3)
        de.setText(Storage.settings.dryEndTargetC.toString())
        val fc = input("First crack target °C", 3)
        fc.setText(Storage.settings.firstCrackTargetC.toString())
        val ror = input("Low RoR warning °C/min", 3)
        ror.setText(Storage.settings.lowRorWarning.toString())
        val drop = input("Estimated drop target °C", 3)
        drop.setText(Storage.settings.dropTargetC.toString())
        val rest = input("Default rest days", 2)
        rest.setText(Storage.settings.defaultRestDays.toString())
        val theme = Spinner(this)
        theme.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, arrayOf("System", "Light", "Dark")
        )
        theme.setSelection(
            when (Storage.settings.theme) {
                "dark" -> 2
                "light" -> 1
                else -> 0
            }
        )
        l.addView(interval)
        l.addView(de)
        l.addView(fc)
        l.addView(ror)
        l.addView(drop)
        l.addView(rest)
        l.addView(sub("Theme"))
        l.addView(theme)
        l.addView(btn("Save settings") {
            Storage.settings.temperatureUnit = if (unit.selectedItemPosition == 1) "F" else "C"
            Storage.settings.weightUnit = if (wu.selectedItemPosition == 1) "oz" else "g"
            Storage.settings.logIntervalSec =
                (interval.text.toString().toIntOrNull() ?: 30).coerceIn(1, 600)
            Storage.settings.dryEndTargetC = de.text.toString().toDoubleOrNull() ?: 150.0
            Storage.settings.firstCrackTargetC = fc.text.toString().toDoubleOrNull() ?: 200.0
            Storage.settings.lowRorWarning = ror.text.toString().toDoubleOrNull() ?: 10.0
            Storage.settings.dropTargetC = drop.text.toString().toDoubleOrNull() ?: 205.0
            Storage.settings.defaultRestDays = rest.text.toString().toIntOrNull() ?: 7
            Storage.settings.theme = when (theme.selectedItemPosition) {
                1 -> "light"
                2 -> "dark"
                else -> "system"
            }
            saveSafe()
            AppCompatDelegate.setDefaultNightMode(
                when (Storage.settings.theme) {
                    "dark" -> AppCompatDelegate.MODE_NIGHT_YES
                    "light" -> AppCompatDelegate.MODE_NIGHT_NO
                    else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
                }
            )
            toast("Saved")
            showHome()
        })
        l.addView(btn("Back") { showHome() })
    }

    private fun installCrashLogger() {
        Thread.setDefaultUncaughtExceptionHandler { _, e ->
            try {
                File(filesDir, "coffeeroast_crash.log").writeText(e.stackTraceToString())
            } catch (_: Exception) {
            }
            android.os.Process.killProcess(android.os.Process.myPid())
        }
    }

    private fun applyTheme() {
        AppCompatDelegate.setDefaultNightMode(
            when (Storage.settings.theme) {
                "dark" -> AppCompatDelegate.MODE_NIGHT_YES
                "light" -> AppCompatDelegate.MODE_NIGHT_NO
                else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
            }
        )
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel("roast_live", "Live Roast", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun showRoastNotification(r: RoastSession) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) return
        val i = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pi = PendingIntent.getActivity(
            this, 1, i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val sec = elapsed(r)
        getSystemService(NotificationManager::class.java).notify(
            42,
            NotificationCompat.Builder(this, "roast_live")
                .setSmallIcon(android.R.drawable.ic_popup_sync)
                .setContentTitle("Coffee Roast #${r.globalRoastNumber}")
                .setContentText("Roast in progress • ${fmtTime(sec)} • tap to return")
                .setOngoing(true)
                .setContentIntent(pi)
                .build()
        )
    }

    private fun cancelRoastNotification() {
        getSystemService(NotificationManager::class.java).cancel(42)
    }

    private fun showBackup() {
        val l = screen("Backup / Restore")
        l.addView(
            sub(
                "Schema ${Storage.SCHEMA}. Backups include all JSON roast data."
            )
        )
        l.addView(btn("Create backup ZIP") {
            val f = File(cacheDir, "CoffeeRoast-backup-${stamp()}.zip")
            if (Storage.exportBackup(this, f)) {
                share(f, "application/zip")
            } else {
                toast("Backup failed: ${Storage.lastStatus}")
            }
        })
        l.addView(btn("Restore backup ZIP") {
            restoreLauncher.launch(arrayOf("application/zip", "application/octet-stream", "*/*"))
        })
        l.addView(btn("Share crash log") {
            val f = File(filesDir, "coffeeroast_crash.log")
            if (f.exists()) share(f, "text/plain") else toast("No crash log saved")
        })
        l.addView(btn("Force save + show storage status") {
            val report = Storage.forceSaveAndReport()
            toast(report.take(80))
            AlertDialog.Builder(this).setTitle("Storage status").setMessage(report + "\n\n" + Storage.dataSummary()).setPositiveButton("OK", null).show()
        })
        l.addView(btn("Export raw JSON") {
            val f = File(cacheDir, "coffeeroast-${stamp()}.json")
            f.writeText(Storage.rawJson())
            share(f, "application/json")
        })
        l.addView(btn("Back") { showHome() })
    }

    private fun exportArtisan(r: RoastSession) {
        val f = File(cacheDir, "artisan_roast_${r.globalRoastNumber}.tsv")
        val events = mapOf(
            r.dryEndSec to "DRY END",
            r.firstCrackSec to "FIRST CRACK",
            r.secondCrackSec to "SECOND CRACK",
            r.dropSec to "DROP",
            r.turningPointSec to "TURNING POINT"
        )
        f.writeText(buildString {
            append("time(sec)\tBT\tET\tEvent\n")
            r.tempLog.sortedBy { it.elapsedSec }.forEach { p ->
                val et = p.et?.toString() ?: ""
                val event = events[p.elapsedSec] ?: ""
                append(p.elapsedSec).append('\t').append(p.bt).append('\t').append(et)
                    .append('\t').append(event).append('\n')
            }
        })
        share(f, "text/tab-separated-values")
    }

    private fun exportCsv(r: RoastSession) {
        val f = File(cacheDir, "roast_${r.globalRoastNumber}.csv")
        val rr = RoastMath.rorSeries(r.tempLog).toMap()
        val dr = RoastMath.deltaRor(r.tempLog).toMap()
        f.writeText(buildString {
            append("time_sec,BT,ET,RoR,DeltaRoR\n")
            r.tempLog.sortedBy { it.elapsedSec }.forEach { p ->
                val et = p.et?.toString() ?: ""
                val ror = rr[p.elapsedSec]?.toString() ?: ""
                val delta = dr[p.elapsedSec]?.toString() ?: ""
                append(p.elapsedSec).append(',').append(p.bt).append(',').append(et)
                    .append(',').append(ror).append(',').append(delta).append('\n')
            }
        })
        share(f, "text/csv")
    }

    private fun exportDashboardCsv() {
        val f = File(cacheDir, "coffee_roast_dashboard.csv")
        f.writeText(buildString {
            append("roast,bean,date,green_g,roasted_g,loss_pct,green_density_gL,roasted_density_gL,density_type,density_reduction_pct,roast_level,brew_intent,DTR,development_sec,development_ror_end,score\n")
            Storage.roasts.filter { it.isComplete }.forEach { r ->
                val b = Storage.beanById(r.beanId)
                val beanName = (b?.name ?: "").replace("\"", "\"\"")
                val roasted = r.roastedWeightG?.toString() ?: ""
                val loss =
                    r.roastedWeightG?.let { RoastMath.weightLossPercent(r.greenWeightG, it)?.toString() } ?: ""
                val greenDensity = r.densityGPerL?.toString() ?: ""
                val roastedDensity = r.roastedDensityGPerL?.toString() ?: ""
                val densityReduction = RoastMath.densityReductionPercent(r.densityGPerL, r.roastedDensityGPerL)?.toString() ?: ""
                val dtr = RoastMath.dtr(0, r.firstCrackSec, r.dropSec)?.toString() ?: ""
                val devSec = if (r.firstCrackSec != null && r.dropSec != null && r.dropSec!! >= r.firstCrackSec!!) (r.dropSec!! - r.firstCrackSec!!).toString() else ""
                val endRor = RoastMath.developmentRorAtDrop(r.tempLog, r.firstCrackSec, r.dropSec)?.toString() ?: ""
                val score = r.tasting?.total()?.toString() ?: ""
                append(r.globalRoastNumber).append(',')
                    .append('\"').append(beanName).append('\"').append(',')
                    .append(date(r.startTimeMillis)).append(',')
                    .append(r.greenWeightG).append(',').append(roasted).append(',')
                    .append(loss).append(',').append(greenDensity).append(',').append(roastedDensity).append(',')
                    .append(r.densityType).append(',').append(densityReduction).append(',')
                    .append(r.roastLevel).append(',').append(r.targetStyle).append(',').append(dtr).append(',')
                    .append(devSec).append(',').append(endRor).append(',').append(score).append('\n')
            }
        })
        share(f, "text/csv")
    }

    private fun exportPdf(r: RoastSession) {
        val f = File(cacheDir, "roast_${r.globalRoastNumber}.pdf")
        val doc = PdfDocument()
        fun page(title: String): Pair<PdfDocument.Page, Canvas> {
            val p = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, doc.pages.size + 1).create())
            return p to p.canvas
        }
        val (p1, c1) = page("summary")
        val b = Storage.beanById(r.beanId)
        val title = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            textSize = 22f
        }
        val body = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            textSize = 12f
        }
        c1.drawText("Coffee Roast Lab — Roast #${r.globalRoastNumber}", 35f, 42f, title)
        val lines = listOf(
            "Bean: ${b?.name ?: "—"}",
            "Date: ${date(r.startTimeMillis)}",
            "Roaster: ${r.roasterName.ifBlank { "—" }}",
            "Green: ${r.greenWeightG} g   Roasted: ${r.roastedWeightG ?: "—"} g",
            "Weight loss: ${r.roastedWeightG?.let { RoastMath.weightLossPercent(r.greenWeightG, it)?.let { x -> "%.2f%%".format(x) } } ?: "—"}",
            "Brew intent: ${RoastMath.styleLabel(r.targetStyle)}   Reference roast level: ${RoastMath.roastLevelLabel(r.roastLevel)}",
            "Weight loss is an analytical indication only; roast color was not recorded.",
            "Green density: ${r.densityGPerL ?: "—"} g/L   Roasted density: ${r.roastedDensityGPerL ?: "—"} g/L",
            "Density reduction: ${RoastMath.densityReductionPercent(r.densityGPerL, r.roastedDensityGPerL)?.let { "%.2f%%".format(it) } ?: "—"}   Type: ${r.densityType}",
            "TP ${r.turningPointSec?.let { fmtTime(it) } ?: "—"}   DE ${r.dryEndSec?.let { fmtTime(it) } ?: "—"}   " +
                "FC ${r.firstCrackSec?.let { fmtTime(it) } ?: "—"}   SC ${r.secondCrackSec?.let { fmtTime(it) } ?: "—"}   " +
                "DROP ${r.dropSec?.let { fmtTime(it) } ?: "—"}",
            "DTR: ${RoastMath.dtr(0, r.firstCrackSec, r.dropSec)?.let { "%.2f%%".format(it) } ?: "—"}   Development: ${if (r.firstCrackSec != null && r.dropSec != null) fmtTime(r.dropSec!! - r.firstCrackSec!!) else "—"}",
            "Development pattern: ${RoastMath.developmentPattern(r.tempLog, r.firstCrackSec, r.dropSec)}",
            "ET coverage: ${RoastMath.etCoveragePercent(r.tempLog)?.let { "%.0f%%".format(it) } ?: "—"}",
            "Cupping: ${r.tasting?.total()?.let { "%.1f".format(it) } ?: "—"}",
            "Notes: ${r.notes.ifBlank { "—" }}"
        )
        lines.forEachIndexed { i, v -> c1.drawText(v.take(90), 35f, 78f + i * 25f, body) }
        doc.finishPage(p1)

        val (p2, c2) = page("chart")
        c2.drawText("Roast curve", 35f, 35f, title)
        val pdfMaxTime = r.tempLog.maxOfOrNull { it.elapsedSec } ?: 0
        val pdfLabelStep = when {
            pdfMaxTime <= 600 -> 60
            pdfMaxTime <= 1200 -> 120
            pdfMaxTime <= 2400 -> 180
            else -> 300
        }
        val chartView = RoastChartView(this).apply {
            session = r
            references = (
                r.referenceRoastId?.let { id -> listOfNotNull(Storage.roasts.firstOrNull { it.id == id }) }
                    ?: emptyList()
                )
            pdfTimeLabelStepSec = pdfLabelStep
        }
        chartView.measure(
            android.view.View.MeasureSpec.makeMeasureSpec(525, android.view.View.MeasureSpec.EXACTLY),
            android.view.View.MeasureSpec.makeMeasureSpec(430, android.view.View.MeasureSpec.EXACTLY)
        )
        chartView.layout(0, 0, 525, 430)
        val bmp = Bitmap.createBitmap(525, 430, Bitmap.Config.ARGB_8888)
        val bc = Canvas(bmp)
        bc.drawColor(Color.WHITE)
        chartView.draw(bc)
        c2.drawBitmap(bmp, 35f, 50f, Paint(Paint.ANTI_ALIAS_FLAG))
        bmp.recycle()
        var y = 510f
        c2.drawText("Control changes", 35f, y, title)
        y += 24f
        val events = (
            r.fanChanges.map { "${fmtTime(it.elapsedSec)}  BT ${"%.1f".format(it.btAtChange)}  FAN ${it.level}" } +
                r.heaterChanges.map { "${fmtTime(it.elapsedSec)}  BT ${"%.1f".format(it.btAtChange)}  HEATER ${it.level}" }
            ).sorted()
        events.take(12).forEach {
            c2.drawText(it, 35f, y, body)
            y += 18f
        }
        doc.finishPage(p2)

        val log = r.tempLog.sortedBy { it.elapsedSec }
        var index = 0
        var pageNo = 0
        while (index < log.size || pageNo == 0) {
            val (pp, cc) = page("samples")
            cc.drawText("Temperature samples ${if (pageNo > 0) "(continued)" else ""}", 35f, 35f, title)
            var yy = 60f
            cc.drawText("Time", 35f, yy, body)
            cc.drawText("BT", 120f, yy, body)
            cc.drawText("ET", 205f, yy, body)
            cc.drawText("RoR", 290f, yy, body)
            yy += 20f
            var rows = 0
            while (index < log.size && yy <= 815f) {
                val sample = log[index]
                val rr = RoastMath.currentRor(log.take(index + 1), 60)
                cc.drawText(fmtTime(sample.elapsedSec), 35f, yy, body)
                cc.drawText("%.1f".format(sample.bt), 120f, yy, body)
                cc.drawText(sample.et?.let { "%.1f".format(it) } ?: "—", 205f, yy, body)
                cc.drawText(rr?.let { "%.2f".format(it) } ?: "—", 290f, yy, body)
                yy += 17f
                index++
                rows++
            }
            doc.finishPage(pp)
            pageNo++
            if (rows == 0) break
        }
        FileOutputStream(f).use { doc.writeTo(it) }
        doc.close()
        share(f, "application/pdf")
    }

    private fun legacyDialog() {
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        val help = TextView(this).apply {
            textSize = 14f
            text =
                "IMPORT OLD ROAST — PRO FORMAT\n\nYou can paste a handwritten/Artisan-style roast.\n\n" +
                    "Example:\nEthiopia\nyirgachef gedeb\nanaerobic\n150\n130\n\n" +
                    "BT   ET\n1:00  98  92\n1:30  114 107\n4:00  151 dryend 143\n10:00 198 FC 183\n10:50 206 DROP 188\n\n" +
                    "Fan Start 12   11:100  10:140  9:154\nHeater Start 13   14:130  18:140\n\n" +
                    "Meaning of controls: LEVEL:TEMPERATURE. The temperature is BT, not elapsed time.\n" +
                    "The importer converts each control change to the nearest roast timestamp automatically.\n" +
                    "You can also use labels: Name:, Origin:, Process:, Green:, Roasted:.\n" +
                    "Blank lines and column headers are ignored."
            setPadding(0, 0, 0, dp(12))
        }
        box.addView(help)
        val e = input("Paste complete old roast here", 1).apply {
            minLines = 22
            gravity = Gravity.TOP or Gravity.START
            setSingleLine(false)
        }
        box.addView(e, LinearLayout.LayoutParams(-1, dp(420)))
        scroll.addView(box)
        AlertDialog.Builder(this)
            .setTitle("Import old roast")
            .setView(scroll)
            .setPositiveButton("Import", null)
            .setNegativeButton("Cancel", null)
            .create()
            .also { dialog ->
                dialog.setOnShowListener {
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                        val lines = e.text.toString().lines()
                        val samples = mutableListOf<TempPoint>()
                        val fanRaw = mutableListOf<Pair<Int, Double>>()
                        val heaterRaw = mutableListOf<Pair<Int, Double>>()
                        val fanStart = mutableListOf<Int>()
                        val heaterStart = mutableListOf<Int>()
                        val errors = mutableListOf<String>()
                        var name = ""
                        var origin = ""
                        var process = ""
                        var greenWeight: Double? = null
                        var roastedWeight: Double? = null
                        var mode = "table"
                        var unlabeledText = 0
                        var unlabeledNumbers = 0
                        val eventBySec = mutableMapOf<Int, String>()

                        fun num(raw: String): Double? = raw.trim().replace(",", ".").toDoubleOrNull()
                        fun putEvent(sec: Int, label: String) {
                            eventBySec[sec] = label.lowercase()
                        }

                        fun parseControlLine(
                            line: String,
                            target: MutableList<Pair<Int, Double>>,
                            starts: MutableList<Int>
                        ) {
                            val low = line.lowercase()
                            Regex("\\bstart\\s+(-?\\d+)\\b").find(low)?.groupValues?.getOrNull(1)
                                ?.toIntOrNull()?.let { starts.add(it) }
                            Regex("(?<![:\\d])(\\d+)\\s*:\\s*(-?\\d+(?:[.,]\\d+)?)").findAll(line)
                                .forEach { m ->
                                    val level = m.groupValues[1].toIntOrNull()
                                    val temp = num(m.groupValues[2])
                                    if (level != null && temp != null) target.add(level to temp)
                                }
                        }

                        for ((idx, raw) in lines.withIndex()) {
                            val line = raw.trim()
                            if (line.isEmpty()) continue
                            val low = line.lowercase()
                            if (low.startsWith("fan")) {
                                mode = "fan"
                                parseControlLine(line, fanRaw, fanStart)
                                continue
                            }
                            if (low.startsWith("heater") || low.startsWith("heat")) {
                                mode = "heater"
                                parseControlLine(line, heaterRaw, heaterStart)
                                continue
                            }
                            if (mode == "fan") {
                                parseControlLine(line, fanRaw, fanStart)
                                continue
                            }
                            if (mode == "heater") {
                                parseControlLine(line, heaterRaw, heaterStart)
                                continue
                            }

                            val labeled =
                                Regex(
                                    "^(name|bean|origin|process|green|green weight|roasted|roasted weight)\\s*[:=]\\s*(.+)$",
                                    RegexOption.IGNORE_CASE
                                ).find(line)
                            if (labeled != null) {
                                when (labeled.groupValues[1].lowercase()) {
                                    "name", "bean" -> name = labeled.groupValues[2].trim()
                                    "origin" -> origin = labeled.groupValues[2].trim()
                                    "process" -> process = labeled.groupValues[2].trim()
                                    "green", "green weight" -> greenWeight = num(labeled.groupValues[2])
                                    "roasted", "roasted weight" -> roastedWeight = num(labeled.groupValues[2])
                                }
                                continue
                            }

                            if (low.contains("bt") && low.contains("et")) {
                                mode = "table"
                                continue
                            }
                            val time = Regex("^(\\d{1,3}:\\d{2}(?::\\d{2})?)\\b").find(line)
                                ?.groupValues?.getOrNull(1)
                            if (time != null) {
                                val sec = RoastMath.parseTime(time)
                                if (sec == null) {
                                    errors.add("Line ${idx + 1}: invalid time")
                                    continue
                                }
                                val rest = line.removePrefix(time).trim()
                                val nums = Regex("[-+]?\\d+(?:[.,]\\d+)?").findAll(rest)
                                    .map { num(it.value) }.filterNotNull().toList()
                                if (nums.isEmpty()) {
                                    errors.add("Line ${idx + 1}: no BT value")
                                    continue
                                }
                                val bt = nums[0]
                                val et = nums.getOrNull(1)
                                if (bt !in 0.0..400.0 || et != null && et !in 0.0..400.0) {
                                    errors.add("Line ${idx + 1}: temperature outside 0–400°C")
                                    continue
                                }
                                samples.add(TempPoint(sec, bt, et))
                                when {
                                    low.contains("dryend") || low.contains("dry end") ||
                                        Regex("\\bde\\b").containsMatchIn(low) -> putEvent(sec, "de")
                                    low.contains("first crack") ||
                                        Regex("\\bfc\\b").containsMatchIn(low) -> putEvent(sec, "fc")
                                    low.contains("second crack") ||
                                        Regex("\\bsc\\b").containsMatchIn(low) -> putEvent(sec, "sc")
                                    low.contains("drop") ||
                                        Regex("\\bdr\\b").containsMatchIn(low) -> putEvent(sec, "drop")
                                }
                                continue
                            }

                            if (low.startsWith("#") || low.startsWith("time") || low.startsWith("temperature")) continue
                            if (name.isBlank() && unlabeledText == 0) {
                                name = line
                                unlabeledText++
                                continue
                            }
                            if (origin.isBlank() && unlabeledText == 1) {
                                origin = line
                                unlabeledText++
                                continue
                            }
                            if (process.isBlank() && unlabeledText == 2) {
                                process = line
                                unlabeledText++
                                continue
                            }
                            val n = num(line)
                            if (n != null && unlabeledNumbers < 2) {
                                if (unlabeledNumbers == 0) greenWeight = n else roastedWeight = n
                                unlabeledNumbers++
                                continue
                            }
                        }

                        if (samples.size < 2) {
                            toast("Import needs at least 2 valid temperature samples")
                            return@setOnClickListener
                        }
                        val unique = samples.sortedBy { it.elapsedSec }.distinctBy { it.elapsedSec }
                        if (name.isBlank()) name = "Imported Roast"
                        val bean = Storage.beans.firstOrNull {
                            it.name.equals(name, true) &&
                                it.origin.equals(origin, true) &&
                                it.process.equals(process, true)
                        } ?: GreenBean(Storage.newBeanId(), name, origin, process)
                        if (Storage.beans.none { it.id == bean.id }) Storage.addBean(bean)
                        val r = RoastSession(
                            Storage.newRoastId(),
                            Storage.allocateGlobalRoastNumber(),
                            bean.id,
                            Storage.nextBatch(bean),
                            greenWeight ?: 0.0,
                            roastedWeightG = roastedWeight,
                            startTimeMillis = System.currentTimeMillis(),
                            isComplete = true,
                            isHistorical = true,
                            stockReserved = false,
                            targetStyle = "not_recorded"
                        )
                        r.tempLog.addAll(unique)
                        eventBySec.forEach { (sec, label) ->
                            when (label) {
                                "de" -> r.dryEndSec = sec
                                "fc" -> r.firstCrackSec = sec
                                "sc" -> r.secondCrackSec = sec
                                "drop" -> r.dropSec = sec
                            }
                        }
                        val byBt = unique.map { it.bt to it }.toList()
                        fun nearestSec(bt: Double): Int =
                            byBt.minByOrNull { abs(it.first - bt) }?.second?.elapsedSec ?: 0
                        fanStart.firstOrNull()?.let {
                            r.startFan = it
                            r.fanChanges.add(SettingChange(0, unique.first().bt, it))
                        }
                        heaterStart.firstOrNull()?.let {
                            r.startHeater = it
                            r.heaterChanges.add(SettingChange(0, unique.first().bt, it))
                        }
                        fanRaw.forEach { (level, bt) ->
                            r.fanChanges.add(SettingChange(nearestSec(bt), bt, level))
                        }
                        heaterRaw.forEach { (level, bt) ->
                            r.heaterChanges.add(SettingChange(nearestSec(bt), bt, level))
                        }
                        r.fanChanges.sortBy { it.elapsedSec }
                        r.heaterChanges.sortBy { it.elapsedSec }
                        try {
                            if (!Storage.addRoast(r)) toast("ذخیره رست نشد: ${Storage.lastStatus}")
                            dialog.dismiss()
                            showSummary(r)
                        } catch (ex: Exception) {
                            toast("IMPORT FAILED: ${ex.message ?: "storage error"}")
                            File(filesDir, "coffeeroast_import_error.log").writeText(ex.stackTraceToString())
                        }
                    }
                }
            }
            .show()
    }

    private fun share(f: File, mime: String) {
        val u = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
        startActivity(
            Intent.createChooser(
                Intent(Intent.ACTION_SEND).apply {
                    type = mime
                    putExtra(Intent.EXTRA_STREAM, u)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                },
                "Share"
            )
        )
    }

    private fun haptic() {
        window.decorView.performHapticFeedback(3)
    }

    private fun temp(c: Double) =
        if (Storage.settings.temperatureUnit == "F") "%.1f°F".format(fromCelsius(c))
        else "%.1f°C".format(c)

    private fun fmt(g: Double) =
        if (Storage.settings.weightUnit == "oz") "%.1f".format(g / 28.3495) else "%.1f".format(g)

    private fun fmtTime(s: Int) = "${s / 60}:${(s % 60).toString().padStart(2, '0')}"
    private fun date(ms: Long) = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(ms))
    private fun stamp() = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())
    private fun List<Double>.averageOrNull(): Double? = if (isEmpty()) null else average()
}
