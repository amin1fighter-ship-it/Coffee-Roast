package com.amin1fighter.coffeeroast

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.abs

class RoastChartView @JvmOverloads constructor(
    c: Context,
    a: AttributeSet? = null
) : View(c, a) {
    var session: RoastSession? = null
    var references: List<RoastSession> = emptyList()
    var smoothing: Int = 1

    private val bt = paint("#D84315", 5f)
    private val et = paint("#6D4C41", 3f)
    private val rr = paint("#2E7D32", 3f)
    private val dr = paint("#1565C0", 2f)
    private val grid = paint("#8D8D8D", 1f)
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#5D4037")
        textSize = 16f
        style = Paint.Style.FILL
    }

    private fun paint(color: String, width: Float) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = Color.parseColor(color)
        strokeWidth = width
        style = Paint.Style.STROKE
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val s = session ?: return
        val all = (listOf(s) + references)
            .map { if (smoothing > 1) RoastMath.smooth(it.tempLog, smoothing) else it.tempLog }
            .filter { it.size > 1 }
        if (all.isEmpty()) return

        val left = 62f
        val top = 45f
        val right = 18f
        val bottom = 38f
        val plotW = width.toFloat() - left - right
        val plotH = height.toFloat() - top - bottom
        if (plotW <= 0f || plotH <= 0f) return

        val maxElapsed = all.maxOf { it.last().elapsedSec }
        val maxTime = ceil(maxElapsed / 30.0).toInt().coerceAtLeast(1) * 30
        val temps = all.flatMap { log -> log.flatMap { p -> listOfNotNull(p.bt, p.et) } }
        if (temps.isEmpty()) return

        val minTemp = floor((temps.minOrNull() ?: 0.0) / 10.0) * 10.0
        val maxTemp = ceil((temps.maxOrNull() ?: 220.0) / 10.0) * 10.0
            .coerceAtLeast(minTemp + 20.0)

        fun x(sec: Int): Float = left + sec.toFloat() / maxTime.toFloat() * plotW
        fun y(v: Double): Float = top + plotH - ((v - minTemp) / (maxTemp - minTemp)).toFloat() * plotH

        var temp = minTemp
        while (temp <= maxTemp) {
            c.drawLine(left, y(temp), left + plotW, y(temp), grid)
            c.drawText("${temp.toInt()}°", 4f, y(temp) + 5f, txt)
            temp += 10.0
        }

        var sec = 0
        while (sec <= maxTime) {
            c.drawLine(x(sec), top, x(sec), top + plotH, grid)
            c.drawText("${sec / 60}:${(sec % 60).toString().padStart(2, '0')}", x(sec) - 14f, top + plotH + 25f, txt)
            sec += 30
        }

        all.forEachIndexed { index, log ->
            val linePaint = if (index == 0) {
                bt
            } else {
                Paint(bt).apply { color = Color.argb(90, 216, 67, 21) }
            }
            for (i in 1 until log.size) {
                c.drawLine(
                    x(log[i - 1].elapsedSec), y(log[i - 1].bt),
                    x(log[i].elapsedSec), y(log[i].bt), linePaint
                )
            }
            if (index == 0) {
                for (i in 1 until log.size) {
                    val a = log[i - 1].et
                    val b = log[i].et
                    if (a != null && b != null) {
                        c.drawLine(
                            x(log[i - 1].elapsedSec), y(a),
                            x(log[i].elapsedSec), y(b), et
                        )
                    }
                }
            }
        }

        val rs = RoastMath.rorSeries(s.tempLog)
        if (rs.size > 1) {
            val maxR = maxOf(10.0, rs.maxOf { it.second })
            for (i in 1 until rs.size) {
                val y1 = top + plotH - (rs[i - 1].second / maxR).toFloat() * plotH * 0.28f
                val y2 = top + plotH - (rs[i].second / maxR).toFloat() * plotH * 0.28f
                c.drawLine(x(rs[i - 1].first), y1, x(rs[i].first), y2, rr)
            }
        }

        val ds = RoastMath.deltaRor(s.tempLog)
        if (ds.size > 1) {
            val scale = maxOf(5.0, ds.maxOf { abs(it.second) })
            for (i in 1 until ds.size) {
                val y1 = top + plotH / 2f - (ds[i - 1].second / scale).toFloat() * plotH / 2f * 0.25f
                val y2 = top + plotH / 2f - (ds[i].second / scale).toFloat() * plotH / 2f * 0.25f
                c.drawLine(x(ds[i - 1].first), y1, x(ds[i].first), y2, dr)
            }
        }

        fun marker(value: Int?, label: String) {
            if (value != null) {
                c.drawLine(x(value), top, x(value), top + plotH, grid)
                c.drawText(
                    "$label ${value / 60}:${(value % 60).toString().padStart(2, '0')}",
                    x(value) + 3f, top + 18f, txt
                )
            }
        }

        marker(s.turningPointSec, "TP")
        marker(s.dryEndSec, "DE")
        marker(s.firstCrackSec, "FC")
        marker(s.dropSec, "DROP")
        c.drawText("BT", left, 20f, bt)
        c.drawText("RoR", left + 45f, 20f, rr)
        c.drawText("ΔRoR", left + 90f, 20f, dr)
    }
}
