package com.amin1fighter.coffeeroast
import org.junit.Assert.*
import org.junit.Test
class RoastMathTest {
 @Test fun parsesTime(){assertEquals(69,RoastMath.parseTime("1:09"));assertNull(RoastMath.parseTime("9:99"))}
 @Test fun dtr(){assertEquals(20.0,RoastMath.dtr(0,480,600)!!,0.001)}
 @Test fun weightLoss(){assertEquals(12.5,RoastMath.weightLossPercent(200.0,175.0)!!,0.001)}
 @Test fun ror(){val l=listOf(TempPoint(0,100.0),TempPoint(60,110.0));assertEquals(10.0,RoastMath.currentRor(l)!!,0.001)}
 @Test fun eta(){assertEquals(600,RoastMath.etaToTempSec(300,150.0,10.0,200.0))}
}
