package com.amin1fighter.coffeeroast

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import kotlin.math.ceil
import kotlin.math.max

/** Roast chart: temperature is the main panel, RoR has its own lower panel,
 * and fan/heater changes are shown in a compact aligned control strip. */
class RoastChartView @JvmOverloads constructor(c: Context, a: AttributeSet? = null) : View(c, a) {
    var session: RoastSession? = null
    var references: List<RoastSession> = emptyList()
    var smoothing: Int = 1

    private val btPaint = paint("#D84315", 5f)
    private val etPaint = paint("#6D4C41", 3f)
    private val refPaint = paint("#9E9E9E", 2f)
    private val gridPaint = paint("#D0D0D0", 1f)
    private val eventPaint = paint("#555555", 1.5f)
    private val fanPaint = paint("#1565C0", 2.5f)
    private val heaterPaint = paint("#EF6C00", 2.5f)
    private val rorPaint = paint("#2E7D32", 3f)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#4E342E"); textSize = 14f }
    private val smallText = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.DKGRAY; textSize = 12f }

    private fun paint(color: String, width: Float) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = Color.parseColor(color); strokeWidth = width; style = Paint.Style.STROKE
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val s = session ?: return
        val current = clean(s.tempLog)
        val refs = references.map { clean(it.tempLog) }.filter { it.size > 1 }
        if (current.size < 2 && refs.isEmpty()) return

        val left = 62f; val right = 18f; val top = 48f
        val tempBottom = height * 0.60f
        val rorTop = tempBottom + 28f
        val rorBottom = height * 0.82f
        val controlTop = rorBottom + 22f
        val bottom = height - 24f
        val plotW = width - left - right
        if (plotW <= 0f || tempBottom <= top || rorBottom <= rorTop) return

        val logs = listOf(current) + refs
        val maxElapsed = logs.maxOfOrNull { it.lastOrNull()?.elapsedSec ?: 0 } ?: 0
        val maxTime = ceil(max(30, maxElapsed) / 30.0).toInt() * 30
        val highest = logs.flatMap { it.flatMap { p -> listOfNotNull(p.bt, p.et) } }.maxOrNull() ?: 220.0
        val maxTemp = if (highest <= 220.0) 220.0 else ceil(highest / 20.0) * 20.0

        fun x(sec: Int) = left + (sec.coerceIn(0, maxTime).toFloat() / maxTime) * plotW
        fun yt(v: Double): Float = tempBottom - (v.coerceIn(0.0, maxTemp) / maxTemp).toFloat() * (tempBottom - top)

        var t = 0.0
        while (t <= maxTemp + 0.1) { c.drawLine(left, yt(t), left + plotW, yt(t), gridPaint); c.drawText("${t.toInt()}°", 5f, yt(t) + 5f, textPaint); t += 20.0 }
        c.drawText("TEMPERATURE", left, 19f, textPaint)
        c.drawText("BT", left + 120f, 19f, btPaint); c.drawText("ET", left + 160f, 19f, etPaint)
        if (refs.isNotEmpty()) c.drawText("REF", left + 205f, 19f, refPaint)

        refs.forEach { drawBt(c, it, ::x, ::yt, refPaint) }
        drawBt(c, current, ::x, ::yt, btPaint)
        drawEt(c, current, ::x, ::yt)

        fun marker(sec: Int?, label: String) {
            if (sec == null || sec !in 0..maxTime) return
            c.drawLine(x(sec), top, x(sec), tempBottom, eventPaint)
            c.drawText("$label ${fmt(sec)}", x(sec) + 3f, top + 15f, smallText)
        }
        marker(s.turningPointSec, "TP"); marker(s.dryEndSec, "DE"); marker(s.firstCrackSec, "FC"); marker(s.dropSec, "DROP")

        // RoR is a separate panel with its own scale. This keeps the BT graph readable.
        val rr = RoastMath.rorSeries(current, 60)
        if (rr.isNotEmpty()) {
            val rrMin = minOf(-2.0, rr.minOf { it.second } - 1.0)
            val rrMax = maxOf(20.0, rr.maxOf { it.second } + 1.0)
            fun yr(v: Double): Float = rorBottom - ((v - rrMin) / (rrMax - rrMin)).toFloat() * (rorBottom - rorTop)
            c.drawText("RoR °C/min", 5f, rorTop + 5f, textPaint)
            c.drawLine(left, yr(0.0), left + plotW, yr(0.0), gridPaint)
            c.drawText("0", 43f, yr(0.0) + 5f, smallText)
            for (i in 1 until rr.size) c.drawLine(x(rr[i-1].first), yr(rr[i-1].second), x(rr[i].first), yr(rr[i].second), rorPaint)
        }

        // One shared time axis aligned with both panels.
        var sec = 0
        while (sec <= maxTime) {
            c.drawLine(x(sec), top, x(sec), bottom - 18f, gridPaint)
            c.drawText(fmt(sec), x(sec) - 14f, bottom, smallText)
            sec += 30
        }

        // Artisan-style control strip: no full-height lines, only compact event bars below the graph.
        c.drawText("CONTROLS", 5f, controlTop + 12f, textPaint)
        c.drawLine(left, controlTop + 2f, left + plotW, controlTop + 2f, gridPaint)
        s.fanChanges.sortedBy { it.elapsedSec }.forEach { q ->
            val xx = x(q.elapsedSec); c.drawLine(xx, controlTop + 2f, xx, controlTop + 18f, fanPaint); c.drawText("F${q.level}", xx + 3f, controlTop + 15f, smallText)
        }
        s.heaterChanges.sortedBy { it.elapsedSec }.forEach { q ->
            val xx = x(q.elapsedSec); c.drawLine(xx, controlTop + 20f, xx, controlTop + 36f, heaterPaint); c.drawText("H${q.level}", xx + 3f, controlTop + 33f, smallText)
        }
        c.drawText("Fan", left, controlTop + 15f, fanPaint); c.drawText("Heater", left, controlTop + 33f, heaterPaint)
    }

    private fun clean(source: List<TempPoint>): List<TempPoint> {
        val sorted = source.sortedBy { it.elapsedSec }
        val filtered = sorted.filter { it.elapsedSec >= 0 && it.bt.isFinite() && it.bt in 0.0..300.0 && (it.et == null || (it.et!!.isFinite() && it.et!! in 0.0..300.0)) }
        return if (smoothing > 1) RoastMath.smooth(filtered, smoothing) else filtered
    }
    private fun drawBt(c: Canvas, log: List<TempPoint>, x: (Int) -> Float, y: (Double) -> Float, p: Paint) { for (i in 1 until log.size) c.drawLine(x(log[i-1].elapsedSec), y(log[i-1].bt), x(log[i].elapsedSec), y(log[i].bt), p) }
    private fun drawEt(c: Canvas, log: List<TempPoint>, x: (Int) -> Float, y: (Double) -> Float) { for (i in 1 until log.size) { val a=log[i-1].et; val b=log[i].et; if(a!=null&&b!=null)c.drawLine(x(log[i-1].elapsedSec),y(a),x(log[i].elapsedSec),y(b),etPaint) } }
    private fun fmt(sec: Int) = "${sec/60}:${(sec%60).toString().padStart(2,'0')}"
}
