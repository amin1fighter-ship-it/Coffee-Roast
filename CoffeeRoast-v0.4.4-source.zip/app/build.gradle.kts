plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace="com.amin1fighter.coffeeroast"
    compileSdk=35
    defaultConfig { applicationId="com.amin1fighter.coffeeroast"; minSdk=26; targetSdk=35; versionCode=40400; versionName="0.4.4" }
    compileOptions { sourceCompatibility=JavaVersion.VERSION_17; targetCompatibility=JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget="17" }
    signingConfigs { create("release") {
        val ks=System.getenv("KEYSTORE_PATH")
        if(!ks.isNullOrBlank()){storeFile=file(ks);storePassword=System.getenv("KEYSTORE_PASSWORD");keyAlias=System.getenv("KEY_ALIAS");keyPassword=System.getenv("KEY_PASSWORD")}
        else if(gradle.startParameter.taskNames.any{it.contains("Release",true)}) error("KEYSTORE_PATH is required for release builds")
    }}
    buildTypes { release { isMinifyEnabled=false; signingConfig=signingConfigs.getByName("release") } }
}
dependencies { implementation("androidx.core:core:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    testImplementation("junit:junit:4.13.2") }
