package com.amin1fighter.coffeeroast

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import kotlin.math.ceil

/** Clean roast chart: temperature is the primary analytical view. RoR/DeltaRoR stay out of the
 * temperature scale so one bad/derived value cannot compress the BT/ET curve. */
class RoastChartView @JvmOverloads constructor(
    c: Context,
    a: AttributeSet? = null
) : View(c, a) {
    var session: RoastSession? = null
    var references: List<RoastSession> = emptyList()
    var smoothing: Int = 1

    private val btPaint = paint("#D84315", 5f)
    private val etPaint = paint("#6D4C41", 3f)
    private val refPaint = paint("#9E9E9E", 2f)
    private val gridPaint = paint("#B0B0B0", 1f)
    private val eventPaint = paint("#555555", 1.5f)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#4E342E")
        textSize = 15f
        style = Paint.Style.FILL
    }

    private fun paint(color: String, width: Float) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = Color.parseColor(color)
        strokeWidth = width
        style = Paint.Style.STROKE
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val s = session ?: return
        val currentLog = clean(s, s.tempLog)
        val refLogs = references.map { clean(it, it.tempLog) }.filter { it.size > 1 }
        if (currentLog.size < 2 && refLogs.isEmpty()) return

        val left = 58f
        val top = 42f
        val right = 18f
        val bottom = 42f
        val plotW = width - left - right
        val plotH = height - top - bottom
        if (plotW <= 0f || plotH <= 0f) return

        val logs = listOf(currentLog) + refLogs
        val maxElapsed = logs.maxOfOrNull { it.lastOrNull()?.elapsedSec ?: 0 } ?: 0
        val maxTime = ceil(maxElapsed / 30.0).toInt().coerceAtLeast(1) * 30

        // Normal coffee roasting lives around 0–220°C. Keep that scale stable.
        // Only expand if real, validated sensor data genuinely exceeds it.
        val highest = logs.flatMap { log -> log.flatMap { listOfNotNull(it.bt, it.et) } }
            .maxOrNull() ?: 220.0
        val maxTemp = if (highest <= 220.0) 220.0 else ceil(highest / 20.0) * 20.0
        val minTemp = 0.0

        fun x(sec: Int): Float = left + (sec.coerceIn(0, maxTime).toFloat() / maxTime) * plotW
        fun y(v: Double): Float = top + plotH - ((v.coerceIn(minTemp, maxTemp) - minTemp) / (maxTemp - minTemp)).toFloat() * plotH

        var t = 0.0
        while (t <= maxTemp + 0.1) {
            c.drawLine(left, y(t), left + plotW, y(t), gridPaint)
            c.drawText("${t.toInt()}°", 5f, y(t) + 5f, textPaint)
            t += 20.0
        }

        var sec = 0
        while (sec <= maxTime) {
            c.drawLine(x(sec), top, x(sec), top + plotH, gridPaint)
            c.drawText("${sec / 60}:${(sec % 60).toString().padStart(2, '0')}", x(sec) - 14f, top + plotH + 25f, textPaint)
            sec += 30
        }

        // Reference curves first, so the active roast remains visually dominant.
        refLogs.forEach { log -> drawBt(c, log, ::x, ::y, refPaint) }
        drawBt(c, currentLog, ::x, ::y, btPaint)
        drawEt(c, currentLog, ::x, ::y)

        fun marker(value: Int?, label: String) {
            if (value == null || value < 0 || value > maxTime) return
            c.drawLine(x(value), top, x(value), top + plotH, eventPaint)
            c.drawText("$label ${value / 60}:${(value % 60).toString().padStart(2, '0')}", x(value) + 3f, top + 17f, textPaint)
        }
        marker(s.turningPointSec, "TP")
        marker(s.dryEndSec, "DE")
        marker(s.firstCrackSec, "FC")
        marker(s.dropSec, "DROP")

        c.drawText("BT", left, 19f, btPaint)
        c.drawText("ET", left + 45f, 19f, etPaint)
        if (refLogs.isNotEmpty()) c.drawText("REF", left + 90f, 19f, refPaint)
    }

    private fun clean(s: RoastSession, source: List<TempPoint>): List<TempPoint> {
        val sorted = source.sortedBy { it.elapsedSec }
        val filtered = sorted.filter { it.elapsedSec >= 0 && it.bt.isFinite() && it.bt in 0.0..300.0 && (it.et == null || (it.et!!.isFinite() && it.et!! in 0.0..300.0)) }
        return if (smoothing > 1) RoastMath.smooth(filtered, smoothing) else filtered
    }

    private fun drawBt(c: Canvas, log: List<TempPoint>, x: (Int) -> Float, y: (Double) -> Float, p: Paint) {
        for (i in 1 until log.size) {
            c.drawLine(x(log[i - 1].elapsedSec), y(log[i - 1].bt), x(log[i].elapsedSec), y(log[i].bt), p)
        }
    }

    private fun drawEt(c: Canvas, log: List<TempPoint>, x: (Int) -> Float, y: (Double) -> Float) {
        for (i in 1 until log.size) {
            val a = log[i - 1].et
            val b = log[i].et
            if (a != null && b != null) c.drawLine(x(log[i - 1].elapsedSec), y(a), x(log[i].elapsedSec), y(b), etPaint)
        }
    }
}
