package com.amin1fighter.coffeeroast

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.widget.*
import java.util.Locale

class MainActivity : Activity() {
    private val points = mutableListOf<Point>()
    private var dry: Double? = null
    private var fc: Double? = null
    private var drop: Double? = null

    private lateinit var chart: RoastChartView
    private lateinit var status: TextView
    private lateinit var time: EditText
    private lateinit var bt: EditText
    private lateinit var et: EditText
    private lateinit var fan: EditText
    private lateinit var heater: EditText
    private lateinit var green: EditText
    private lateinit var roasted: EditText
    private lateinit var density: EditText
    private lateinit var name: EditText

    private var pendingCsv = ""

    private fun field(hint: String): EditText =
        EditText(this).apply {
            this.hint = hint
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or
                    android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        }

    private fun textField(hint: String): EditText =
        EditText(this).apply { this.hint = hint }

    private fun button(label: String, action: () -> Unit) =
        Button(this).apply {
            text = label
            setOnClickListener { action() }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 12, 16, 16)
        }

        name = textField("Coffee / roast name")
        green = field("Green weight (g)")
        roasted = field("Roasted weight (g)")
        density = field("Density (g/L)")
        root.addView(name)
        root.addView(green)
        root.addView(roasted)
        root.addView(density)

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        time = field("Time sec")
        bt = field("BT °C")
        et = field("ET °C")
        fan = field("Fan")
        heater = field("Heater")
        listOf(time, bt, et, fan, heater).forEach {
            row.addView(it, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(row)

        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        controls.addView(button("ADD") { addPoint() })
        controls.addView(button("DRY") { dry = points.lastOrNull()?.sec; refresh() })
        controls.addView(button("FC") { fc = points.lastOrNull()?.sec; refresh() })
        controls.addView(button("DROP") { drop = points.lastOrNull()?.sec; refresh() })
        root.addView(controls)

        chart = RoastChartView(this)
        root.addView(chart, LinearLayout.LayoutParams(-1, 520))

        status = TextView(this).apply { textSize = 16f }
        root.addView(status)

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(button("EXPORT CSV") { exportCsv() })
        actions.addView(button("CLEAR") { clearAll() })
        root.addView(actions)

        scroll.addView(root)
        setContentView(scroll)
    }

    private fun addPoint() {
        val t = time.text.toString().toDoubleOrNull() ?: return
        val b = bt.text.toString().toDoubleOrNull() ?: return
        val e = et.text.toString().toDoubleOrNull() ?: 0.0
        val f = fan.text.toString().toIntOrNull()
        val h = heater.text.toString().toIntOrNull()
        points.add(Point(t, b, e, f, h))
        refresh()
    }

    private fun refresh() {
        chart.points = points
        chart.dry = dry
        chart.fc = fc
        chart.drop = drop
        chart.invalidate()

        if (points.isEmpty()) {
            status.text = "No roast points yet."
            return
        }

        val i = points.lastIndex
        val p = points[i]
        val ror = RoastMath.instantRor(points, i)
        val smooth = RoastMath.smoothRor(points, i)
        val total = drop ?: p.sec
        val dryPct = RoastMath.percent(0.0, dry, total)
        val maiPct = RoastMath.percent(dry, fc, total)
        val devPct = RoastMath.percent(fc, drop, total)
        val loss = RoastMath.weightLoss(
            green.text.toString().toDoubleOrNull() ?: 0.0,
            roasted.text.toString().toDoubleOrNull() ?: 0.0
        )

        status.text = String.format(
            Locale.US,
            "BT %.1f°C   RoR %.1f°C/min   Smooth %.1f°C/min\n" +
                    "%s   |   Dry %.1f%%   Maillard %.1f%%   Dev %.1f%%\n" +
                    "Weight loss %.1f%%   Fan %s   Heater %s",
            p.bt, ror, smooth,
            RoastMath.phase(p.sec, dry, fc, drop),
            dryPct, maiPct, devPct, loss,
            p.fan?.toString() ?: "—",
            p.heater?.toString() ?: "—"
        )
    }

    private fun exportCsv() {
        if (points.isEmpty()) return

        val roastName = name.text.toString().ifBlank { "roast" }
        pendingCsv = buildString {
            append("Time_sec,BT_C,ET_C,RoR_C_min,RoR_Smoothed_C_min,Fan,Heater,Event,Phase\n")
            points.forEachIndexed { i, p ->
                val event = when (p.sec) {
                    dry -> "DRY_END"
                    fc -> "FC_START"
                    drop -> "DROP"
                    else -> ""
                }
                append(String.format(
                    Locale.US,
                    "%.2f,%.2f,%.2f,%.3f,%.3f,%s,%s,%s,%s\n",
                    p.sec, p.bt, p.et,
                    RoastMath.instantRor(points, i),
                    RoastMath.smoothRor(points, i),
                    p.fan?.toString() ?: "",
                    p.heater?.toString() ?: "",
                    event,
                    RoastMath.phase(p.sec, dry, fc, drop)
                ))
            }
        }

        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            type = "text/csv"
            putExtra(Intent.EXTRA_TITLE, "$roastName.csv")
        }
        startActivityForResult(intent, 42)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 42 && resultCode == RESULT_OK && data?.data != null) {
            contentResolver.openOutputStream(data.data!!)?.use {
                it.write(pendingCsv.toByteArray(Charsets.UTF_8))
            }
            Toast.makeText(this, "CSV exported", Toast.LENGTH_SHORT).show()
        }
    }

    private fun clearAll() {
        points.clear()
        dry = null
        fc = null
        drop = null
        refresh()
    }
}
