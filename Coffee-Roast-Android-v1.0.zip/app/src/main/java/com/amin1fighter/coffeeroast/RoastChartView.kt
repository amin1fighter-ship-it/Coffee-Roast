package com.amin1fighter.coffeeroast

import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.max
import kotlin.math.min

class RoastChartView(context: Context) : View(context) {
    var points: List<Point> = emptyList()
    var dry: Double? = null
    var fc: Double? = null
    var drop: Double? = null

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.WHITE)
        if (points.size < 2) return

        val left = 62f
        val right = width - 24f
        val top = 28f
        val bottom = height - 48f
        val maxTime = max(60.0, points.maxOf { it.sec })
        val minTemp = min(60.0, points.minOf { min(it.bt, it.et) })
        val maxTemp = max(220.0, points.maxOf { max(it.bt, it.et) })

        fun x(t: Double) = left + (t / maxTime) * (right - left)
        fun y(v: Double) = bottom - ((v - minTemp) / (maxTemp - minTemp)) * (bottom - top)

        fun curve(selector: (Point) -> Double, color: Int, widthPx: Float) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = widthPx
            paint.color = color
            val path = Path()
            points.forEachIndexed { i, p ->
                val px = x(p.sec).toFloat()
                val py = y(selector(p)).toFloat()
                if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
            }
            canvas.drawPath(path, paint)
        }

        curve({ it.bt }, Color.rgb(95, 55, 35), 4f)
        curve({ it.et }, Color.DKGRAY, 2.5f)

        paint.textSize = 22f
        paint.style = Paint.Style.FILL
        paint.color = Color.DKGRAY
        canvas.drawText("BT", left, 20f, paint)
        canvas.drawText("ET", left + 42f, 20f, paint)

        fun marker(sec: Double?, label: String) {
            if (sec == null) return
            paint.color = Color.GRAY
            paint.strokeWidth = 2f
            canvas.drawLine(x(sec).toFloat(), top, x(sec).toFloat(), bottom, paint)
            paint.textSize = 18f
            canvas.drawText(label, x(sec).toFloat() - 15f, bottom + 27f, paint)
        }
        marker(dry, "DRY")
        marker(fc, "FC")
        marker(drop, "DROP")

        paint.textSize = 16f
        paint.color = Color.GRAY
        canvas.drawText(maxTemp.toInt().toString(), 8f, top + 5f, paint)
        canvas.drawText(minTemp.toInt().toString(), 18f, bottom, paint)
    }
}
