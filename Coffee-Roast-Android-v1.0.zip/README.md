# Coffee Roast

A lightweight Android roast logger designed around a fluid-bed roaster workflow.

## Current features

- BT / ET time-series logging
- Fan and heater values per sample
- Instant RoR and smoothed RoR
- Dry End / First Crack / Drop markers
- Dry / Maillard / Development percentages
- Green/roasted weight loss
- BT/ET chart
- CSV export containing BT, ET, RoR, Fan, Heater, events and phase

## Example workflow

Enter the elapsed time in seconds for each measurement:

`194 sec | BT 199 | ET 190 | Fan 7 | Heater 17`

Mark the last point as DRY, FC or DROP with the event buttons.

## Artisan

The exported CSV is deliberately a clean time-series interchange format. It contains enough information to map the roast into an Artisan profile, but it is not claimed to be a native Artisan `.alog` file. Native Artisan import formats vary by workflow/version, so the next iteration can add a dedicated Artisan importer/exporter once the exact Artisan format used by the user is selected.

## Build

Open the project in Android Studio, or let GitHub Actions build `app-debug.apk`.

The workflow is at `.github/workflows/android-build.yml`.
