# Coffee Roast Lab 0.4.18

## Critical fix: NaN JSON save

Android `org.json` **cannot encode NaN**. Empty optional numbers (`optDouble()` without a default) became NaN in memory, so **every save failed** with:

`JSONException: Forbidden numeric value: NaN`

That is why new beans/roasts vanished after leaving the app.

### 0.4.18
- All numeric JSON writes skip NaN/Infinity (write 0 or null).
- All numeric JSON reads use finite defaults instead of NaN.
- In-memory data is sanitized before every save.
- Load still restores beans/roasts; save now actually succeeds.

Version `0.4.18` / versionCode `41800`.
