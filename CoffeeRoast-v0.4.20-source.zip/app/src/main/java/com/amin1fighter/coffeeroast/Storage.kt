package com.amin1fighter.coffeeroast

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Simple, reliable local JSON storage.
 * Android org.json forbids NaN/Infinity — every numeric write is sanitized.
 */
object Storage {
    const val SCHEMA = 7
    private const val FILE = "coffeeroast_data.json"
    private const val BAK = "coffeeroast_data.json.bak"
    private const val TMP = "coffeeroast_data.json.tmp"

    var beans = mutableListOf<GreenBean>()
    var roasts = mutableListOf<RoastSession>()
    var settings = AppSettings()

    private var nb = 1L
    private var nr = 1L
    private var ng = 1
    private var dir: File? = null
    private var loaded = false

    @Volatile
    var lastStatus: String = "not ready"
        private set

    @Synchronized
    fun init(c: Context) {
        dir = c.filesDir
        if (loaded) return
        loadQuiet()
        loaded = true
    }

    fun newBeanId() = nb++
    fun newRoastId() = nr++
    fun allocateGlobalRoastNumber(): Int {
        val x = ng; ng++; return x
    }

    fun nextBatch(bean: GreenBean) =
        (roasts.filter { it.beanId == bean.id }.maxOfOrNull { it.beanBatchNumber } ?: 0) + 1

    fun beanById(id: Long) = beans.firstOrNull { it.id == id }

    fun dataSummary(): String =
        "beans=${beans.size} roasts=${roasts.size} · $lastStatus"

    @Synchronized
    fun addBean(b: GreenBean): Boolean {
        val added = beans.none { it.id == b.id }
        if (added) beans.add(b)
        val ok = save()
        if (!ok && added) beans.removeAll { it.id == b.id }
        return ok
    }

    fun deleteBean(id: Long): Boolean {
        val related = roasts.filter { it.beanId == id }
        related.filter { !it.isComplete && it.stockReserved }.forEach { r ->
            beanById(id)?.let { it.stockGrams += r.greenWeightG }
        }
        roasts.removeAll { it.beanId == id }
        beans.removeAll { it.id == id }
        beans.forEach { it.totalBatches = roasts.count { r -> r.beanId == it.id } }
        return save()
    }

    @Synchronized
    fun addRoast(r: RoastSession): Boolean {
        val added = roasts.none { it.id == r.id }
        if (added) roasts.add(r)
        val ok = save()
        if (!ok && added) roasts.removeAll { it.id == r.id }
        return ok
    }

    fun deleteRoast(id: Long): Boolean {
        val r = roasts.firstOrNull { it.id == id } ?: return save()
        if (!r.isComplete && r.stockReserved) {
            beanById(r.beanId)?.let { it.stockGrams += r.greenWeightG }
        }
        roasts.removeAll { it.id == id }
        beans.forEach { it.totalBatches = roasts.count { rr -> rr.beanId == it.id } }
        return save()
    }

    /** Persist memory to disk atomically. The previous valid file is kept until the new file is verified. */
    @Synchronized
    fun save(): Boolean {
        val d = dir
        if (d == null) {
            lastStatus = "save: dir null"
            return false
        }
        try {
            if (!d.exists() && !d.mkdirs()) {
                lastStatus = "save: cannot create files directory"
                return false
            }

            sanitizeInMemory()
            val json = toJson().toString()
            if (json.length < 2) {
                lastStatus = "save: empty json"
                return false
            }

            val main = File(d, FILE)
            val tmp = File(d, TMP)
            val bak = File(d, BAK)

            // Write and validate the candidate before touching the current database.
            tmp.outputStream().use { it.write(json.toByteArray(Charsets.UTF_8)); it.flush() }
            val written = tmp.readText(Charsets.UTF_8)
            JSONObject(written)

            // Preserve the last known-good database.
            if (main.exists() && main.length() > 2) {
                main.copyTo(bak, overwrite = true)
            }

            // Files.move(REPLACE_EXISTING) is atomic on filesystems that support it.
            // Android API 26+ supports java.nio.file.Files.
            try {
                Files.move(
                    tmp.toPath(),
                    main.toPath(),
                    StandardCopyOption.REPLACE_EXISTING,
                    StandardCopyOption.ATOMIC_MOVE
                )
            } catch (_: Exception) {
                // Some Android filesystems do not support ATOMIC_MOVE. Do not delete the
                // valid main file first; fall back to a verified copy only when necessary.
                val fallback = File(d, "$TMP.copy")
                tmp.copyTo(fallback, overwrite = true)
                JSONObject(fallback.readText(Charsets.UTF_8))
                if (!fallback.renameTo(main)) {
                    // Last resort: copy over the existing file after validation.
                    fallback.inputStream().use { input ->
                        main.outputStream().use { output -> input.copyTo(output) }
                    }
                    fallback.delete()
                }
                tmp.delete()
            }

            if (!main.exists() || main.length() < 2) {
                lastStatus = "save: verify failed"
                return false
            }
            JSONObject(main.readText(Charsets.UTF_8))

            lastStatus = "OK saved ${beans.size}b/${roasts.size}r ${main.length()}B"
            return true
        } catch (e: Exception) {
            lastStatus = "save error: ${e.javaClass.simpleName}: ${e.message}"
            try {
                val rec = File(d, "coffeeroast_recovery_${System.currentTimeMillis()}.json")
                rec.writeText(toJson().toString(), Charsets.UTF_8)
                lastStatus += " recovery=${rec.name}"
            } catch (_: Exception) {}
            return false
        }
    }

    fun forceSaveAndReport(): String {
        val ok = save()
        return if (ok) "OK: $lastStatus" else "FAIL: $lastStatus"
    }

    private fun loadQuiet() {
        val d = dir ?: run {
            lastStatus = "load: no dir"
            return
        }
        val main = File(d, FILE)
        val bak = File(d, BAK)
        val candidates = mutableListOf<File>()
        if (main.exists()) candidates.add(main)
        if (bak.exists()) candidates.add(bak)
        d.listFiles()?.filter {
            it.name.startsWith("coffeeroast_recovery_") && it.name.endsWith(".json")
        }?.sortedByDescending { it.lastModified() }?.let { candidates.addAll(it) }

        var lastError: Exception? = null
        for (f in candidates) {
            try {
                if (f.length() < 2) continue
                val root = JSONObject(f.readText(Charsets.UTF_8))
                val v = root.optInt("schemaVersion", 1)
                if (v > SCHEMA) continue
                parseRoot(root)
                sanitizeInMemory()
                lastStatus = "loaded from ${f.name} schema=$v ${beans.size}b/${roasts.size}r"
                // Migration is best-effort. Never replace valid in-memory data with empty data.
                save()
                return
            } catch (e: Exception) {
                lastError = e
            }
        }

        // If a database file exists but could not be parsed, preserve it and do NOT create
        // a fresh empty database over it. This is the key data-loss guard.
        if (candidates.isNotEmpty()) {
            beans = mutableListOf()
            roasts = mutableListOf()
            settings = AppSettings()
            nb = 1; nr = 1; ng = 1
            lastStatus = "load failed; existing files preserved${lastError?.let { ": ${it.message}" } ?: ""}"
            return
        }

        beans = mutableListOf()
        roasts = mutableListOf()
        settings = AppSettings()
        nb = 1; nr = 1; ng = 1
        lastStatus = "fresh empty DB"
        save()
    }

    /** org.json throws on NaN/Infinity — never write those. */
    private fun finite(v: Double, fallback: Double = 0.0) = if (v.isFinite()) v else fallback
    private fun finiteOrNull(v: Double?) = v?.takeIf { it.isFinite() }

    private fun JSONObject.putD(key: String, v: Double, fallback: Double = 0.0): JSONObject {
        put(key, finite(v, fallback))
        return this
    }

    private fun JSONObject.putDN(key: String, v: Double?): JSONObject {
        val x = finiteOrNull(v)
        if (x == null) put(key, JSONObject.NULL) else put(key, x)
        return this
    }

    private fun JSONObject.getD(key: String, fallback: Double = 0.0): Double {
        if (!has(key) || isNull(key)) return fallback
        val v = optDouble(key, fallback)
        return if (v.isFinite()) v else fallback
    }

    private fun JSONObject.getDN(key: String): Double? {
        if (!has(key) || isNull(key)) return null
        val v = optDouble(key)
        return if (v.isFinite()) v else null
    }

    private fun sanitizeInMemory() {
        beans.forEach { b ->
            if (!b.price.isFinite()) b.price = 0.0
            if (!b.stockGrams.isFinite()) b.stockGrams = 0.0
            if (b.altitudeMasl != null && !b.altitudeMasl!!.isFinite()) b.altitudeMasl = null
        }
        if (!settings.dryEndTargetC.isFinite()) settings.dryEndTargetC = 150.0
        if (!settings.firstCrackTargetC.isFinite()) settings.firstCrackTargetC = 200.0
        if (!settings.lowRorWarning.isFinite()) settings.lowRorWarning = 10.0
        if (!settings.dropTargetC.isFinite()) settings.dropTargetC = 205.0
        roasts.forEach { r ->
            if (!r.greenWeightG.isFinite()) r.greenWeightG = 0.0
            r.roastedWeightG = finiteOrNull(r.roastedWeightG)
            r.densityGPerL = finiteOrNull(r.densityGPerL)
            r.roastedRemainingG = finiteOrNull(r.roastedRemainingG)
            r.tasting?.let { t ->
                if (!t.fragrance.isFinite()) t.fragrance = 0.0
                if (!t.flavor.isFinite()) t.flavor = 0.0
                if (!t.aftertaste.isFinite()) t.aftertaste = 0.0
                if (!t.acidity.isFinite()) t.acidity = 0.0
                if (!t.body.isFinite()) t.body = 0.0
                if (!t.balance.isFinite()) t.balance = 0.0
                if (!t.sweetness.isFinite()) t.sweetness = 0.0
                if (!t.cleanCup.isFinite()) t.cleanCup = 0.0
                if (!t.uniformity.isFinite()) t.uniformity = 0.0
                if (!t.overall.isFinite()) t.overall = 0.0
            }
            val log = r.tempLog.mapNotNull { p ->
                if (!p.bt.isFinite()) null
                else TempPoint(p.elapsedSec, p.bt, finiteOrNull(p.et))
            }
            r.tempLog.clear()
            r.tempLog.addAll(log)
            fun cleanChanges(src: MutableList<SettingChange>) {
                val next = src.map {
                    SettingChange(it.elapsedSec, finite(it.btAtChange, 0.0), it.level)
                }
                src.clear()
                src.addAll(next)
            }
            cleanChanges(r.fanChanges)
            cleanChanges(r.heaterChanges)
        }
    }

    private fun toJson(): JSONObject {
        val root = JSONObject()
            .put("schemaVersion", SCHEMA)
            .put("nextBeanId", nb)
            .put("nextRoastId", nr)
            .put("nextGlobalRoastNumber", ng)

        root.put(
            "settings",
            JSONObject()
                .put("temperatureUnit", settings.temperatureUnit)
                .put("weightUnit", settings.weightUnit)
                .put("language", settings.language)
                .put("logIntervalSec", settings.logIntervalSec)
                .putD("dryEndTargetC", settings.dryEndTargetC, 150.0)
                .putD("firstCrackTargetC", settings.firstCrackTargetC, 200.0)
                .putD("lowRorWarning", settings.lowRorWarning, 10.0)
                .putD("dropTargetC", settings.dropTargetC, 205.0)
                .put("theme", settings.theme)
                .put("defaultRestDays", settings.defaultRestDays)
        )

        val ba = JSONArray()
        beans.forEach { b ->
            ba.put(JSONObject().apply {
                put("id", b.id); put("name", b.name); put("origin", b.origin)
                put("process", b.process); put("notes", b.notes); put("supplier", b.supplier)
                put("purchaseDate", b.purchaseDate)
                putD("price", b.price)
                put("harvestYear", b.harvestYear)
                putDN("altitudeMasl", b.altitudeMasl)
                put("variety", b.variety); put("storageLocation", b.storageLocation)
                putD("stockGrams", b.stockGrams); put("totalBatches", b.totalBatches)
            })
        }
        root.put("beans", ba)

        val ra = JSONArray()
        roasts.forEach { r -> ra.put(roastJson(r)) }
        root.put("roasts", ra)
        return root
    }

    private fun roastJson(r: RoastSession) = JSONObject().apply {
        put("id", r.id); put("globalRoastNumber", r.globalRoastNumber); put("beanId", r.beanId)
        put("beanBatchNumber", r.beanBatchNumber)
        putD("greenWeightG", r.greenWeightG)
        putDN("roastedWeightG", r.roastedWeightG)
        putDN("densityGPerL", r.densityGPerL)
        put("startFan", r.startFan); put("startHeater", r.startHeater)
        put("dryEndSec", r.dryEndSec ?: JSONObject.NULL)
        put("turningPointSec", r.turningPointSec ?: JSONObject.NULL)
        put("firstCrackSec", r.firstCrackSec ?: JSONObject.NULL)
        put("secondCrackSec", r.secondCrackSec ?: JSONObject.NULL)
        put("dropSec", r.dropSec ?: JSONObject.NULL)
        put("startTimeMillis", r.startTimeMillis); put("startElapsedRealtime", r.startElapsedRealtime)
        put("isComplete", r.isComplete); put("isHistorical", r.isHistorical)
        put("stockReserved", r.stockReserved); put("targetStyle", r.targetStyle)
        put("roasterName", r.roasterName); put("notes", r.notes)
        put("referenceRoastId", r.referenceRoastId ?: JSONObject.NULL)
        put("restingDays", r.restingDays)
        putDN("roastedRemainingG", r.roastedRemainingG)
        put("tasting", r.tasting?.let { tastingJson(it) } ?: JSONObject.NULL)
        put("fanChanges", changes(r.fanChanges)); put("heaterChanges", changes(r.heaterChanges))
        put("tempLog", JSONArray().apply {
            r.tempLog.forEach {
                put(
                    JSONObject()
                        .put("elapsedSec", it.elapsedSec)
                        .putD("bt", it.bt)
                        .putDN("et", it.et)
                )
            }
        })
    }

    private fun tastingJson(t: TastingScore) = JSONObject().apply {
        putD("fragrance", t.fragrance); putD("flavor", t.flavor); putD("aftertaste", t.aftertaste)
        putD("acidity", t.acidity); putD("body", t.body); putD("balance", t.balance)
        putD("sweetness", t.sweetness); putD("cleanCup", t.cleanCup); putD("uniformity", t.uniformity)
        putD("overall", t.overall); put("notes", t.notes)
    }

    private fun changes(x: List<SettingChange>) = JSONArray().apply {
        x.forEach {
            put(
                JSONObject()
                    .put("elapsedSec", it.elapsedSec)
                    .putD("btAtChange", it.btAtChange)
                    .put("level", it.level)
            )
        }
    }

    private fun parseRoot(root: JSONObject) {
        val v = root.optInt("schemaVersion", 1)
        if (v > SCHEMA) throw IllegalStateException("schema $v > $SCHEMA")

        nb = root.optLong("nextBeanId", 1)
        nr = root.optLong("nextRoastId", 1)
        ng = root.optInt("nextGlobalRoastNumber", 1)

        val s = root.optJSONObject("settings")
        if (s != null) {
            settings = AppSettings(
                s.optString("temperatureUnit", "C"),
                s.optString("weightUnit", "g"),
                s.optString("language", "en"),
                s.optInt("logIntervalSec", 30),
                s.getD("dryEndTargetC", 150.0),
                s.getD("firstCrackTargetC", 200.0),
                s.getD("lowRorWarning", 10.0),
                s.getD("dropTargetC", 205.0),
                s.optString("theme", "system"),
                s.optInt("defaultRestDays", 7)
            )
        }

        val loadedBeans = mutableListOf<GreenBean>()
        val ba = root.optJSONArray("beans")
        for (i in 0 until (ba?.length() ?: 0)) {
            val o = ba!!.getJSONObject(i)
            loadedBeans.add(
                GreenBean(
                    o.getLong("id"), o.optString("name"), o.optString("origin"), o.optString("process"),
                    o.optString("notes"), o.optString("supplier"), o.optString("purchaseDate"),
                    o.getD("price"), o.optString("harvestYear"),
                    o.getDN("altitudeMasl"),
                    o.optString("variety"), o.optString("storageLocation"),
                    o.getD("stockGrams"), o.optInt("totalBatches")
                )
            )
        }

        val loadedRoasts = mutableListOf<RoastSession>()
        val ra = root.optJSONArray("roasts")
        for (i in 0 until (ra?.length() ?: 0)) {
            val o = ra!!.getJSONObject(i)
            val r = RoastSession(
                o.getLong("id"), o.optInt("globalRoastNumber"), o.getLong("beanId"),
                o.optInt("beanBatchNumber"), o.getD("greenWeightG"),
                o.getDN("roastedWeightG"),
                o.getDN("densityGPerL"),
                o.optInt("startFan"), o.optInt("startHeater")
            )
            r.dryEndSec = ni(o, "dryEndSec")
            r.turningPointSec = ni(o, "turningPointSec")
            r.firstCrackSec = ni(o, "firstCrackSec")
            r.secondCrackSec = ni(o, "secondCrackSec")
            r.dropSec = ni(o, "dropSec")
            r.startTimeMillis = o.optLong("startTimeMillis")
            r.startElapsedRealtime = o.optLong("startElapsedRealtime", 0L)
            r.isComplete = o.optBoolean("isComplete")
            r.isHistorical = o.optBoolean("isHistorical")
            r.stockReserved = if (o.has("stockReserved")) o.optBoolean("stockReserved")
            else !r.isComplete && !r.isHistorical
            r.targetStyle = o.optString("targetStyle", "specialty").ifBlank { "specialty" }
            r.roasterName = o.optString("roasterName")
            r.notes = o.optString("notes")
            r.referenceRoastId = nl(o, "referenceRoastId")
            r.restingDays = o.optInt("restingDays", settings.defaultRestDays)
            r.roastedRemainingG = o.getDN("roastedRemainingG")
            val t = o.optJSONObject("tasting")
            if (t != null) {
                r.tasting = TastingScore(
                    t.getD("fragrance"), t.getD("flavor"), t.getD("aftertaste"),
                    t.getD("acidity"), t.getD("body"), t.getD("balance"),
                    t.getD("sweetness"), t.getD("cleanCup"), t.getD("uniformity"),
                    t.getD("overall"), t.optString("notes")
                )
            }
            loadChanges(o.optJSONArray("fanChanges"), r.fanChanges)
            loadChanges(o.optJSONArray("heaterChanges"), r.heaterChanges)
            val ta = o.optJSONArray("tempLog")
            for (k in 0 until (ta?.length() ?: 0)) {
                val q = ta!!.getJSONObject(k)
                val bt = q.getD("bt")
                r.tempLog.add(TempPoint(q.optInt("elapsedSec"), bt, q.getDN("et")))
            }
            loadedRoasts.add(r)
        }

        beans = loadedBeans
        roasts = loadedRoasts
        nb = maxOf(nb, (beans.maxOfOrNull { it.id } ?: 0) + 1)
        nr = maxOf(nr, (roasts.maxOfOrNull { it.id } ?: 0) + 1)
        ng = maxOf(ng, (roasts.maxOfOrNull { it.globalRoastNumber } ?: 0) + 1)
        beans.forEach { it.totalBatches = roasts.count { r -> r.beanId == it.id } }
    }

    private fun ni(o: JSONObject, k: String) = if (o.isNull(k)) null else o.optInt(k)
    private fun nl(o: JSONObject, k: String) = if (o.isNull(k)) null else o.optLong(k)

    private fun loadChanges(a: JSONArray?, out: MutableList<SettingChange>) {
        for (i in 0 until (a?.length() ?: 0)) {
            val o = a!!.getJSONObject(i)
            out.add(SettingChange(o.optInt("elapsedSec"), o.getD("btAtChange"), o.optInt("level")))
        }
    }

    @Synchronized
    fun exportBackup(context: Context, out: File): Boolean {
        return try {
            if (!save()) return false
            sanitizeInMemory()
            val tmp = File(out.parentFile ?: context.cacheDir, out.name + ".tmp")
            if (tmp.exists()) tmp.delete()
            ZipOutputStream(tmp.outputStream()).use { z ->
                z.putNextEntry(ZipEntry(FILE))
                z.write(toJson().toString().toByteArray(Charsets.UTF_8))
                z.closeEntry()
            }
            // Verify the archive before exposing it to the share flow.
            ZipInputStream(tmp.inputStream()).use { z ->
                var found = false
                var entry = z.nextEntry
                while (entry != null) {
                    if (entry.name == FILE) {
                        JSONObject(z.readBytes().toString(Charsets.UTF_8))
                        found = true
                        break
                    }
                    entry = z.nextEntry
                }
                if (!found) throw IllegalStateException("backup JSON missing")
            }
            if (out.exists()) out.delete()
            if (!tmp.renameTo(out)) {
                tmp.copyTo(out, overwrite = true)
                tmp.delete()
            }
            lastStatus = "backup OK ${out.length()}B"
            true
        } catch (e: Exception) {
            lastStatus = "backup error: ${e.javaClass.simpleName}: ${e.message}"
            try { File(dir, "coffeeroast_backup_error.log").writeText(e.stackTraceToString()) } catch (_: Exception) {}
            false
        }
    }

    fun importBackup(context: Context, src: File) {
        val d = dir ?: throw IllegalStateException("not initialized")
        val extracted = File(d, "coffeeroast_import.json")
        try {
            ZipInputStream(src.inputStream()).use { z ->
                var e = z.nextEntry
                while (e != null) {
                    val name = e.name.substringAfterLast('/')
                    if (name == FILE || name == "coffeeroast_data.json") {
                        extracted.outputStream().use { z.copyTo(it) }
                        break
                    }
                    e = z.nextEntry
                }
            }
            if (!extracted.exists()) throw IllegalArgumentException("No data in backup ZIP")
            val candidate = JSONObject(extracted.readText(Charsets.UTF_8))
            parseRoot(candidate)
            sanitizeInMemory()
            if (!save()) throw IllegalStateException("Import ok but disk save failed: $lastStatus")
        } finally {
            try {
                extracted.delete()
            } catch (_: Exception) {
            }
        }
    }

    fun rawJson(): String {
        sanitizeInMemory()
        return toJson().toString()
    }
}
