# Coffee Roast Lab 0.4.17

Stability release focused on **never crashing** and **always persisting**.

### Storage
- `save()` / `load()` never throw
- `addBean` / `addRoast` never throw; return false on disk failure
- Simple write path: TMP → BAK → main, then verify parse
- Loads main, then bak, then recovery files

### UI
- All saves go through `saveSafe` with Toast on failure
- Storage status on home screen
- Force-save diagnostics on Backup screen

Version `0.4.17` / versionCode `41700`.
