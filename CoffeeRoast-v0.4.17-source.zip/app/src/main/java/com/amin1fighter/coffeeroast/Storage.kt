package com.amin1fighter.coffeeroast

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Simple, reliable local JSON storage.
 * - save() NEVER throws
 * - load() NEVER throws
 * - addBean/addRoast never throw (return false on disk failure; data still in memory)
 */
object Storage {
    const val SCHEMA = 7
    private const val FILE = "coffeeroast_data.json"
    private const val BAK = "coffeeroast_data.json.bak"
    private const val TMP = "coffeeroast_data.json.tmp"

    var beans = mutableListOf<GreenBean>()
    var roasts = mutableListOf<RoastSession>()
    var settings = AppSettings()

    private var nb = 1L
    private var nr = 1L
    private var ng = 1
    private var dir: File? = null
    private var loaded = false

    @Volatile
    var lastStatus: String = "not ready"
        private set

    fun init(c: Context) {
        dir = c.filesDir
        if (loaded) return
        loaded = true
        loadQuiet()
    }

    fun newBeanId() = nb++
    fun newRoastId() = nr++
    fun allocateGlobalRoastNumber(): Int {
        val x = ng; ng++; return x
    }

    fun nextBatch(bean: GreenBean) =
        (roasts.filter { it.beanId == bean.id }.maxOfOrNull { it.beanBatchNumber } ?: 0) + 1

    fun beanById(id: Long) = beans.firstOrNull { it.id == id }

    fun dataSummary(): String =
        "beans=${beans.size} roasts=${roasts.size} · $lastStatus"

    /** Returns true if disk write succeeded. Never throws. */
    fun addBean(b: GreenBean): Boolean {
        if (beans.none { it.id == b.id }) beans.add(b)
        return save()
    }

    fun deleteBean(id: Long): Boolean {
        val related = roasts.filter { it.beanId == id }
        related.filter { !it.isComplete && it.stockReserved }.forEach { r ->
            beanById(id)?.let { it.stockGrams += r.greenWeightG }
        }
        roasts.removeAll { it.beanId == id }
        beans.removeAll { it.id == id }
        beans.forEach { it.totalBatches = roasts.count { r -> r.beanId == it.id } }
        return save()
    }

    fun addRoast(r: RoastSession): Boolean {
        if (roasts.none { it.id == r.id }) roasts.add(r)
        return save()
    }

    fun deleteRoast(id: Long): Boolean {
        val r = roasts.firstOrNull { it.id == id } ?: return save()
        if (!r.isComplete && r.stockReserved) {
            beanById(r.beanId)?.let { it.stockGrams += r.greenWeightG }
        }
        roasts.removeAll { it.id == id }
        beans.forEach { it.totalBatches = roasts.count { rr -> rr.beanId == it.id } }
        return save()
    }

    /**
     * Write memory → disk. Never throws.
     * Strategy: write TMP → copy main to BAK → copy TMP to main → delete TMP → verify.
     */
    @Synchronized
    fun save(): Boolean {
        val d = dir
        if (d == null) {
            lastStatus = "save: dir null"
            return false
        }
        try {
            if (!d.exists()) d.mkdirs()
            val json = toJson().toString()
            if (json.length < 2) {
                lastStatus = "save: empty json"
                return false
            }
            val tmp = File(d, TMP)
            val main = File(d, FILE)
            val bak = File(d, BAK)

            tmp.writeText(json, Charsets.UTF_8)

            if (main.exists() && main.length() > 2) {
                try {
                    main.copyTo(bak, overwrite = true)
                } catch (_: Exception) {
                }
            }

            // Prefer rename; fall back to copy
            if (main.exists()) {
                try {
                    main.delete()
                } catch (_: Exception) {
                }
            }
            val renamed = try {
                tmp.renameTo(main)
            } catch (_: Exception) {
                false
            }
            if (!renamed) {
                tmp.copyTo(main, overwrite = true)
                tmp.delete()
            }

            // Verify
            if (!main.exists() || main.length() < 2) {
                lastStatus = "save: verify failed size=${if (main.exists()) main.length() else -1}"
                return false
            }
            try {
                JSONObject(main.readText(Charsets.UTF_8))
            } catch (e: Exception) {
                lastStatus = "save: verify parse failed ${e.message}"
                return false
            }

            lastStatus = "OK saved ${beans.size}b/${roasts.size}r ${main.length()}B"
            return true
        } catch (e: Exception) {
            lastStatus = "save error: ${e.javaClass.simpleName}: ${e.message}"
            // Best-effort recovery dump
            try {
                val rec = File(d, "coffeeroast_recovery_${System.currentTimeMillis()}.json")
                rec.writeText(toJson().toString(), Charsets.UTF_8)
                lastStatus += " recovery=${rec.name}"
            } catch (_: Exception) {
            }
            return false
        }
    }

    fun forceSaveAndReport(): String {
        val ok = save()
        return if (ok) "OK: $lastStatus" else "FAIL: $lastStatus"
    }

    private fun loadQuiet() {
        val d = dir ?: run {
            lastStatus = "load: no dir"
            return
        }
        val candidates = mutableListOf<File>()
        val main = File(d, FILE)
        val bak = File(d, BAK)
        if (main.exists()) candidates.add(main)
        if (bak.exists()) candidates.add(bak)
        d.listFiles()?.filter {
            it.name.startsWith("coffeeroast_recovery_") && it.name.endsWith(".json")
        }?.sortedByDescending { it.lastModified() }?.let { candidates.addAll(it) }

        for (f in candidates) {
            try {
                if (f.length() < 2) continue
                val root = JSONObject(f.readText(Charsets.UTF_8))
                val v = root.optInt("schemaVersion", 1)
                if (v > SCHEMA) continue
                parseRoot(root)
                lastStatus = "loaded from ${f.name} schema=$v ${beans.size}b/${roasts.size}r"
                if (v < SCHEMA || f != main) {
                    save() // migrate / restore to main
                }
                return
            } catch (_: Exception) {
                // try next candidate
            }
        }
        // Fresh install or nothing readable
        beans = mutableListOf()
        roasts = mutableListOf()
        settings = AppSettings()
        nb = 1; nr = 1; ng = 1
        lastStatus = "fresh empty DB"
        save()
    }

    private fun toJson(): JSONObject {
        val root = JSONObject()
            .put("schemaVersion", SCHEMA)
            .put("nextBeanId", nb)
            .put("nextRoastId", nr)
            .put("nextGlobalRoastNumber", ng)

        root.put(
            "settings",
            JSONObject()
                .put("temperatureUnit", settings.temperatureUnit)
                .put("weightUnit", settings.weightUnit)
                .put("language", settings.language)
                .put("logIntervalSec", settings.logIntervalSec)
                .put("dryEndTargetC", settings.dryEndTargetC)
                .put("firstCrackTargetC", settings.firstCrackTargetC)
                .put("lowRorWarning", settings.lowRorWarning)
                .put("dropTargetC", settings.dropTargetC)
                .put("theme", settings.theme)
                .put("defaultRestDays", settings.defaultRestDays)
        )

        val ba = JSONArray()
        beans.forEach { b ->
            ba.put(JSONObject().apply {
                put("id", b.id); put("name", b.name); put("origin", b.origin)
                put("process", b.process); put("notes", b.notes); put("supplier", b.supplier)
                put("purchaseDate", b.purchaseDate); put("price", b.price)
                put("harvestYear", b.harvestYear)
                put("altitudeMasl", b.altitudeMasl ?: JSONObject.NULL)
                put("variety", b.variety); put("storageLocation", b.storageLocation)
                put("stockGrams", b.stockGrams); put("totalBatches", b.totalBatches)
            })
        }
        root.put("beans", ba)

        val ra = JSONArray()
        roasts.forEach { r -> ra.put(roastJson(r)) }
        root.put("roasts", ra)
        return root
    }

    private fun roastJson(r: RoastSession) = JSONObject().apply {
        put("id", r.id); put("globalRoastNumber", r.globalRoastNumber); put("beanId", r.beanId)
        put("beanBatchNumber", r.beanBatchNumber); put("greenWeightG", r.greenWeightG)
        put("roastedWeightG", r.roastedWeightG ?: JSONObject.NULL)
        put("densityGPerL", r.densityGPerL ?: JSONObject.NULL)
        put("startFan", r.startFan); put("startHeater", r.startHeater)
        put("dryEndSec", r.dryEndSec ?: JSONObject.NULL)
        put("turningPointSec", r.turningPointSec ?: JSONObject.NULL)
        put("firstCrackSec", r.firstCrackSec ?: JSONObject.NULL)
        put("secondCrackSec", r.secondCrackSec ?: JSONObject.NULL)
        put("dropSec", r.dropSec ?: JSONObject.NULL)
        put("startTimeMillis", r.startTimeMillis); put("startElapsedRealtime", r.startElapsedRealtime)
        put("isComplete", r.isComplete); put("isHistorical", r.isHistorical)
        put("stockReserved", r.stockReserved); put("targetStyle", r.targetStyle)
        put("roasterName", r.roasterName); put("notes", r.notes)
        put("referenceRoastId", r.referenceRoastId ?: JSONObject.NULL)
        put("restingDays", r.restingDays)
        put("roastedRemainingG", r.roastedRemainingG ?: JSONObject.NULL)
        put("tasting", r.tasting?.let { tastingJson(it) } ?: JSONObject.NULL)
        put("fanChanges", changes(r.fanChanges)); put("heaterChanges", changes(r.heaterChanges))
        put("tempLog", JSONArray().apply {
            r.tempLog.forEach {
                put(JSONObject().put("elapsedSec", it.elapsedSec).put("bt", it.bt).put("et", it.et ?: JSONObject.NULL))
            }
        })
    }

    private fun tastingJson(t: TastingScore) = JSONObject().apply {
        put("fragrance", t.fragrance); put("flavor", t.flavor); put("aftertaste", t.aftertaste)
        put("acidity", t.acidity); put("body", t.body); put("balance", t.balance)
        put("sweetness", t.sweetness); put("cleanCup", t.cleanCup); put("uniformity", t.uniformity)
        put("overall", t.overall); put("notes", t.notes)
    }

    private fun changes(x: List<SettingChange>) = JSONArray().apply {
        x.forEach {
            put(JSONObject().put("elapsedSec", it.elapsedSec).put("btAtChange", it.btAtChange).put("level", it.level))
        }
    }

    private fun parseRoot(root: JSONObject) {
        val v = root.optInt("schemaVersion", 1)
        if (v > SCHEMA) throw IllegalStateException("schema $v > $SCHEMA")

        nb = root.optLong("nextBeanId", 1)
        nr = root.optLong("nextRoastId", 1)
        ng = root.optInt("nextGlobalRoastNumber", 1)

        val s = root.optJSONObject("settings")
        if (s != null) {
            settings = AppSettings(
                s.optString("temperatureUnit", "C"),
                s.optString("weightUnit", "g"),
                s.optString("language", "en"),
                s.optInt("logIntervalSec", 30),
                s.optDouble("dryEndTargetC", 150.0),
                s.optDouble("firstCrackTargetC", 200.0),
                s.optDouble("lowRorWarning", 10.0),
                s.optDouble("dropTargetC", 205.0),
                s.optString("theme", "system"),
                s.optInt("defaultRestDays", 7)
            )
        }

        val loadedBeans = mutableListOf<GreenBean>()
        val ba = root.optJSONArray("beans")
        for (i in 0 until (ba?.length() ?: 0)) {
            val o = ba!!.getJSONObject(i)
            loadedBeans.add(
                GreenBean(
                    o.getLong("id"), o.optString("name"), o.optString("origin"), o.optString("process"),
                    o.optString("notes"), o.optString("supplier"), o.optString("purchaseDate"),
                    o.optDouble("price"), o.optString("harvestYear"),
                    if (o.isNull("altitudeMasl")) null else o.optDouble("altitudeMasl"),
                    o.optString("variety"), o.optString("storageLocation"),
                    o.optDouble("stockGrams"), o.optInt("totalBatches")
                )
            )
        }

        val loadedRoasts = mutableListOf<RoastSession>()
        val ra = root.optJSONArray("roasts")
        for (i in 0 until (ra?.length() ?: 0)) {
            val o = ra!!.getJSONObject(i)
            val r = RoastSession(
                o.getLong("id"), o.optInt("globalRoastNumber"), o.getLong("beanId"),
                o.optInt("beanBatchNumber"), o.optDouble("greenWeightG"),
                if (o.isNull("roastedWeightG")) null else o.optDouble("roastedWeightG"),
                if (o.isNull("densityGPerL")) null else o.optDouble("densityGPerL"),
                o.optInt("startFan"), o.optInt("startHeater")
            )
            r.dryEndSec = ni(o, "dryEndSec")
            r.turningPointSec = ni(o, "turningPointSec")
            r.firstCrackSec = ni(o, "firstCrackSec")
            r.secondCrackSec = ni(o, "secondCrackSec")
            r.dropSec = ni(o, "dropSec")
            r.startTimeMillis = o.optLong("startTimeMillis")
            r.startElapsedRealtime = o.optLong("startElapsedRealtime", 0L)
            r.isComplete = o.optBoolean("isComplete")
            r.isHistorical = o.optBoolean("isHistorical")
            r.stockReserved = if (o.has("stockReserved")) o.optBoolean("stockReserved")
            else !r.isComplete && !r.isHistorical
            r.targetStyle = o.optString("targetStyle", "specialty").ifBlank { "specialty" }
            r.roasterName = o.optString("roasterName")
            r.notes = o.optString("notes")
            r.referenceRoastId = nl(o, "referenceRoastId")
            r.restingDays = o.optInt("restingDays", settings.defaultRestDays)
            r.roastedRemainingG = if (o.isNull("roastedRemainingG")) null else o.optDouble("roastedRemainingG")
            val t = o.optJSONObject("tasting")
            if (t != null) {
                r.tasting = TastingScore(
                    t.optDouble("fragrance"), t.optDouble("flavor"), t.optDouble("aftertaste"),
                    t.optDouble("acidity"), t.optDouble("body"), t.optDouble("balance"),
                    t.optDouble("sweetness"), t.optDouble("cleanCup"), t.optDouble("uniformity"),
                    t.optDouble("overall"), t.optString("notes")
                )
            }
            loadChanges(o.optJSONArray("fanChanges"), r.fanChanges)
            loadChanges(o.optJSONArray("heaterChanges"), r.heaterChanges)
            val ta = o.optJSONArray("tempLog")
            for (k in 0 until (ta?.length() ?: 0)) {
                val q = ta!!.getJSONObject(k)
                r.tempLog.add(
                    TempPoint(
                        q.optInt("elapsedSec"), q.optDouble("bt"),
                        if (q.isNull("et") || !q.has("et")) null else q.optDouble("et")
                    )
                )
            }
            loadedRoasts.add(r)
        }

        beans = loadedBeans
        roasts = loadedRoasts
        nb = maxOf(nb, (beans.maxOfOrNull { it.id } ?: 0) + 1)
        nr = maxOf(nr, (roasts.maxOfOrNull { it.id } ?: 0) + 1)
        ng = maxOf(ng, (roasts.maxOfOrNull { it.globalRoastNumber } ?: 0) + 1)
        beans.forEach { it.totalBatches = roasts.count { r -> r.beanId == it.id } }
    }

    private fun ni(o: JSONObject, k: String) = if (o.isNull(k)) null else o.optInt(k)
    private fun nl(o: JSONObject, k: String) = if (o.isNull(k)) null else o.optLong(k)

    private fun loadChanges(a: JSONArray?, out: MutableList<SettingChange>) {
        for (i in 0 until (a?.length() ?: 0)) {
            val o = a!!.getJSONObject(i)
            out.add(SettingChange(o.optInt("elapsedSec"), o.optDouble("btAtChange"), o.optInt("level")))
        }
    }

    fun exportBackup(context: Context, out: File) {
        ZipOutputStream(out.outputStream()).use { z ->
            z.putNextEntry(ZipEntry(FILE))
            z.write(toJson().toString().toByteArray(Charsets.UTF_8))
            z.closeEntry()
        }
    }

    fun importBackup(context: Context, src: File) {
        val d = dir ?: throw IllegalStateException("not initialized")
        val extracted = File(d, "coffeeroast_import.json")
        try {
            ZipInputStream(src.inputStream()).use { z ->
                var e = z.nextEntry
                while (e != null) {
                    val name = e.name.substringAfterLast('/')
                    if (name == FILE || name == "coffeeroast_data.json") {
                        extracted.outputStream().use { z.copyTo(it) }
                        break
                    }
                    e = z.nextEntry
                }
            }
            if (!extracted.exists()) throw IllegalArgumentException("No data in backup ZIP")
            val candidate = JSONObject(extracted.readText(Charsets.UTF_8))
            parseRoot(candidate)
            if (!save()) throw IllegalStateException("Import ok but disk save failed: $lastStatus")
        } finally {
            try {
                extracted.delete()
            } catch (_: Exception) {
            }
        }
    }

    fun rawJson() = toJson().toString()
}
