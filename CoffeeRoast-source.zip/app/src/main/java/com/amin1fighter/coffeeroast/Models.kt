package com.amin1fighter.coffeeroast

data class GreenBean(
    val id: Long,
    var name: String,
    var origin: String = "",
    var process: String = "",
    var notes: String = "",
    var stockGrams: Double = 0.0,
    var totalBatches: Int = 0
)

data class TempPoint(
    val elapsedSec: Int,
    val bt: Double,
    val et: Double
)

data class SettingChange(
    val elapsedSec: Int,
    val btAtChange: Double,
    val level: Int
)

data class RoastSession(
    val id: Long,
    val globalRoastNumber: Int,
    val beanId: Long,
    val beanBatchNumber: Int,
    var greenWeightG: Double,
    var roastedWeightG: Double? = null,
    var densityGPerL: Double? = null,
    var startFan: Int,
    var startHeater: Int,
    val fanChanges: MutableList<SettingChange> = mutableListOf(),
    val heaterChanges: MutableList<SettingChange> = mutableListOf(),
    val tempLog: MutableList<TempPoint> = mutableListOf(),
    var dryEndSec: Int? = null,
    var firstCrackSec: Int? = null,
    var dropSec: Int? = null,
    var startTimeMillis: Long = 0L,
    var isComplete: Boolean = false
)
