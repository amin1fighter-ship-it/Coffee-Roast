package com.amin1fighter.coffeeroast

object RoastMath {

    /**
     * Rate of rise of BT, in degrees per minute, using the trailing point
     * closest to (now - windowSec) as the reference - the same idea Artisan
     * uses for its projected/instant RoR.
     */
    fun currentRor(tempLog: List<TempPoint>, windowSec: Int = 60): Double? {
        if (tempLog.size < 2) return null
        val last = tempLog.last()
        val targetSec = last.elapsedSec - windowSec

        var best: TempPoint? = null
        var bestDiff = Int.MAX_VALUE
        for (p in tempLog) {
            if (p.elapsedSec >= last.elapsedSec) continue
            val diff = kotlin.math.abs(p.elapsedSec - targetSec)
            if (diff < bestDiff) {
                bestDiff = diff
                best = p
            }
        }
        val ref = best ?: tempLog[tempLog.size - 2]
        val dtSec = last.elapsedSec - ref.elapsedSec
        if (dtSec <= 0) return null
        val dBt = last.bt - ref.bt
        return dBt * 60.0 / dtSec
    }

    fun weightLossPercent(greenG: Double, roastedG: Double): Double? {
        if (greenG <= 0.0) return null
        return (greenG - roastedG) / greenG * 100.0
    }

    data class PhasePercents(
        val dryingPercent: Double?,
        val maillardPercent: Double?,
        val developmentPercent: Double?
    )

    /**
     * Percentage breakdown of the roast timeline.
     * - dryingPercent: start -> dry end (only if dryEndSec was marked)
     * - maillardPercent: dry end (or start) -> first crack
     * - developmentPercent: first crack -> drop (the "development time ratio")
     */
    fun phasePercents(startSec: Int, dryEndSec: Int?, firstCrackSec: Int?, dropSec: Int?): PhasePercents {
        if (dropSec == null || dropSec <= startSec) {
            return PhasePercents(null, null, null)
        }
        val total = (dropSec - startSec).toDouble()

        var drying: Double? = null
        var maillard: Double? = null
        var development: Double? = null

        if (firstCrackSec != null) {
            development = (dropSec - firstCrackSec) / total * 100.0
            if (dryEndSec != null) {
                drying = (dryEndSec - startSec) / total * 100.0
                maillard = (firstCrackSec - dryEndSec) / total * 100.0
            } else {
                maillard = (firstCrackSec - startSec) / total * 100.0
            }
        }
        return PhasePercents(drying, maillard, development)
    }
}
