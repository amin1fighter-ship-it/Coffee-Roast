package com.amin1fighter.coffeeroast

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.round

/**
 * Professional roast chart: 30s time grid, 10C temperature grid, BT mandatory,
 * ET optional. Artisan-style extras: a phase %/duration header line, and
 * DE/FC/DROP markers labeled with their temperature and time.
 */
class RoastChartView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {
    var session: RoastSession? = null
        set(value) { field = value; invalidate() }

    private val btPaint = Paint().apply { color = Color.parseColor("#D84315"); strokeWidth = 5f; style = Paint.Style.STROKE; isAntiAlias = true }
    private val etPaint = Paint().apply { color = Color.parseColor("#6D4C41"); strokeWidth = 4f; style = Paint.Style.STROKE; isAntiAlias = true }
    private val rorPaint = Paint().apply { color = Color.parseColor("#2E7D32"); strokeWidth = 3f; style = Paint.Style.STROKE; isAntiAlias = true }
    private val markerPaint = Paint().apply { color = Color.parseColor("#8D6E63"); strokeWidth = 2f; style = Paint.Style.STROKE; isAntiAlias = true }
    private val gridPaint = Paint().apply { color = Color.parseColor("#E8E2DD"); strokeWidth = 1f; isAntiAlias = true }
    private val axisPaint = Paint().apply { color = Color.parseColor("#5D4037"); strokeWidth = 2f; isAntiAlias = true }
    private val labelPaint = Paint().apply { color = Color.parseColor("#6D4C41"); textSize = 18f; isAntiAlias = true }
    private val markerLabelPaint = Paint().apply { color = Color.parseColor("#4E342E"); textSize = 16f; isAntiAlias = true }
    private val headerPaint = Paint().apply { color = Color.parseColor("#3E2417"); textSize = 18f; isAntiAlias = true }

    private fun fmtTime(sec: Int): String = "${sec / 60}:${(sec % 60).toString().padStart(2, '0')}"
    private fun r(v: Double): Int = round(v).toInt()

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.WHITE)
        val s = session ?: return
        val log = s.tempLog.sortedBy { it.elapsedSec }
        if (log.size < 2) return

        // Local, non-null-checked copies so the compiler can smart-cast safely
        // (these are var properties on a class, not locals, so they can't be
        // smart-cast directly at the point of use).
        val dryEndSec = s.dryEndSec
        val firstCrackSec = s.firstCrackSec
        val dropSec = s.dropSec

        val padLeft = 58f
        val padRight = 28f
        val padTop = 56f
        val padBottom = 42f
        val w = width - padLeft - padRight
        val h = height - padTop - padBottom
        if (w <= 0 || h <= 0) return

        val maxTime = ceil(log.last().elapsedSec / 30.0).toInt().coerceAtLeast(1) * 30
        val allTemps = log.flatMap { listOfNotNull(it.bt, it.et) }
        val minTemp = (floor((allTemps.minOrNull() ?: 0.0) / 10.0) * 10.0).coerceAtMost(0.0)
        val maxTemp = (ceil((allTemps.maxOrNull() ?: 100.0) / 10.0) * 10.0).coerceAtLeast(minTemp + 10.0)
        fun x(sec: Int) = padLeft + (sec.toFloat() / maxTime) * w
        fun y(temp: Double) = padTop + h - ((temp - minTemp) / (maxTemp - minTemp)).toFloat() * h

        // Header: phase % and duration, Artisan-style
        val phases = RoastMath.phasePercents(0, dryEndSec, firstCrackSec, dropSec)
        val headerParts = mutableListOf<String>()
        val dryingPercent = phases.dryingPercent
        if (dryingPercent != null && dryEndSec != null) {
            headerParts.add("Dry ${r(dryingPercent)}% (${fmtTime(dryEndSec)})")
        }
        val maillardPercent = phases.maillardPercent
        if (maillardPercent != null && firstCrackSec != null) {
            val maillardStart = dryEndSec ?: 0
            headerParts.add("Maillard ${r(maillardPercent)}% (${fmtTime(firstCrackSec - maillardStart)})")
        }
        val developmentPercent = phases.developmentPercent
        if (developmentPercent != null && dropSec != null && firstCrackSec != null) {
            headerParts.add("Dev ${r(developmentPercent)}% (${fmtTime(dropSec - firstCrackSec)})")
        }
        if (headerParts.isNotEmpty()) {
            canvas.drawText(headerParts.joinToString("   |   "), padLeft, 20f, headerPaint)
        }

        var t = minTemp
        while (t <= maxTemp + 0.1) {
            val yy = y(t)
            canvas.drawLine(padLeft, yy, padLeft + w, yy, gridPaint)
            canvas.drawText("${t.toInt()}\u00b0", 5f, yy + 6f, labelPaint)
            t += 10.0
        }
        var sec = 0
        while (sec <= maxTime) {
            val xx = x(sec)
            canvas.drawLine(xx, padTop, xx, padTop + h, gridPaint)
            canvas.drawText(fmtTime(sec), xx - 15f, padTop + h + 27f, labelPaint)
            sec += 30
        }
        canvas.drawLine(padLeft, padTop, padLeft, padTop + h, axisPaint)
        canvas.drawLine(padLeft, padTop + h, padLeft + w, padTop + h, axisPaint)

        for (i in 1 until log.size) {
            val a = log[i - 1]
            val b = log[i]
            canvas.drawLine(x(a.elapsedSec), y(a.bt), x(b.elapsedSec), y(b.bt), btPaint)
            val ae = a.et
            val be = b.et
            if (ae != null && be != null) canvas.drawLine(x(a.elapsedSec), y(ae), x(b.elapsedSec), y(be), etPaint)
        }

        val rors = mutableListOf<Pair<Int, Double>>()
        for (i in log.indices) {
            val ror = RoastMath.currentRor(log.subList(0, i + 1))
            if (ror != null) rors.add(log[i].elapsedSec to ror)
        }
        if (rors.size >= 2) {
            val minRor = 0.0
            val maxRor = maxOf(10.0, ceil(rors.maxOf { it.second } / 2.0) * 2.0)
            fun yr(v: Double): Float = padTop + h - ((v - minRor) / (maxRor - minRor)).toFloat() * h
            for (i in 1 until rors.size) {
                canvas.drawLine(x(rors[i - 1].first), yr(rors[i - 1].second), x(rors[i].first), yr(rors[i].second), rorPaint)
            }
        }

        fun tempNear(sec: Int): Double? = log.minByOrNull { kotlin.math.abs(it.elapsedSec - sec) }?.bt

        if (dryEndSec != null) {
            canvas.drawLine(x(dryEndSec), padTop, x(dryEndSec), padTop + h, markerPaint)
            val temp = tempNear(dryEndSec)
            val tempTxt = if (temp != null) " ${temp.toInt()}\u00b0" else ""
            canvas.drawText("DE$tempTxt ${fmtTime(dryEndSec)}", x(dryEndSec) + 4f, padTop + 16f, markerLabelPaint)
        }
        if (firstCrackSec != null) {
            canvas.drawLine(x(firstCrackSec), padTop, x(firstCrackSec), padTop + h, markerPaint)
            val temp = tempNear(firstCrackSec)
            val tempTxt = if (temp != null) " ${temp.toInt()}\u00b0" else ""
            canvas.drawText("FC$tempTxt ${fmtTime(firstCrackSec)}", x(firstCrackSec) + 4f, padTop + 34f, markerLabelPaint)
        }
        if (dropSec != null) {
            canvas.drawLine(x(dropSec), padTop, x(dropSec), padTop + h, markerPaint)
            val temp = tempNear(dropSec)
            val tempTxt = if (temp != null) " ${temp.toInt()}\u00b0" else ""
            canvas.drawText("DROP$tempTxt ${fmtTime(dropSec)}", x(dropSec) + 4f, padTop + 52f, markerLabelPaint)
        }

        btPaint.style = Paint.Style.FILL
        canvas.drawText("BT", padLeft + 8f, padTop - 8f, btPaint)
        btPaint.style = Paint.Style.STROKE
        if (log.any { it.et != null }) {
            etPaint.style = Paint.Style.FILL
            canvas.drawText("ET", padLeft + 52f, padTop - 8f, etPaint)
            etPaint.style = Paint.Style.STROKE
        }
        rorPaint.style = Paint.Style.FILL
        canvas.drawText("RoR", padLeft + 92f, padTop - 8f, rorPaint)
        rorPaint.style = Paint.Style.STROKE
    }
}
