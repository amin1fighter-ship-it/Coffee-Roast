package com.amin1fighter.coffeeroast

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View

/**
 * Minimal roast graph: BT / ET vs. time, with ROR overlaid on the same
 * vertical space, and vertical markers for dry-end / first-crack / drop.
 */
class RoastChartView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var session: RoastSession? = null
        set(value) {
            field = value
            invalidate()
        }

    private val btPaint = Paint().apply {
        color = Color.parseColor("#D84315")
        strokeWidth = 5f
        style = Paint.Style.STROKE
        isAntiAlias = true
    }
    private val etPaint = Paint().apply {
        color = Color.parseColor("#6D4C41")
        strokeWidth = 5f
        style = Paint.Style.STROKE
        isAntiAlias = true
    }
    private val rorPaint = Paint().apply {
        color = Color.parseColor("#2E7D32")
        strokeWidth = 4f
        style = Paint.Style.STROKE
        isAntiAlias = true
    }
    private val markerPaint = Paint().apply {
        color = Color.parseColor("#9E9E9E")
        strokeWidth = 2f
        style = Paint.Style.STROKE
        isAntiAlias = true
    }
    private val axisPaint = Paint().apply {
        color = Color.parseColor("#616161")
        strokeWidth = 2f
        isAntiAlias = true
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val s = session ?: return
        val log = s.tempLog
        if (log.size < 2) return

        val padLeft = 20f
        val padRight = 20f
        val padTop = 30f
        val padBottom = 20f
        val w = width.toFloat() - padLeft - padRight
        val h = height.toFloat() - padTop - padBottom
        if (w <= 0f || h <= 0f) return

        val maxTime = log.last().elapsedSec.toFloat().coerceAtLeast(1f)
        val maxTemp = (log.maxOf { kotlin.math.max(it.bt, it.et) }).toFloat().coerceAtLeast(50f)
        val minTemp = 0f

        fun x(sec: Int): Float = padLeft + (sec / maxTime) * w
        fun y(temp: Double): Float = padTop + h - ((temp.toFloat() - minTemp) / (maxTemp - minTemp)) * h

        // Axes
        canvas.drawLine(padLeft, padTop, padLeft, padTop + h, axisPaint)
        canvas.drawLine(padLeft, padTop + h, padLeft + w, padTop + h, axisPaint)

        // BT / ET curves
        for (i in 1 until log.size) {
            val p0 = log[i - 1]
            val p1 = log[i]
            canvas.drawLine(x(p0.elapsedSec), y(p0.bt), x(p1.elapsedSec), y(p1.bt), btPaint)
            canvas.drawLine(x(p0.elapsedSec), y(p0.et), x(p1.elapsedSec), y(p1.et), etPaint)
        }

        // ROR curve, rescaled into the same plot area
        val rorValues = mutableListOf<Pair<Int, Double>>()
        for (i in log.indices) {
            val ror = RoastMath.currentRor(log.subList(0, i + 1))
            if (ror != null) rorValues.add(log[i].elapsedSec to ror)
        }
        if (rorValues.size >= 2) {
            val maxRor = rorValues.maxOf { it.second }.coerceAtLeast(10.0)
            fun yRor(v: Double): Float = padTop + h - ((v / maxRor).toFloat().coerceIn(0f, 1f)) * h
            for (i in 1 until rorValues.size) {
                val (t0, v0) = rorValues[i - 1]
                val (t1, v1) = rorValues[i]
                canvas.drawLine(x(t0), yRor(v0), x(t1), yRor(v1), rorPaint)
            }
        }

        // Phase markers
        s.dryEndSec?.let { canvas.drawLine(x(it), padTop, x(it), padTop + h, markerPaint) }
        s.firstCrackSec?.let { canvas.drawLine(x(it), padTop, x(it), padTop + h, markerPaint) }
        s.dropSec?.let { canvas.drawLine(x(it), padTop, x(it), padTop + h, markerPaint) }

        // Legend
        btPaint.style = Paint.Style.FILL
        canvas.drawText("BT", padLeft + 10f, padTop - 10f, btPaint)
        btPaint.style = Paint.Style.STROKE

        etPaint.style = Paint.Style.FILL
        canvas.drawText("ET", padLeft + 60f, padTop - 10f, etPaint)
        etPaint.style = Paint.Style.STROKE

        rorPaint.style = Paint.Style.FILL
        canvas.drawText("ROR", padLeft + 110f, padTop - 10f, rorPaint)
        rorPaint.style = Paint.Style.STROKE
    }
}
