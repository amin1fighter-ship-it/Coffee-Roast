package com.amin1fighter.coffeeroast

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import java.util.Locale
import kotlin.math.roundToInt

class MainActivity : Activity() {

    private lateinit var root: FrameLayout
    private val handler = Handler(Looper.getMainLooper())
    private var tickRunnable: Runnable? = null

    private var currentSession: RoastSession? = null
    private var lastLogElapsedSec: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Storage.init(applicationContext)
        root = FrameLayout(this)
        setContentView(root)
        showHomeScreen()
    }

    override fun onDestroy() {
        super.onDestroy()
        stopTicker()
    }

    // ---------- small UI helpers ----------

    private fun screen(): LinearLayout {
        val sv = ScrollView(this)
        sv.setBackgroundColor(Color.parseColor("#FAFAFA"))
        val ll = LinearLayout(this)
        ll.orientation = LinearLayout.VERTICAL
        val pad = dp(20)
        ll.setPadding(pad, pad, pad, pad)
        sv.addView(ll, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.removeAllViews()
        root.addView(sv, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        return ll
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).roundToInt()

    private fun title(text: String): TextView {
        val tv = TextView(this)
        tv.text = text
        tv.textSize = 22f
        tv.setTypeface(null, Typeface.BOLD)
        tv.setTextColor(Color.parseColor("#3E2417"))
        tv.setPadding(0, 0, 0, dp(16))
        return tv
    }

    private fun subtitle(text: String): TextView {
        val tv = TextView(this)
        tv.text = text
        tv.textSize = 16f
        tv.setTextColor(Color.parseColor("#5D4037"))
        tv.setPadding(0, dp(8), 0, dp(4))
        return tv
    }

    private fun bigButton(text: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.setAllCaps(false)
        b.setBackgroundColor(Color.parseColor("#795548"))
        b.setTextColor(Color.WHITE)
        b.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56))
        lp.topMargin = dp(10)
        b.layoutParams = lp
        return b
    }

    private fun labeledInput(
        hint: String,
        inputType: Int = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
    ): EditText {
        val et = EditText(this)
        et.hint = hint
        et.inputType = inputType
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(8)
        et.layoutParams = lp
        return et
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    // ---------- HOME ----------

    private fun showHomeScreen() {
        stopTicker()
        val ll = screen()
        ll.addView(title("☕ Coffee Roast"))
        ll.addView(subtitle("یکی از بخش‌ها رو انتخاب کن"))
        ll.addView(bigButton("🔥 بخش روست") { showRoastHomeScreen() })
        ll.addView(bigButton("🌱 دونه سبز") { showGreenBeanScreen() })
    }

    // ---------- GREEN BEAN ----------

    private fun showGreenBeanScreen() {
        stopTicker()
        val ll = screen()
        ll.addView(title("🌱 دونه‌های سبز"))

        if (Storage.beans.isEmpty()) {
            ll.addView(subtitle("هنوز دونه‌ای ثبت نشده."))
        }
        for (bean in Storage.beans) {
            val card = LinearLayout(this)
            card.orientation = LinearLayout.VERTICAL
            card.setBackgroundColor(Color.parseColor("#F1E4D8"))
            val p = dp(12)
            card.setPadding(p, p, p, p)
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.topMargin = dp(10)
            card.layoutParams = lp

            val name = TextView(this)
            name.text = bean.name
            name.textSize = 18f
            name.setTypeface(null, Typeface.BOLD)
            card.addView(name)

            val info = TextView(this)
            val originTxt = if (bean.origin.isNotBlank()) bean.origin else "—"
            val processTxt = if (bean.process.isNotBlank()) bean.process else "—"
            info.text = "منشا: $originTxt   |   فرآوری: $processTxt"
            info.setTextColor(Color.parseColor("#6D4C41"))
            card.addView(info)

            val stock = TextView(this)
            stock.text = "موجودی: ${fmt(bean.stockGrams)} گرم   |   تعداد بچ: ${bean.totalBatches}"
            stock.setTextColor(Color.parseColor("#6D4C41"))
            card.addView(stock)

            ll.addView(card)
        }

        ll.addView(bigButton("+ افزودن دونه جدید") { showAddBeanDialog() })
        ll.addView(bigButton("بازگشت") { showHomeScreen() })
    }

    private fun showAddBeanDialog() {
        val container = LinearLayout(this)
        container.orientation = LinearLayout.VERTICAL
        val p = dp(20)
        container.setPadding(p, p, p, p)

        val nameEt = EditText(this)
        nameEt.hint = "نام دونه"
        nameEt.inputType = InputType.TYPE_CLASS_TEXT
        container.addView(nameEt)

        val originEt = EditText(this)
        originEt.hint = "منشا (مثلا اتیوپی)"
        originEt.inputType = InputType.TYPE_CLASS_TEXT
        container.addView(originEt)

        val processEt = EditText(this)
        processEt.hint = "فرآوری (واشد، ناچرال، هانی و ...)"
        processEt.inputType = InputType.TYPE_CLASS_TEXT
        container.addView(processEt)

        val stockEt = EditText(this)
        stockEt.hint = "موجودی اولیه (گرم)"
        stockEt.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        container.addView(stockEt)

        AlertDialog.Builder(this)
            .setTitle("افزودن دونه سبز")
            .setView(container)
            .setPositiveButton("ذخیره") { _, _ ->
                val name = nameEt.text.toString().trim()
                if (name.isEmpty()) {
                    toast("نام دونه رو وارد کن")
                    return@setPositiveButton
                }
                val bean = GreenBean(
                    id = Storage.newBeanId(),
                    name = name,
                    origin = originEt.text.toString().trim(),
                    process = processEt.text.toString().trim(),
                    stockGrams = stockEt.text.toString().toDoubleOrNull() ?: 0.0
                )
                Storage.addBean(bean)
                showGreenBeanScreen()
            }
            .setNegativeButton("انصراف", null)
            .show()
    }

    // ---------- ROAST HOME ----------

    private fun showRoastHomeScreen() {
        stopTicker()
        val ll = screen()
        ll.addView(title("🔥 روست‌ها"))

        val sorted = Storage.roasts.sortedByDescending { it.globalRoastNumber }
        if (sorted.isEmpty()) {
            ll.addView(subtitle("هنوز روستی ثبت نشده."))
        }
        for (r in sorted) {
            val bean = Storage.beanById(r.beanId)
            val card = LinearLayout(this)
            card.orientation = LinearLayout.VERTICAL
            card.setBackgroundColor(Color.parseColor("#F1E4D8"))
            val p = dp(12)
            card.setPadding(p, p, p, p)
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.topMargin = dp(10)
            card.layoutParams = lp

            val head = TextView(this)
            head.setTypeface(null, Typeface.BOLD)
            head.text = "روست #${r.globalRoastNumber}  —  ${bean?.name ?: "?"} (بچ ${r.beanBatchNumber})"
            card.addView(head)

            val status = TextView(this)
            status.setTextColor(Color.parseColor("#6D4C41"))
            status.text = if (r.isComplete) {
                val loss = if (r.roastedWeightG != null) RoastMath.weightLossPercent(r.greenWeightG, r.roastedWeightG!!) else null
                "پایان یافته  |  افت وزن: ${lossFmt(loss)}"
            } else {
                "در حال انجام…"
            }
            card.addView(status)

            card.setOnClickListener {
                currentSession = r
                if (r.isComplete) showRoastSummaryScreen(r) else showLiveRoastScreen(r)
            }

            ll.addView(card)
        }

        ll.addView(bigButton("+ شروع روست جدید") {
            if (Storage.beans.isEmpty()) {
                toast("اول یک دونه سبز اضافه کن")
                showGreenBeanScreen()
            } else {
                showNewRoastSetupScreen()
            }
        })
        ll.addView(bigButton("بازگشت") { showHomeScreen() })
    }

    // ---------- NEW ROAST SETUP ----------

    private fun showNewRoastSetupScreen() {
        stopTicker()
        val ll = screen()
        ll.addView(title("شروع روست جدید"))

        ll.addView(subtitle("دونه"))
        val spinner = Spinner(this)
        val beanNames = Storage.beans.map { "${it.name} (موجودی ${fmt(it.stockGrams)} گرم)" }
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, beanNames)
        spinner.adapter = adapter
        ll.addView(spinner)

        ll.addView(subtitle("وزن دونه سبز (گرم)"))
        val greenWeightEt = labeledInput("وزن دونه سبز")
        ll.addView(greenWeightEt)

        ll.addView(subtitle("فن شروع"))
        val startFanEt = labeledInput("فن شروع", InputType.TYPE_CLASS_NUMBER)
        ll.addView(startFanEt)

        ll.addView(subtitle("هیتر شروع"))
        val startHeaterEt = labeledInput("هیتر شروع", InputType.TYPE_CLASS_NUMBER)
        ll.addView(startHeaterEt)

        ll.addView(bigButton("شروع روست") {
            val beanIdx = spinner.selectedItemPosition
            if (beanIdx < 0 || beanIdx >= Storage.beans.size) {
                toast("یک دونه انتخاب کن")
                return@bigButton
            }
            val bean = Storage.beans[beanIdx]
            val greenWeight = greenWeightEt.text.toString().toDoubleOrNull()
            val startFan = startFanEt.text.toString().toIntOrNull()
            val startHeater = startHeaterEt.text.toString().toIntOrNull()
            if (greenWeight == null || greenWeight <= 0.0) {
                toast("وزن دونه سبز رو درست وارد کن")
                return@bigButton
            }
            if (startFan == null || startHeater == null) {
                toast("مقدار فن و هیتر شروع رو وارد کن")
                return@bigButton
            }

            val batchNumber = bean.totalBatches + 1
            bean.totalBatches = batchNumber
            bean.stockGrams -= greenWeight

            val session = RoastSession(
                id = Storage.newRoastId(),
                globalRoastNumber = Storage.newGlobalRoastNumber(),
                beanId = bean.id,
                beanBatchNumber = batchNumber,
                greenWeightG = greenWeight,
                startFan = startFan,
                startHeater = startHeater
            )
            session.startTimeMillis = System.currentTimeMillis()
            session.fanChanges.add(SettingChange(0, 0.0, startFan))
            session.heaterChanges.add(SettingChange(0, 0.0, startHeater))

            currentSession = session
            lastLogElapsedSec = 0
            Storage.save()
            showLiveRoastScreen(session)
        })
        ll.addView(bigButton("انصراف") { showRoastHomeScreen() })
    }

    // ---------- LIVE ROAST ----------

    private lateinit var elapsedTv: TextView
    private lateinit var nextLogTv: TextView
    private lateinit var rorTv: TextView
    private lateinit var lastPointsTv: TextView

    private fun showLiveRoastScreen(session: RoastSession) {
        stopTicker()
        val ll = screen()
        val bean = Storage.beanById(session.beanId)
        ll.addView(title("روست #${session.globalRoastNumber} — ${bean?.name ?: "?"} (بچ ${session.beanBatchNumber})"))

        elapsedTv = TextView(this)
        elapsedTv.textSize = 40f
        elapsedTv.setTypeface(null, Typeface.BOLD)
        elapsedTv.gravity = Gravity.CENTER
        elapsedTv.setTextColor(Color.parseColor("#3E2417"))
        ll.addView(elapsedTv)

        nextLogTv = TextView(this)
        nextLogTv.gravity = Gravity.CENTER
        nextLogTv.setTextColor(Color.parseColor("#6D4C41"))
        ll.addView(nextLogTv)

        rorTv = TextView(this)
        rorTv.textSize = 18f
        rorTv.gravity = Gravity.CENTER
        rorTv.setPadding(0, dp(10), 0, dp(10))
        ll.addView(rorTv)

        ll.addView(subtitle("ثبت دما (BT / ET)"))
        val btEt = labeledInput("BT")
        val etEt = labeledInput("ET")
        ll.addView(btEt)
        ll.addView(etEt)
        ll.addView(bigButton("ثبت نقطه دما") {
            val bt = btEt.text.toString().toDoubleOrNull()
            val et = etEt.text.toString().toDoubleOrNull()
            if (bt == null || et == null) {
                toast("BT و ET رو وارد کن")
                return@bigButton
            }
            val elapsed = currentElapsedSec(session)
            session.tempLog.add(TempPoint(elapsed, bt, et))
            lastLogElapsedSec = elapsed
            Storage.save()
            btEt.text.clear()
            etEt.text.clear()
            refreshLiveInfo(session)
            toast("ثبت شد")
        })

        ll.addView(subtitle("تغییر فن (مقدار جدید فن، ثبت می‌شه با دمای فعلی)"))
        val fanEt = labeledInput("فن جدید", InputType.TYPE_CLASS_NUMBER)
        ll.addView(fanEt)
        ll.addView(bigButton("ثبت تغییر فن") {
            val fan = fanEt.text.toString().toIntOrNull()
            if (fan == null) {
                toast("مقدار فن رو وارد کن")
                return@bigButton
            }
            val elapsed = currentElapsedSec(session)
            val bt = session.tempLog.lastOrNull()?.bt ?: 0.0
            session.fanChanges.add(SettingChange(elapsed, bt, fan))
            Storage.save()
            fanEt.text.clear()
            toast("تغییر فن ثبت شد")
        })

        ll.addView(subtitle("تغییر هیتر (مقدار جدید هیتر، ثبت می‌شه با دمای فعلی)"))
        val heaterEt = labeledInput("هیتر جدید", InputType.TYPE_CLASS_NUMBER)
        ll.addView(heaterEt)
        ll.addView(bigButton("ثبت تغییر هیتر") {
            val heater = heaterEt.text.toString().toIntOrNull()
            if (heater == null) {
                toast("مقدار هیتر رو وارد کن")
                return@bigButton
            }
            val elapsed = currentElapsedSec(session)
            val bt = session.tempLog.lastOrNull()?.bt ?: 0.0
            session.heaterChanges.add(SettingChange(elapsed, bt, heater))
            Storage.save()
            heaterEt.text.clear()
            toast("تغییر هیتر ثبت شد")
        })

        ll.addView(subtitle("نشانه‌های روست"))
        val markerRow = LinearLayout(this)
        markerRow.orientation = LinearLayout.HORIZONTAL
        val dryEndBtn = Button(this)
        dryEndBtn.text = "پایان خشک شدن"
        dryEndBtn.setAllCaps(false)
        dryEndBtn.setOnClickListener {
            session.dryEndSec = currentElapsedSec(session)
            Storage.save()
            toast("پایان خشک شدن ثبت شد")
        }
        val fcBtn = Button(this)
        fcBtn.text = "کرک اول"
        fcBtn.setAllCaps(false)
        fcBtn.setOnClickListener {
            session.firstCrackSec = currentElapsedSec(session)
            Storage.save()
            toast("کرک اول ثبت شد")
        }
        markerRow.addView(dryEndBtn, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        markerRow.addView(fcBtn, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        ll.addView(markerRow)

        lastPointsTv = TextView(this)
        lastPointsTv.setTextColor(Color.parseColor("#6D4C41"))
        lastPointsTv.setPadding(0, dp(12), 0, 0)
        ll.addView(lastPointsTv)

        ll.addView(bigButton("🔴 پایان روست") {
            session.dropSec = currentElapsedSec(session)
            stopTicker()
            showEndRoastWeightScreen(session)
        })

        val cancelBtn = Button(this)
        cancelBtn.text = "لغو این روست"
        cancelBtn.setAllCaps(false)
        cancelBtn.setBackgroundColor(Color.parseColor("#BDBDBD"))
        cancelBtn.setOnClickListener {
            val b = Storage.beanById(session.beanId)
            if (b != null) {
                b.totalBatches = (b.totalBatches - 1).coerceAtLeast(0)
                b.stockGrams += session.greenWeightG
                Storage.save()
            }
            stopTicker()
            showRoastHomeScreen()
        }
        val cancelLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48))
        cancelLp.topMargin = dp(10)
        cancelBtn.layoutParams = cancelLp
        ll.addView(cancelBtn)

        refreshLiveInfo(session)
        startTicker(session)
    }

    private fun currentElapsedSec(session: RoastSession): Int {
        return ((System.currentTimeMillis() - session.startTimeMillis) / 1000L).toInt().coerceAtLeast(0)
    }

    private fun refreshLiveInfo(session: RoastSession) {
        val elapsed = currentElapsedSec(session)
        val mm = elapsed / 60
        val ss = elapsed % 60
        elapsedTv.text = String.format(Locale.US, "%02d:%02d", mm, ss)

        val sinceLog = elapsed - lastLogElapsedSec
        val remaining = 30 - (sinceLog % 30)
        if (sinceLog >= 30) {
            nextLogTv.text = "⏰ وقت ثبت دماست!"
            nextLogTv.setTextColor(Color.parseColor("#D32F2F"))
        } else {
            nextLogTv.text = "ثبت بعدی تا $remaining ثانیه دیگر"
            nextLogTv.setTextColor(Color.parseColor("#6D4C41"))
        }

        val ror = RoastMath.currentRor(session.tempLog)
        if (ror != null) {
            val warn = ror < 10.0
            rorTv.text = if (warn) {
                "ROR: ${ror.roundToInt()} °/min  ⚠️ انرژی کم، احتمال بیک شدن"
            } else {
                "ROR: ${ror.roundToInt()} °/min"
            }
            rorTv.setTextColor(if (warn) Color.parseColor("#D32F2F") else Color.parseColor("#2E7D32"))
        } else {
            rorTv.text = "ROR: —"
            rorTv.setTextColor(Color.parseColor("#6D4C41"))
        }

        val last = session.tempLog.lastOrNull()
        lastPointsTv.text = if (last != null) {
            "آخرین ثبت: ${fmt(last.bt)}°BT / ${fmt(last.et)}°ET در ${last.elapsedSec}s"
        } else {
            "هنوز دمایی ثبت نشده"
        }
    }

    private fun startTicker(session: RoastSession) {
        stopTicker()
        val r = object : Runnable {
            override fun run() {
                refreshLiveInfo(session)
                handler.postDelayed(this, 1000L)
            }
        }
        tickRunnable = r
        handler.post(r)
    }

    private fun stopTicker() {
        tickRunnable?.let { handler.removeCallbacks(it) }
        tickRunnable = null
    }

    // ---------- END ROAST WEIGHT ----------

    private fun showEndRoastWeightScreen(session: RoastSession) {
        val ll = screen()
        ll.addView(title("پایان روست"))
        ll.addView(subtitle("وزن دونه بعد از روست رو وارد کن"))
        val weightEt = labeledInput("وزن بعد از روست (گرم)")
        ll.addView(weightEt)
        ll.addView(bigButton("ثبت و مشاهده نتیجه") {
            val w = weightEt.text.toString().toDoubleOrNull()
            if (w == null || w <= 0.0) {
                toast("وزن رو درست وارد کن")
                return@bigButton
            }
            session.roastedWeightG = w
            session.isComplete = true
            if (Storage.roasts.none { it.id == session.id }) {
                Storage.addRoast(session)
            } else {
                Storage.save()
            }
            showRoastSummaryScreen(session)
        })
    }

    // ---------- SUMMARY ----------

    private fun showRoastSummaryScreen(session: RoastSession) {
        stopTicker()
        val ll = screen()
        val bean = Storage.beanById(session.beanId)
        ll.addView(title("نتیجه روست #${session.globalRoastNumber} — ${bean?.name ?: "?"} (بچ ${session.beanBatchNumber})"))

        val chart = RoastChartView(this)
        chart.session = session
        val chartLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(260))
        chartLp.topMargin = dp(10)
        chart.layoutParams = chartLp
        ll.addView(chart)

        val loss = if (session.roastedWeightG != null) {
            RoastMath.weightLossPercent(session.greenWeightG, session.roastedWeightG!!)
        } else null
        ll.addView(subtitle("وزن سبز: ${fmt(session.greenWeightG)} گرم   |   وزن روست: ${session.roastedWeightG?.let { fmt(it) } ?: "—"} گرم"))
        ll.addView(subtitle("افت وزن: ${lossFmt(loss)}"))

        val phases = RoastMath.phasePercents(0, session.dryEndSec, session.firstCrackSec, session.dropSec)
        ll.addView(subtitle("فاز خشک شدن: ${pctFmt(phases.dryingPercent)}"))
        ll.addView(subtitle("فاز مایلارد: ${pctFmt(phases.maillardPercent)}"))
        ll.addView(subtitle("فاز دولوپمنت: ${pctFmt(phases.developmentPercent)}"))

        val totalSec = session.dropSec ?: (session.tempLog.lastOrNull()?.elapsedSec ?: 0)
        ll.addView(subtitle("مدت کل روست: " + String.format(Locale.US, "%d:%02d", totalSec / 60, totalSec % 60)))

        ll.addView(bigButton("بازگشت به لیست روست‌ها") { showRoastHomeScreen() })
        ll.addView(bigButton("بازگشت به خانه") { showHomeScreen() })
    }

    // ---------- formatting ----------

    private fun fmt(v: Double): String {
        return if (v == v.toLong().toDouble()) {
            v.toLong().toString()
        } else {
            String.format(Locale.US, "%.1f", v)
        }
    }

    private fun lossFmt(v: Double?): String {
        return if (v == null) "—" else String.format(Locale.US, "%.1f%%", v)
    }

    private fun pctFmt(v: Double?): String {
        return if (v == null) "—" else String.format(Locale.US, "%.0f%%", v)
    }
}
