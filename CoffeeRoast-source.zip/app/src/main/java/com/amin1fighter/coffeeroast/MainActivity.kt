package com.amin1fighter.coffeeroast

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.util.Locale
import java.text.SimpleDateFormat
import java.util.Date
import kotlin.math.roundToInt

class MainActivity : Activity() {

    private lateinit var root: FrameLayout
    private val handler = Handler(Looper.getMainLooper())
    private var tickRunnable: Runnable? = null

    private var currentSession: RoastSession? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Storage.init(applicationContext)
        root = FrameLayout(this)
        setContentView(root)
        showHomeScreen()
    }

    override fun onDestroy() {
        super.onDestroy()
        stopTicker()
    }

    // ---------- small UI helpers ----------

    private fun screen(): LinearLayout {
        val sv = ScrollView(this)
        sv.setBackgroundColor(Color.parseColor("#FAFAFA"))
        val ll = LinearLayout(this)
        ll.orientation = LinearLayout.VERTICAL
        val pad = dp(20)
        ll.setPadding(pad, pad, pad, pad)
        sv.addView(ll, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.removeAllViews()
        root.addView(sv, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        return ll
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).roundToInt()

    private fun title(text: String): TextView {
        val tv = TextView(this)
        tv.text = text
        tv.textSize = 22f
        tv.setTypeface(null, Typeface.BOLD)
        tv.setTextColor(Color.parseColor("#3E2417"))
        tv.setPadding(0, 0, 0, dp(16))
        return tv
    }

    private fun subtitle(text: String): TextView {
        val tv = TextView(this)
        tv.text = text
        tv.textSize = 16f
        tv.setTextColor(Color.parseColor("#5D4037"))
        tv.setPadding(0, dp(8), 0, dp(4))
        return tv
    }

    private fun bigButton(text: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.setAllCaps(false)
        b.setBackgroundColor(Color.parseColor("#795548"))
        b.setTextColor(Color.WHITE)
        b.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56))
        lp.topMargin = dp(10)
        b.layoutParams = lp
        return b
    }

    private fun labeledInput(
        hint: String,
        inputType: Int = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
    ): EditText {
        val et = EditText(this)
        et.hint = hint
        et.inputType = inputType
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(8)
        et.layoutParams = lp
        return et
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    private fun parseMmSs(s: String): Int? {
        val t = s.trim()
        if (t.isEmpty()) return null
        if (t.contains(":")) {
            val parts = t.split(":")
            if (parts.size != 2) return null
            val m = parts[0].toIntOrNull() ?: return null
            val sec = parts[1].toIntOrNull() ?: return null
            return m * 60 + sec
        }
        return t.toIntOrNull()
    }

    // ---------- HOME ----------

    private fun showHomeScreen() {
        stopTicker()
        val ll = screen()
        ll.addView(title("\u2615 COFFEE ROAST LAB"))
        ll.addView(subtitle("Roast logging • analysis • Artisan export"))
        ll.addView(bigButton("Roast") { showRoastHomeScreen() })
        ll.addView(bigButton("Green Beans") { showGreenBeanScreen() })
        ll.addView(bigButton("Import legacy roast") { showLegacyImportScreen() })
    }

    // ---------- GREEN BEAN ----------

    private fun showGreenBeanScreen() {
        stopTicker()
        val ll = screen()
        ll.addView(title("Green Beans"))

        if (Storage.beans.isEmpty()) {
            ll.addView(subtitle("No beans added yet."))
        }
        for (bean in Storage.beans) {
            val card = LinearLayout(this)
            card.orientation = LinearLayout.VERTICAL
            card.setBackgroundColor(Color.parseColor("#F1E4D8"))
            val p = dp(12)
            card.setPadding(p, p, p, p)
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.topMargin = dp(10)
            card.layoutParams = lp

            val name = TextView(this)
            name.text = bean.name
            name.textSize = 18f
            name.setTypeface(null, Typeface.BOLD)
            card.addView(name)

            val info = TextView(this)
            val originTxt = if (bean.origin.isNotBlank()) bean.origin else "-"
            val processTxt = if (bean.process.isNotBlank()) bean.process else "-"
            info.text = "Origin: $originTxt   |   Process: $processTxt"
            info.setTextColor(Color.parseColor("#6D4C41"))
            card.addView(info)

            val stock = TextView(this)
            stock.text = "Stock: ${fmt(bean.stockGrams)} g   |   Batches roasted: ${bean.totalBatches}"
            stock.setTextColor(Color.parseColor("#6D4C41"))
            card.addView(stock)

            ll.addView(card)
        }

        ll.addView(bigButton("+ Add new bean") { showAddBeanDialog() })
        ll.addView(bigButton("Back") { showHomeScreen() })
    }

    private fun showAddBeanDialog() {
        val container = LinearLayout(this)
        container.orientation = LinearLayout.VERTICAL
        val p = dp(20)
        container.setPadding(p, p, p, p)

        val nameEt = EditText(this)
        nameEt.hint = "Bean name"
        nameEt.inputType = InputType.TYPE_CLASS_TEXT
        container.addView(nameEt)

        val originEt = EditText(this)
        originEt.hint = "Origin (e.g. Ethiopia)"
        originEt.inputType = InputType.TYPE_CLASS_TEXT
        container.addView(originEt)

        val processEt = EditText(this)
        processEt.hint = "Process (washed, natural, honey...)"
        processEt.inputType = InputType.TYPE_CLASS_TEXT
        container.addView(processEt)

        val stockEt = EditText(this)
        stockEt.hint = "Initial stock (g)"
        stockEt.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        container.addView(stockEt)

        AlertDialog.Builder(this)
            .setTitle("Add green bean")
            .setView(container)
            .setPositiveButton("Save") { _, _ ->
                val name = nameEt.text.toString().trim()
                if (name.isEmpty()) {
                    toast("Enter a bean name")
                    return@setPositiveButton
                }
                val bean = GreenBean(
                    id = Storage.newBeanId(),
                    name = name,
                    origin = originEt.text.toString().trim(),
                    process = processEt.text.toString().trim(),
                    stockGrams = stockEt.text.toString().toDoubleOrNull() ?: 0.0
                )
                Storage.addBean(bean)
                showGreenBeanScreen()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---------- ROAST HOME ----------

    private fun showRoastHomeScreen() {
        stopTicker()
        val ll = screen()
        ll.addView(title("Roasts"))

        val sorted = Storage.roasts.sortedByDescending { it.globalRoastNumber }
        if (sorted.isEmpty()) {
            ll.addView(subtitle("No roasts logged yet."))
        }
        for (r in sorted) {
            val bean = Storage.beanById(r.beanId)
            val card = LinearLayout(this)
            card.orientation = LinearLayout.VERTICAL
            card.setBackgroundColor(Color.parseColor("#F1E4D8"))
            val p = dp(12)
            card.setPadding(p, p, p, p)
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.topMargin = dp(10)
            card.layoutParams = lp

            val head = TextView(this)
            head.setTypeface(null, Typeface.BOLD)
            head.text = "Roast #${r.globalRoastNumber}  -  ${bean?.name ?: "?"} (batch ${r.beanBatchNumber})"
            card.addView(head)

            val status = TextView(this)
            status.setTextColor(Color.parseColor("#6D4C41"))
            status.text = if (r.isComplete) {
                val loss = if (r.roastedWeightG != null) RoastMath.weightLossPercent(r.greenWeightG, r.roastedWeightG!!) else null
                "Complete  |  Weight loss: ${lossFmt(loss)}"
            } else {
                "In progress..."
            }
            card.addView(status)

            card.setOnClickListener {
                currentSession = r
                if (r.isComplete) showRoastSummaryScreen(r) else showLiveRoastScreen(r)
            }

            ll.addView(card)
        }

        ll.addView(bigButton("+ Start new roast") {
            if (Storage.beans.isEmpty()) {
                toast("Add a green bean first")
                showGreenBeanScreen()
            } else {
                showNewRoastSetupScreen()
            }
        })
        ll.addView(bigButton("Back") { showHomeScreen() })
    }

    // ---------- NEW ROAST SETUP ----------

    private fun showNewRoastSetupScreen() {
        stopTicker()
        val ll = screen()
        ll.addView(title("Start new roast"))

        ll.addView(subtitle("Bean"))
        val spinner = Spinner(this)
        val beanNames = Storage.beans.map { "${it.name} (stock ${fmt(it.stockGrams)} g)" }
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, beanNames)
        spinner.adapter = adapter
        ll.addView(spinner)

        ll.addView(subtitle("Green weight (g)"))
        val greenWeightEt = labeledInput("Green weight")
        ll.addView(greenWeightEt)

        ll.addView(subtitle("Green bean density, g/L (optional - used for the drop-temp suggestion)"))
        val densityEt = labeledInput("Density e.g. 713")
        ll.addView(densityEt)

        ll.addView(subtitle("Start fan"))
        val startFanEt = labeledInput("Start fan", InputType.TYPE_CLASS_NUMBER)
        ll.addView(startFanEt)

        ll.addView(subtitle("Start heater"))
        val startHeaterEt = labeledInput("Start heater", InputType.TYPE_CLASS_NUMBER)
        ll.addView(startHeaterEt)

        ll.addView(subtitle("Charge temperature - ambient/room BT at drop-in (optional, but this is what makes the graph start from the real charge point instead of jumping straight to your first 30s reading)"))
        val chargeBtEt = labeledInput("Charge BT")
        ll.addView(chargeBtEt)
        val chargeEtEt = labeledInput("Charge ET (optional)")
        ll.addView(chargeEtEt)

        ll.addView(bigButton("Start roast") {
            val beanIdx = spinner.selectedItemPosition
            if (beanIdx < 0 || beanIdx >= Storage.beans.size) {
                toast("Select a bean")
                return@bigButton
            }
            val bean = Storage.beans[beanIdx]
            val greenWeight = greenWeightEt.text.toString().toDoubleOrNull()
            val startFan = startFanEt.text.toString().toIntOrNull()
            val startHeater = startHeaterEt.text.toString().toIntOrNull()
            if (greenWeight == null || greenWeight <= 0.0) {
                toast("Enter a valid green weight")
                return@bigButton
            }
            if (startFan == null || startHeater == null) {
                toast("Enter start fan and heater values")
                return@bigButton
            }

            val batchNumber = bean.totalBatches + 1
            bean.totalBatches = batchNumber
            bean.stockGrams -= greenWeight

            val session = RoastSession(
                id = Storage.newRoastId(),
                globalRoastNumber = Storage.newGlobalRoastNumber(),
                beanId = bean.id,
                beanBatchNumber = batchNumber,
                greenWeightG = greenWeight,
                densityGPerL = densityEt.text.toString().toDoubleOrNull(),
                startFan = startFan,
                startHeater = startHeater
            )
            session.startTimeMillis = System.currentTimeMillis()
            session.fanChanges.add(SettingChange(0, 0.0, startFan))
            session.heaterChanges.add(SettingChange(0, 0.0, startHeater))
            val chargeBt = chargeBtEt.text.toString().toDoubleOrNull()
            if (chargeBt != null) {
                val chargeEt = chargeEtEt.text.toString().toDoubleOrNull()
                session.tempLog.add(TempPoint(0, chargeBt, chargeEt))
            }

            currentSession = session
            Storage.save()
            showLiveRoastScreen(session)
        })
        ll.addView(bigButton("Cancel") { showRoastHomeScreen() })
    }

    // ---------- LIVE ROAST ----------

    private lateinit var elapsedTv: TextView
    private lateinit var nextSlotTv: TextView
    private lateinit var rorTv: TextView
    private lateinit var predictionTv: TextView
    private lateinit var dropSuggestionTv: TextView
    private lateinit var slotsContainer: LinearLayout
    private val slotRows = LinkedHashMap<Int, Pair<EditText, EditText>>()

    private fun showLiveRoastScreen(session: RoastSession) {
        stopTicker()
        slotRows.clear()
        val ll = screen()
        val bean = Storage.beanById(session.beanId)
        ll.addView(title("Roast #${session.globalRoastNumber} - ${bean?.name ?: "?"} (batch ${session.beanBatchNumber})"))

        elapsedTv = TextView(this)
        elapsedTv.textSize = 40f
        elapsedTv.setTypeface(null, Typeface.BOLD)
        elapsedTv.gravity = Gravity.CENTER
        elapsedTv.setTextColor(Color.parseColor("#3E2417"))
        ll.addView(elapsedTv)

        nextSlotTv = TextView(this)
        nextSlotTv.gravity = Gravity.CENTER
        nextSlotTv.setTextColor(Color.parseColor("#6D4C41"))
        ll.addView(nextSlotTv)

        rorTv = TextView(this)
        rorTv.textSize = 18f
        rorTv.gravity = Gravity.CENTER
        rorTv.setPadding(0, dp(10), 0, dp(4))
        ll.addView(rorTv)

        predictionTv = TextView(this)
        predictionTv.textSize = 14f
        predictionTv.gravity = Gravity.CENTER
        predictionTv.setTextColor(Color.parseColor("#6D4C41"))
        ll.addView(predictionTv)

        dropSuggestionTv = TextView(this)
        dropSuggestionTv.textSize = 14f
        dropSuggestionTv.gravity = Gravity.CENTER
        dropSuggestionTv.setTextColor(Color.parseColor("#6D4C41"))
        dropSuggestionTv.setPadding(0, dp(4), 0, dp(4))
        val density = session.densityGPerL
        dropSuggestionTv.text = if (density != null) {
            val (lo, hi) = RoastMath.suggestedDropRangeC(density, bean?.process ?: "")
            "Suggested drop range: ${lo.roundToInt()}-${hi.roundToInt()}C (rule of thumb, not a formula)"
        } else {
            "Suggested drop range: enter density next time to see one"
        }
        ll.addView(dropSuggestionTv)

        ll.addView(subtitle("BT log — one row every 30s. ET is optional; leave ET blank when you did not record it."))
        slotsContainer = LinearLayout(this)
        slotsContainer.orientation = LinearLayout.VERTICAL
        ll.addView(slotsContainer)
        ensureSlotsUpTo(session, currentElapsedSec(session))

        ll.addView(subtitle("Fan change (logs the new fan level against the current BT)"))
        val fanEt = labeledInput("New fan level", InputType.TYPE_CLASS_NUMBER)
        ll.addView(fanEt)
        ll.addView(bigButton("Log fan change") {
            val fan = fanEt.text.toString().toIntOrNull()
            if (fan == null) {
                toast("Enter a fan value")
                return@bigButton
            }
            val elapsed = currentElapsedSec(session)
            val bt = session.tempLog.lastOrNull()?.bt ?: 0.0
            session.fanChanges.add(SettingChange(elapsed, bt, fan))
            Storage.save()
            fanEt.text.clear()
            toast("Fan change logged")
        })

        ll.addView(subtitle("Heater change (logs the new heater level against the current BT)"))
        val heaterEt = labeledInput("New heater level", InputType.TYPE_CLASS_NUMBER)
        ll.addView(heaterEt)
        ll.addView(bigButton("Log heater change") {
            val heater = heaterEt.text.toString().toIntOrNull()
            if (heater == null) {
                toast("Enter a heater value")
                return@bigButton
            }
            val elapsed = currentElapsedSec(session)
            val bt = session.tempLog.lastOrNull()?.bt ?: 0.0
            session.heaterChanges.add(SettingChange(elapsed, bt, heater))
            Storage.save()
            heaterEt.text.clear()
            toast("Heater change logged")
        })

        ll.addView(subtitle("Roast markers"))
        val markerRow = LinearLayout(this)
        markerRow.orientation = LinearLayout.HORIZONTAL
        val dryEndBtn = Button(this)
        dryEndBtn.text = "Dry end"
        dryEndBtn.setAllCaps(false)
        dryEndBtn.setOnClickListener {
            session.dryEndSec = currentElapsedSec(session)
            Storage.save()
            toast("Dry end logged")
        }
        val fcBtn = Button(this)
        fcBtn.text = "First crack"
        fcBtn.setAllCaps(false)
        fcBtn.setOnClickListener {
            session.firstCrackSec = currentElapsedSec(session)
            Storage.save()
            toast("First crack logged")
        }
        markerRow.addView(dryEndBtn, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        markerRow.addView(fcBtn, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        ll.addView(markerRow)

        ll.addView(bigButton("End roast") {
            session.dropSec = currentElapsedSec(session)
            stopTicker()
            showEndRoastWeightScreen(session)
        })

        val cancelBtn = Button(this)
        cancelBtn.text = "Cancel this roast"
        cancelBtn.setAllCaps(false)
        cancelBtn.setBackgroundColor(Color.parseColor("#BDBDBD"))
        cancelBtn.setOnClickListener {
            val b = Storage.beanById(session.beanId)
            if (b != null) {
                b.totalBatches = (b.totalBatches - 1).coerceAtLeast(0)
                b.stockGrams += session.greenWeightG
                Storage.save()
            }
            stopTicker()
            showRoastHomeScreen()
        }
        val cancelLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48))
        cancelLp.topMargin = dp(10)
        cancelBtn.layoutParams = cancelLp
        ll.addView(cancelBtn)

        refreshLiveInfo(session)
        startTicker(session)
    }

    private fun ensureSlotsUpTo(session: RoastSession, uptoElapsedSec: Int) {
        var slot = 0
        while (slot <= uptoElapsedSec + 30) {
            if (!slotRows.containsKey(slot)) {
                addSlotRow(session, slot) { refreshLiveInfo(session) }
            }
            slot += 30
        }
    }

    /**
     * A single editable BT/ET row for elapsedSec = slotSec. onSaved is only
     * used by the live ticking screen (to refresh the RoR/timer readout) -
     * omit it when reusing this from a non-live screen such as Edit, or the
     * live-only TextViews it touches would crash with "not initialized".
     */
    private fun addSlotRow(session: RoastSession, slotSec: Int, onSaved: (() -> Unit)? = null) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val rowLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        rowLp.topMargin = dp(6)
        row.layoutParams = rowLp

        val label = TextView(this)
        label.text = fmtMmSs(slotSec)
        label.setTextColor(Color.parseColor("#6D4C41"))
        label.gravity = Gravity.CENTER_VERTICAL
        label.layoutParams = LinearLayout.LayoutParams(dp(48), ViewGroup.LayoutParams.WRAP_CONTENT)
        row.addView(label)

        val existing = session.tempLog.firstOrNull { it.elapsedSec == slotSec }

        val btEt = EditText(this)
        btEt.hint = "BT"
        btEt.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        if (existing != null) btEt.setText(fmt(existing.bt))
        btEt.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        row.addView(btEt)

        val etEt = EditText(this)
        etEt.hint = "ET"
        etEt.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        if (existing?.et != null) etEt.setText(fmt(existing.et!!))
        etEt.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        row.addView(etEt)

        val saveBtn = Button(this)
        saveBtn.text = "Save"
        saveBtn.textSize = 12f
        saveBtn.setAllCaps(false)
        saveBtn.setPadding(dp(8), 0, dp(8), 0)
        saveBtn.setOnClickListener {
            val bt = btEt.text.toString().toDoubleOrNull()
            val et = etEt.text.toString().toDoubleOrNull()
            if (bt == null) {
                toast("BT is required")
                return@setOnClickListener
            }
            session.tempLog.removeAll { it.elapsedSec == slotSec }
            session.tempLog.add(TempPoint(slotSec, bt, et))
            session.tempLog.sortBy { it.elapsedSec }
            Storage.save()
            onSaved?.invoke()
            toast("Saved ${fmtMmSs(slotSec)}")
        }
        saveBtn.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        row.addView(saveBtn)

        slotsContainer.addView(row)
        slotRows[slotSec] = btEt to etEt
    }

    private fun currentElapsedSec(session: RoastSession): Int {
        return ((System.currentTimeMillis() - session.startTimeMillis) / 1000L).toInt().coerceAtLeast(0)
    }

    private fun refreshLiveInfo(session: RoastSession) {
        val elapsed = currentElapsedSec(session)
        elapsedTv.text = fmtMmSs(elapsed)

        ensureSlotsUpTo(session, elapsed)

        val nextSlot = ((elapsed / 30) + 1) * 30
        nextSlotTv.text = "Next slot at ${fmtMmSs(nextSlot)} (in ${nextSlot - elapsed}s)"

        val ror = RoastMath.currentRor(session.tempLog)
        if (ror != null) {
            val warn = ror < 10.0
            rorTv.text = if (warn) {
                "RoR: ${ror.roundToInt()} C/min  - low energy, beans may bake"
            } else {
                "RoR: ${ror.roundToInt()} C/min"
            }
            rorTv.setTextColor(if (warn) Color.parseColor("#D32F2F") else Color.parseColor("#2E7D32"))
        } else {
            rorTv.text = "RoR: -"
            rorTv.setTextColor(Color.parseColor("#6D4C41"))
        }

        val last = session.tempLog.lastOrNull()
        predictionTv.text = when {
            last == null -> "Prediction: waiting for the first BT entry"
            session.dryEndSec == null -> {
                val eta = RoastMath.etaToTempSec(elapsed, last.bt, ror, RoastMath.DEFAULT_DRY_END_TARGET_C)
                if (eta != null) "Est. dry end: ~${fmtMmSs(eta)} (assumes steady RoR)" else "Est. dry end: -"
            }
            session.firstCrackSec == null -> {
                val eta = RoastMath.etaToTempSec(elapsed, last.bt, ror, RoastMath.DEFAULT_FIRST_CRACK_TARGET_C)
                if (eta != null) "Est. first crack: ~${fmtMmSs(eta)} (assumes steady RoR)" else "Est. first crack: -"
            }
            else -> "In development phase"
        }
    }

    private fun startTicker(session: RoastSession) {
        stopTicker()
        val r = object : Runnable {
            override fun run() {
                refreshLiveInfo(session)
                handler.postDelayed(this, 1000L)
            }
        }
        tickRunnable = r
        handler.post(r)
    }

    private fun stopTicker() {
        tickRunnable?.let { handler.removeCallbacks(it) }
        tickRunnable = null
    }

    // ---------- END ROAST WEIGHT ----------

    private fun showEndRoastWeightScreen(session: RoastSession) {
        val ll = screen()
        ll.addView(title("End of roast"))
        ll.addView(subtitle("Enter the weight after roasting"))
        val weightEt = labeledInput("Weight after roast (g)")
        ll.addView(weightEt)
        ll.addView(bigButton("Save and view result") {
            val w = weightEt.text.toString().toDoubleOrNull()
            if (w == null || w <= 0.0) {
                toast("Enter a valid weight")
                return@bigButton
            }
            session.roastedWeightG = w
            session.isComplete = true
            if (Storage.roasts.none { it.id == session.id }) {
                Storage.addRoast(session)
            } else {
                Storage.save()
            }
            showRoastSummaryScreen(session)
        })
    }

    // ---------- SUMMARY ----------

    private fun showRoastSummaryScreen(session: RoastSession) {
        stopTicker()
        val ll = screen()
        val bean = Storage.beanById(session.beanId)
        ll.addView(title("Roast #${session.globalRoastNumber} result - ${bean?.name ?: "?"} (batch ${session.beanBatchNumber})"))

        val chart = RoastChartView(this)
        chart.session = session
        val chartLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(280))
        chartLp.topMargin = dp(10)
        chart.layoutParams = chartLp
        ll.addView(chart)

        ll.addView(bigButton("Share / export chart") { shareChart(chart) })

        val loss = if (session.roastedWeightG != null) {
            RoastMath.weightLossPercent(session.greenWeightG, session.roastedWeightG!!)
        } else null
        ll.addView(subtitle("Green weight: ${fmt(session.greenWeightG)} g   |   Roasted weight: ${session.roastedWeightG?.let { fmt(it) } ?: "-"} g"))
        ll.addView(subtitle("Weight loss: ${lossFmt(loss)}"))

        val phases = RoastMath.phasePercents(0, session.dryEndSec, session.firstCrackSec, session.dropSec)
        ll.addView(subtitle("Drying phase: ${pctFmt(phases.dryingPercent)}"))
        ll.addView(subtitle("Maillard phase: ${pctFmt(phases.maillardPercent)}"))
        ll.addView(subtitle("Development phase: ${pctFmt(phases.developmentPercent)}"))

        val actualDropBt = session.dropSec?.let { ds -> session.tempLog.lastOrNull { it.elapsedSec <= ds }?.bt }
        if (session.densityGPerL != null) {
            val (lo, hi) = RoastMath.suggestedDropRangeC(session.densityGPerL!!, bean?.process ?: "")
            ll.addView(
                subtitle(
                    "Suggested drop range: ${lo.roundToInt()}-${hi.roundToInt()}C   |   Actual drop BT: " +
                        (actualDropBt?.let { fmt(it) } ?: "-") + "C"
                )
            )
        }

        val totalSec = session.dropSec ?: (session.tempLog.lastOrNull()?.elapsedSec ?: 0)
        ll.addView(subtitle("Total roast time: " + fmtMmSs(totalSec)))

        ll.addView(bigButton("Export to Artisan") { exportArtisanTsv(session) })
        ll.addView(bigButton("Edit this roast") { showEditRoastScreen(session) })
        ll.addView(bigButton("Back to roast list") { showRoastHomeScreen() })
        ll.addView(bigButton("Back to home") { showHomeScreen() })
    }

    private fun shareChart(chart: RoastChartView) {
        val w = chart.width
        val h = chart.height
        if (w <= 0 || h <= 0) {
            toast("Chart isn't ready yet")
            return
        }
        try {
            val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            chart.draw(canvas)

            val dir = File(cacheDir, "charts")
            if (!dir.exists()) dir.mkdirs()
            val file = File(dir, "roast_chart_${System.currentTimeMillis()}.png")
            FileOutputStream(file).use { out ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
            }
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            val intent = Intent(Intent.ACTION_SEND)
            intent.type = "image/png"
            intent.putExtra(Intent.EXTRA_STREAM, uri)
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(intent, "Share roast chart"))
        } catch (e: Exception) {
            toast("Could not export chart: ${e.message}")
        }
    }

    // ---------- EDIT / DELETE A SAVED ROAST ----------

    /**
     * Full edit form for any finalized roast - live-completed or imported
     * from Legacy Import. Every field is pre-filled from the session and
     * overwrites it in place on Save, so nothing about "already saved"
     * roasts is locked.
     */
    private fun showEditRoastScreen(session: RoastSession) {
        stopTicker()
        slotRows.clear()
        val ll = screen()
        val bean = Storage.beanById(session.beanId)
        ll.addView(title("Edit roast #${session.globalRoastNumber} - ${bean?.name ?: "?"}"))

        ll.addView(subtitle("Green weight (g)"))
        val greenWeightEt = labeledInput("Green weight")
        greenWeightEt.setText(fmt(session.greenWeightG))
        ll.addView(greenWeightEt)

        ll.addView(subtitle("Density g/L (optional)"))
        val densityEt = labeledInput("Density")
        session.densityGPerL?.let { densityEt.setText(fmt(it)) }
        ll.addView(densityEt)

        ll.addView(subtitle("Start fan"))
        val startFanEt = labeledInput("Start fan", InputType.TYPE_CLASS_NUMBER)
        startFanEt.setText(session.startFan.toString())
        ll.addView(startFanEt)

        ll.addView(subtitle("Start heater"))
        val startHeaterEt = labeledInput("Start heater", InputType.TYPE_CLASS_NUMBER)
        startHeaterEt.setText(session.startHeater.toString())
        ll.addView(startHeaterEt)

        ll.addView(subtitle("BT / ET log - every saved row is editable, tap + to add another"))
        slotsContainer = LinearLayout(this)
        slotsContainer.orientation = LinearLayout.VERTICAL
        ll.addView(slotsContainer)
        val existingSecs = session.tempLog.map { it.elapsedSec }.distinct().sorted()
        for (secVal in existingSecs) addSlotRow(session, secVal)
        var nextNewSlot = if (existingSecs.isEmpty()) 0 else ((existingSecs.max() / 30) + 1) * 30
        ll.addView(bigButton("+ Add another row") {
            addSlotRow(session, nextNewSlot)
            nextNewSlot += 30
        })

        ll.addView(subtitle("Markers, time as mm:ss (clear the text to remove a marker)"))
        val dryEndTimeEt = labeledInput("Dry end e.g. 3:14", InputType.TYPE_CLASS_TEXT)
        session.dryEndSec?.let { dryEndTimeEt.setText(fmtMmSs(it)) }
        ll.addView(dryEndTimeEt)
        val fcTimeEt = labeledInput("First crack e.g. 6:45", InputType.TYPE_CLASS_TEXT)
        session.firstCrackSec?.let { fcTimeEt.setText(fmtMmSs(it)) }
        ll.addView(fcTimeEt)
        val dropTimeEt = labeledInput("Drop / end e.g. 7:45", InputType.TYPE_CLASS_TEXT)
        session.dropSec?.let { dropTimeEt.setText(fmtMmSs(it)) }
        ll.addView(dropTimeEt)

        ll.addView(subtitle("Weight after roast (g)"))
        val roastedWeightEt = labeledInput("Roasted weight")
        session.roastedWeightG?.let { roastedWeightEt.setText(fmt(it)) }
        ll.addView(roastedWeightEt)

        ll.addView(bigButton("Save changes") {
            val gw = greenWeightEt.text.toString().toDoubleOrNull()
            if (gw == null || gw <= 0.0) {
                toast("Enter a valid green weight")
                return@bigButton
            }
            session.greenWeightG = gw
            session.densityGPerL = densityEt.text.toString().toDoubleOrNull()
            startFanEt.text.toString().toIntOrNull()?.let { session.startFan = it }
            startHeaterEt.text.toString().toIntOrNull()?.let { session.startHeater = it }
            session.dryEndSec = parseMmSs(dryEndTimeEt.text.toString())
            session.firstCrackSec = parseMmSs(fcTimeEt.text.toString())
            session.dropSec = parseMmSs(dropTimeEt.text.toString())
            session.roastedWeightG = roastedWeightEt.text.toString().toDoubleOrNull()
            Storage.save()
            toast("Changes saved")
            showRoastSummaryScreen(session)
        })
        ll.addView(bigButton("Delete this roast") { confirmDeleteRoast(session) })
        ll.addView(bigButton("Cancel") { showRoastSummaryScreen(session) })
    }

    private fun confirmDeleteRoast(session: RoastSession) {
        AlertDialog.Builder(this)
            .setTitle("Delete roast #${session.globalRoastNumber}?")
            .setMessage("This can't be undone. Green bean stock and batch numbers already used are not restored.")
            .setPositiveButton("Delete") { _, _ ->
                Storage.deleteRoast(session.id)
                toast("Roast deleted")
                showRoastHomeScreen()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---------- LEGACY IMPORT ----------

    private fun showLegacyImportScreen() {
        stopTicker()
        val ll = screen()
        ll.addView(title("Import legacy roast"))
        ll.addView(subtitle("Paste a Google Keep note. The parser accepts common English labels and temperature rows such as 0:30 150 170. Review the imported roast before relying on it."))
        val input = EditText(this)
        input.hint = "Paste roast notes here..."
        input.gravity = Gravity.TOP
        input.minLines = 14
        input.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        ll.addView(input)
        ll.addView(bigButton("Parse and import") {
            val text = input.text.toString().trim()
            if (text.isBlank()) { toast("Paste a roast note first"); return@bigButton }
            val imported = parseLegacyRoast(text)
            if (imported == null) { toast("Could not find enough data. Add at least a coffee name and green weight."); return@bigButton }
            showLegacyReview(imported)
        })
        ll.addView(bigButton("Back") { showHomeScreen() })
    }

    private data class LegacyImport(
        val beanName: String,
        val origin: String,
        val process: String,
        val greenWeight: Double,
        val roastedWeight: Double?,
        val density: Double?,
        val startFan: Int,
        val startHeater: Int,
        val dryEnd: Int?,
        val firstCrack: Int?,
        val drop: Int?,
        val points: List<TempPoint>,
        val notes: String
    )

    private fun parseLegacyRoast(text: String): LegacyImport? {
        fun value(vararg keys: String): String? {
            val key = keys.joinToString("|") { Regex.escape(it) }
            val r = Regex("(?im)^\\s*(?:$key)\\s*[:=-]\\s*(.+?)\\s*$").find(text)
            return r?.groupValues?.getOrNull(1)?.trim()
        }
        fun num(vararg keys:String)=value(*keys)?.replace(',', '.')?.replace(Regex("[^0-9.\\-]"),"")?.toDoubleOrNull()
        fun time(vararg keys:String):Int? = value(*keys)?.let { parseTime(it) }
        val name=value("Bean","Coffee","Coffee name","Name","قهوه","نام قهوه") ?: text.lineSequence().firstOrNull { it.isNotBlank() }?.trim() ?: return null
        val green=num("Green weight","Green","Input weight","Weight green","وزن سبز") ?: return null
        val roasted=num("Roasted weight","Roasted","Output weight","Weight roasted","وزن رست")
        val density=num("Density","Green density","چگالی")
        val points=mutableListOf<TempPoint>()
        val row=Regex("(?i)^\\s*(\\d{1,2}:\\d{2}|\\d+)\\s+(?:BT\\s*)?([0-9]+(?:[.,][0-9]+)?)(?:\\s+(?:ET\\s*)?([0-9]+(?:[.,][0-9]+)?))?\\s*$")
        for(line in text.lines()) { val m=row.find(line) ?: continue; val sec=parseTime(m.groupValues[1]) ?: continue; val bt=m.groupValues[2].replace(',','.').toDoubleOrNull() ?: continue; val et=m.groupValues[3].takeIf{it.isNotBlank()}?.replace(',','.')?.toDoubleOrNull(); points.add(TempPoint(sec,bt,et)) }
        points.sortBy{it.elapsedSec}
        val process=value("Process","Processing","فرآوری") ?: ""
        return LegacyImport(name, value("Origin","Region","مبدا") ?: "", process, green, roasted, density, num("Start fan","Fan","فن")?.toInt() ?: 0, num("Start heater","Heater","هیتر")?.toInt() ?: 0, time("Dry end","Dry","DE","خشک شدن"), time("First crack","FC","FC start","First crack start","ترک اول"), time("Drop","Drop time","خروج","دراپ"), points, value("Notes","Tasting notes","Cup notes","یادداشت") ?: "")
    }

    private fun parseTime(raw:String):Int? { val x=raw.trim(); if(x.contains(':')) { val p=x.split(':'); if(p.size==2) return p[0].toIntOrNull()?.times(60)?.plus(p[1].toIntOrNull() ?: return null) }; return x.toIntOrNull() }

    private fun showLegacyReview(data: LegacyImport) {
        AlertDialog.Builder(this).setTitle("Review imported roast").setMessage("${data.beanName}\nGreen: ${fmt(data.greenWeight)} g\nPoints: ${data.points.size}\nET readings: ${data.points.count{it.et!=null}}\nFC: ${data.firstCrack?.let{fmtMmSs(it)} ?: "-"}\nDrop: ${data.drop?.let{fmtMmSs(it)} ?: "-"}").setNegativeButton("Cancel", null).setPositiveButton("Import") { _, _ -> saveLegacyImport(data) }.show()
    }

    private fun saveLegacyImport(d: LegacyImport) {
        val bean=Storage.beans.firstOrNull{it.name.equals(d.beanName,true)} ?: GreenBean(Storage.newBeanId(),d.beanName,d.origin,d.process)
        if(Storage.beans.none{it.id==bean.id}) Storage.beans.add(bean)
        val session=RoastSession(Storage.newRoastId(),Storage.newGlobalRoastNumber(),bean.id,bean.totalBatches+1,d.greenWeight,d.roastedWeight,d.density,d.startFan,d.startHeater)
        session.tempLog.addAll(d.points.distinctBy{it.elapsedSec})
        session.dryEndSec=d.dryEnd; session.firstCrackSec=d.firstCrack; session.dropSec=d.drop
        session.isComplete=d.roastedWeight!=null || d.drop!=null; session.isHistorical=true
        session.startTimeMillis=System.currentTimeMillis()-((d.drop ?: d.points.lastOrNull()?.elapsedSec ?: 0)*1000L)
        Storage.roasts.add(session); Storage.save(); toast("Imported Roast #${session.globalRoastNumber}"); showRoastSummaryScreen(session)
    }

    // ---------- ARTISAN EXPORT ----------

    private fun exportArtisanTsv(session: RoastSession) {
        try {
            val bean=Storage.beanById(session.beanId)
            val file=File(cacheDir,"artisan_roast_${session.globalRoastNumber}.tsv")
            val events=mutableMapOf<Int,String>(); events[0]="CHARGE"; session.dryEndSec?.let{events[it]="DRY"}; session.firstCrackSec?.let{events[it]="FCs"}; session.dropSec?.let{events[it]="DROP"}
            file.bufferedWriter().use { out ->
                out.write("Time\tET\tBT\tEvent\n")
                for(p in session.tempLog.sortedBy{it.elapsedSec}) {
                    out.write("${fmtMmSs(p.elapsedSec)}\t${p.et?.let{fmt(it)} ?: ""}\t${fmt(p.bt)}\t${events[p.elapsedSec] ?: ""}\n")
                }
            }
            val uri=FileProvider.getUriForFile(this,"$packageName.fileprovider",file)
            val intent=Intent(Intent.ACTION_SEND).apply { type="text/tab-separated-values"; putExtra(Intent.EXTRA_STREAM,uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION); putExtra(Intent.EXTRA_TEXT,"Artisan-compatible TSV export — import via Artisan File > Import / CSV") }
            startActivity(Intent.createChooser(intent,"Send roast to Artisan"))
        } catch(e:Exception) { toast("Could not export Artisan file: ${e.message}") }
    }

    // ---------- formatting ----------

    private fun fmtMmSs(totalSec: Int): String {
        val s = totalSec.coerceAtLeast(0)
        return String.format(Locale.US, "%d:%02d", s / 60, s % 60)
    }

    private fun fmt(v: Double): String {
        return if (v == v.toLong().toDouble()) {
            v.toLong().toString()
        } else {
            String.format(Locale.US, "%.1f", v)
        }
    }

    private fun lossFmt(v: Double?): String {
        return if (v == null) "-" else String.format(Locale.US, "%.1f%%", v)
    }

    private fun pctFmt(v: Double?): String {
        return if (v == null) "-" else String.format(Locale.US, "%.0f%%", v)
    }
}
