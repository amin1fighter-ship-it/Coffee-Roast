# Coffee Roast

Android app for logging your own fluid-bed roasts: green bean inventory,
per-bean batch numbering, live BT/ET logging every ~30s, real-time RoR with
a low-energy warning, fan/heater change log, phase percentages, weight loss,
and a BT/ET/RoR chart.

## Screens

- Home -> Roast section / Green Bean section
- Green Bean: list + add (name, origin, process, stock in grams)
- Roast home: history list + "start new roast"
- New roast setup: pick bean -> auto-assigns a global roast number and a
  per-bean batch number, enter green weight + starting fan/heater
- Live roast: elapsed timer, 30s log reminder, BT/ET entry, fan/heater
  change log (tagged with the BT at the moment of change), Dry-End /
  First-Crack markers, live RoR (warns below 10 deg/min), Drop button
- Summary: roasted weight entry -> weight loss %, drying/Maillard/development
  phase %, and the BT/ET/RoR chart

## Data

Stored locally as JSON in the app's private storage
(`filesDir/coffeeroast_data.json`). No network access, no external database.

## Build

CI is at `.github/workflows/android-build.yml`. It builds a **signed release
APK** (not debug) on every push to main and on manual dispatch, and uploads
it as a downloadable Actions artifact named `CoffeeRoast-release-apk`.

versionCode auto-increments from `GITHUB_RUN_NUMBER`, so every build
installs as an update over the previous one - as long as the signing key
stays the same. Required repository secrets:

- `KEYSTORE_BASE64`
- `KEYSTORE_PASSWORD`
- `KEY_ALIAS`
- `KEY_PASSWORD`

## Not yet built

- CSV / Artisan `.alog` export
- Editing or deleting a saved bean or roast
