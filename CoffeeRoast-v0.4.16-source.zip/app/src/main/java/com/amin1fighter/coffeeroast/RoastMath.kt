package com.amin1fighter.coffeeroast

import kotlin.math.abs
import kotlin.math.roundToInt

object RoastMath {
    const val DEFAULT_DRY_END_TARGET_C = 150.0
    const val DEFAULT_FIRST_CRACK_TARGET_C = 200.0

    fun currentRor(log: List<TempPoint>, windowSec: Int = 60): Double? {
        if (log.size < 2) return null
        val a = log.sortedBy { it.elapsedSec }
        val last = a.last()
        val target = last.elapsedSec - windowSec
        val ref = a.filter { it.elapsedSec < last.elapsedSec }
            .minByOrNull { abs(it.elapsedSec - target) } ?: a[a.size - 2]
        val dt = last.elapsedSec - ref.elapsedSec
        if (dt <= 0) return null
        if (windowSec > 0 && abs(ref.elapsedSec - target) > windowSec * 0.75 &&
            a.last().elapsedSec - a.first().elapsedSec > windowSec * 2
        ) return null
        return (last.bt - ref.bt) * 60.0 / dt
    }

    fun rorSeries(log: List<TempPoint>, windowSec: Int = 60) =
        log.sortedBy { it.elapsedSec }.mapNotNull { p ->
            val r = currentRor(log.takeWhile { it.elapsedSec <= p.elapsedSec }, windowSec)
            if (r == null) null else p.elapsedSec to r
        }

    fun deltaRor(log: List<TempPoint>, windowSec: Int = 60): List<Pair<Int, Double>> {
        val rr = rorSeries(log, windowSec)
        return rr.mapIndexedNotNull { i, p ->
            if (i == 0) null
            else p.first to (p.second - rr[i - 1].second) * 60.0 / (p.first - rr[i - 1].first).coerceAtLeast(1)
        }
    }

    fun smooth(log: List<TempPoint>, window: Int) =
        if (window <= 1) log
        else log.sortedBy { it.elapsedSec }.mapIndexed { i, p ->
            val a = maxOf(0, i - window + 1)
            val xs = log.sortedBy { it.elapsedSec }.subList(a, i + 1)
            TempPoint(
                p.elapsedSec,
                xs.map { it.bt }.average(),
                xs.mapNotNull { it.et }.takeIf { it.isNotEmpty() }?.average()
            )
        }

    fun weightLossPercent(g: Double, r: Double) = if (g <= 0) null else (g - r) / g * 100

    /** Development time ratio: (drop - FC) / (drop - charge) * 100. Charge is always 0. */
    fun dtr(start: Int, fc: Int?, drop: Int?) =
        if (fc != null && drop != null && drop > start) (drop - fc).toDouble() / (drop - start) * 100 else null

    /**
     * Phase percentages relative to charge (start) → drop.
     * Dry: charge → DE, Maillard: DE → FC, Development: FC → drop.
     */
    fun phasePercents(start: Int, de: Int?, fc: Int?, drop: Int?): Triple<Double?, Double?, Double?> {
        if (drop == null || drop <= start) return Triple(null, null, null)
        val total = (drop - start).toDouble()
        val dry = de?.let { (it - start) / total * 100 }
        val mail = if (fc != null) (fc - (de ?: start)) / total * 100 else null
        val dev = dtr(start, fc, drop)
        return Triple(dry, mail, dev)
    }

    fun etaToTempSec(now: Int, bt: Double, ror: Double?, target: Double): Int? {
        if (ror == null || !ror.isFinite() || ror <= 0.01 || !bt.isFinite() || target <= bt) return null
        return now + ((target - bt) / ror * 60.0).roundToInt()
    }

    fun stableRor(log: List<TempPoint>, windowSec: Int = 60): Double? {
        val clean = log.filter { it.bt.isFinite() && it.elapsedSec >= 0 }.sortedBy { it.elapsedSec }
        if (clean.size < 2) return null
        val last = clean.last().elapsedSec
        val window = clean.filter { it.elapsedSec >= last - windowSec }.takeIf { it.size >= 2 } ?: return null
        val xs = window.map { it.elapsedSec.toDouble() }
        val ys = window.map { it.bt }
        val xm = xs.average()
        val ym = ys.average()
        val den = xs.sumOf { (it - xm) * (it - xm) }
        if (den <= 1.0) return null
        val slope = xs.indices.sumOf { (xs[it] - xm) * (ys[it] - ym) } / den
        val r = slope * 60.0
        return r.takeIf { it.isFinite() && it > -5.0 && it < 40.0 }
    }

    fun predictionRor(log: List<TempPoint>): Double? {
        val values = listOfNotNull(stableRor(log, 30), stableRor(log, 60), stableRor(log, 90))
        if (values.isEmpty()) return null
        return values.sorted()[values.size / 2]
    }

    fun suggestedDropRangeC(d: Double, p: String): Pair<Double, Double> {
        var l = when {
            d >= 720 -> 200.0
            d >= 680 -> 196.0
            else -> 190.0
        }
        var h = when {
            d >= 720 -> 206.0
            d >= 680 -> 202.0
            else -> 197.0
        }
        if (p.lowercase().contains("natural")) {
            l -= 3; h -= 3
        }
        if (p.lowercase().contains("honey")) {
            l -= 1.5; h -= 1.5
        }
        return l to h
    }

    fun parseTime(s: String): Int? {
        val t = s.trim()
        if (t.isEmpty()) return null
        if (!t.contains(":")) return t.toIntOrNull()
        val p = t.split(":")
        if (p.size != 2) return null
        val m = p[0].toIntOrNull() ?: return null
        val sec = p[1].toIntOrNull() ?: return null
        if (m < 0 || sec !in 0..59) return null
        return m * 60 + sec
    }

    /**
     * Validate marker chronology: TP ≤ DE ≤ FC ≤ SC ≤ DROP (nulls ignored).
     * Returns null if OK, otherwise an error message.
     */

    /**
     * Classify achieved roast style from DTR and drop temperature.
     * Returns one of: "Espresso", "Specialty (Filter)", "Omni", or "—".
     */
    fun classifyStyle(dtrPercent: Double?, dropBtC: Double?, totalSec: Int?): String {
        if (dtrPercent == null && dropBtC == null) return "—"
        val dtr = dtrPercent ?: 20.0
        val drop = dropBtC ?: 200.0
        // Heuristic used by many specialty roasters:
        // - Filter/Specialty: lower development, often cooler drop
        // - Espresso: higher development and/or hotter drop
        // - Omni: middle ground
        return when {
            dtr >= 23.0 || (dtr >= 21.0 && drop >= 204.0) -> "Espresso"
            dtr <= 17.5 || (dtr <= 19.0 && drop <= 198.0) -> "Specialty (Filter)"
            else -> "Omni"
        }
    }

    fun styleLabel(code: String): String = when (code.lowercase()) {
        "espresso" -> "Espresso"
        "omni" -> "Omni"
        else -> "Specialty (Filter)"
    }

    fun validateMarkers(
        tp: Int?,
        de: Int?,
        fc: Int?,
        sc: Int?,
        drop: Int?
    ): String? {
        val ordered = listOf(
            "TP" to tp,
            "DE" to de,
            "FC" to fc,
            "SC" to sc,
            "DROP" to drop
        ).filter { it.second != null }
        for (i in 1 until ordered.size) {
            val prev = ordered[i - 1]
            val cur = ordered[i]
            if (cur.second!! < prev.second!!) {
                return "${cur.first} (${fmtTime(cur.second!!)}) cannot be before ${prev.first} (${fmtTime(prev.second!!)})"
            }
        }
        return null
    }

    private fun fmtTime(s: Int) = "${s / 60}:${(s % 60).toString().padStart(2, '0')}"
}
