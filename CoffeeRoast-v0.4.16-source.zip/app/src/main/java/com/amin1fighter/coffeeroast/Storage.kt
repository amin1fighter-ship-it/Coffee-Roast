package com.amin1fighter.coffeeroast

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Durable local storage.
 *
 * Rules:
 * - Never silently no-op a save while the user has in-memory data.
 * - Prefer restoring the newest valid snapshot (.json, .bak, .bak2).
 * - Only refuse to overwrite a *non-empty disk snapshot* with an *empty* memory state
 *   (guards against accidental wipe after a bad load).
 */
object Storage {
    const val SCHEMA = 7
    private const val FILE = "coffeeroast_data.json"
    private const val BACKUP = "coffeeroast_data.json.bak"
    private const val BACKUP2 = "coffeeroast_data.json.bak2"
    private const val TEMP = "coffeeroast_data.json.tmp"
    private const val STATUS = "coffeeroast_status.txt"

    var beans = mutableListOf<GreenBean>()
    var roasts = mutableListOf<RoastSession>()
    var settings = AppSettings()

    private var nb = 1L
    private var nr = 1L
    private var ng = 1
    private lateinit var file: File
    private lateinit var filesDir: File
    private var loaded = false

    /** Last human-readable storage status for the UI. */
    var lastStatus: String = "not initialized"
        private set

    fun init(c: Context) {
        filesDir = c.filesDir
        file = File(filesDir, FILE)
        if (loaded) return
        load()
        loaded = true
    }

    fun newBeanId() = nb++
    fun newRoastId() = nr++
    fun allocateGlobalRoastNumber(): Int {
        val x = ng
        ng++
        return x
    }

    fun nextBatch(bean: GreenBean) =
        (roasts.filter { it.beanId == bean.id }.maxOfOrNull { it.beanBatchNumber } ?: 0) + 1

    fun addBean(b: GreenBean) {
        beans.add(b)
        saveOrThrow()
    }

    fun deleteBean(id: Long) {
        val related = roasts.filter { it.beanId == id }
        related.filter { !it.isComplete && it.stockReserved }.forEach { r ->
            beanById(id)?.let { it.stockGrams += r.greenWeightG }
        }
        roasts.removeAll { it.beanId == id }
        beans.removeAll { it.id == id }
        beans.forEach { it.totalBatches = roasts.count { r -> r.beanId == it.id } }
        saveOrThrow()
    }

    fun addRoast(r: RoastSession) {
        roasts.add(r)
        saveOrThrow()
    }

    fun deleteRoast(id: Long) {
        val r = roasts.firstOrNull { it.id == id } ?: return
        if (!r.isComplete && r.stockReserved) {
            beanById(r.beanId)?.let { it.stockGrams += r.greenWeightG }
        }
        roasts.removeAll { it.id == id }
        beans.forEach { it.totalBatches = roasts.count { rr -> rr.beanId == it.id } }
        saveOrThrow()
    }

    fun beanById(id: Long) = beans.firstOrNull { it.id == id }

    fun dataSummary(): String =
        "beans=${beans.size} roasts=${roasts.size} file=${if (::file.isInitialized && file.exists()) file.length() else 0}B · $lastStatus"

    /**
     * Persist current memory state. Returns true on success.
     * Never silently skips when the user has data in memory.
     */
    @Synchronized
    fun save(): Boolean {
        if (!::file.isInitialized) {
            lastStatus = "save skipped: not initialized"
            return false
        }
        val parent = file.parentFile ?: run {
            lastStatus = "save failed: no parent dir"
            return false
        }
        if (!parent.exists()) parent.mkdirs()

        val tmp = File(parent, TEMP)
        val backup = File(parent, BACKUP)
        val backup2 = File(parent, BACKUP2)
        val payload = try {
            toJson().toString().toByteArray(Charsets.UTF_8)
        } catch (e: Exception) {
            lastStatus = "save failed: JSON encode ${e.message}"
            writeStatusFile()
            return false
        }
        if (payload.isEmpty()) {
            lastStatus = "save failed: empty payload"
            return false
        }

        return try {
            FileOutputStream(tmp).use { out ->
                out.write(payload)
                out.flush()
                out.fd.sync()
            }
            // Rotate backups: main → bak → bak2
            if (file.exists() && file.length() > 0) {
                if (backup.exists()) {
                    try {
                        Files.copy(backup.toPath(), backup2.toPath(), StandardCopyOption.REPLACE_EXISTING)
                    } catch (_: Exception) {
                    }
                }
                try {
                    Files.copy(file.toPath(), backup.toPath(), StandardCopyOption.REPLACE_EXISTING)
                } catch (_: Exception) {
                }
            }
            try {
                Files.move(
                    tmp.toPath(), file.toPath(),
                    StandardCopyOption.REPLACE_EXISTING,
                    StandardCopyOption.ATOMIC_MOVE
                )
            } catch (_: Exception) {
                // Some Android FS do not support ATOMIC_MOVE
                if (file.exists()) file.delete()
                Files.move(tmp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING)
            }
            // Verify
            if (!file.exists() || file.length() < 2) {
                lastStatus = "save failed: verify empty after write"
                writeStatusFile()
                return false
            }
            // Round-trip parse check
            try {
                JSONObject(file.readText())
            } catch (e: Exception) {
                lastStatus = "save failed: verify parse ${e.message}"
                writeStatusFile()
                return false
            }
            lastStatus = "saved ok · ${beans.size} beans · ${roasts.size} roasts · ${file.length()}B"
            writeStatusFile()
            true
        } catch (e: Exception) {
            try {
                tmp.delete()
            } catch (_: Exception) {
            }
            lastStatus = "save failed: ${e.javaClass.simpleName}: ${e.message}"
            writeStatusFile()
            // Emergency: write a recovery copy so data is not lost entirely
            try {
                val recovery = File(parent, "coffeeroast_recovery_${System.currentTimeMillis()}.json")
                recovery.writeBytes(payload)
                lastStatus += " · recovery=$recovery.name"
            } catch (_: Exception) {
            }
            false
        }
    }

    fun saveOrThrow() {
        if (!save()) {
            throw IllegalStateException(lastStatus)
        }
    }

    private fun writeStatusFile() {
        try {
            if (::filesDir.isInitialized) {
                File(filesDir, STATUS).writeText(
                    "$lastStatus\nbeans=${beans.size}\nroasts=${roasts.size}\n" +
                        "fileExists=${file.exists()}\nfileSize=${if (file.exists()) file.length() else 0}\n" +
                        "time=${System.currentTimeMillis()}\n"
                )
            }
        } catch (_: Exception) {
        }
    }

    private fun toJson(): JSONObject {
        val root = JSONObject()
            .put("schemaVersion", SCHEMA)
            .put("nextBeanId", nb)
            .put("nextRoastId", nr)
            .put("nextGlobalRoastNumber", ng)

        root.put(
            "settings",
            JSONObject()
                .put("temperatureUnit", settings.temperatureUnit)
                .put("weightUnit", settings.weightUnit)
                .put("language", settings.language)
                .put("logIntervalSec", settings.logIntervalSec)
                .put("dryEndTargetC", settings.dryEndTargetC)
                .put("firstCrackTargetC", settings.firstCrackTargetC)
                .put("lowRorWarning", settings.lowRorWarning)
                .put("dropTargetC", settings.dropTargetC)
                .put("theme", settings.theme)
                .put("defaultRestDays", settings.defaultRestDays)
        )

        val ba = JSONArray()
        beans.forEach { b ->
            ba.put(JSONObject().apply {
                put("id", b.id)
                put("name", b.name)
                put("origin", b.origin)
                put("process", b.process)
                put("notes", b.notes)
                put("supplier", b.supplier)
                put("purchaseDate", b.purchaseDate)
                put("price", b.price)
                put("harvestYear", b.harvestYear)
                put("altitudeMasl", b.altitudeMasl ?: JSONObject.NULL)
                put("variety", b.variety)
                put("storageLocation", b.storageLocation)
                put("stockGrams", b.stockGrams)
                put("totalBatches", b.totalBatches)
            })
        }
        root.put("beans", ba)

        val ra = JSONArray()
        roasts.forEach { r -> ra.put(roastJson(r)) }
        root.put("roasts", ra)
        return root
    }

    private fun roastJson(r: RoastSession) = JSONObject().apply {
        put("id", r.id)
        put("globalRoastNumber", r.globalRoastNumber)
        put("beanId", r.beanId)
        put("beanBatchNumber", r.beanBatchNumber)
        put("greenWeightG", r.greenWeightG)
        put("roastedWeightG", r.roastedWeightG ?: JSONObject.NULL)
        put("densityGPerL", r.densityGPerL ?: JSONObject.NULL)
        put("startFan", r.startFan)
        put("startHeater", r.startHeater)
        put("dryEndSec", r.dryEndSec ?: JSONObject.NULL)
        put("turningPointSec", r.turningPointSec ?: JSONObject.NULL)
        put("firstCrackSec", r.firstCrackSec ?: JSONObject.NULL)
        put("secondCrackSec", r.secondCrackSec ?: JSONObject.NULL)
        put("dropSec", r.dropSec ?: JSONObject.NULL)
        put("startTimeMillis", r.startTimeMillis)
        put("startElapsedRealtime", r.startElapsedRealtime)
        put("isComplete", r.isComplete)
        put("isHistorical", r.isHistorical)
        put("stockReserved", r.stockReserved)
        put("targetStyle", r.targetStyle)
        put("roasterName", r.roasterName)
        put("notes", r.notes)
        put("referenceRoastId", r.referenceRoastId ?: JSONObject.NULL)
        put("restingDays", r.restingDays)
        put("roastedRemainingG", r.roastedRemainingG ?: JSONObject.NULL)
        put("tasting", r.tasting?.let { tastingJson(it) } ?: JSONObject.NULL)
        put("fanChanges", changes(r.fanChanges))
        put("heaterChanges", changes(r.heaterChanges))
        put("tempLog", JSONArray().apply {
            r.tempLog.forEach {
                put(
                    JSONObject()
                        .put("elapsedSec", it.elapsedSec)
                        .put("bt", it.bt)
                        .put("et", it.et ?: JSONObject.NULL)
                )
            }
        })
    }

    private fun tastingJson(t: TastingScore) = JSONObject().apply {
        put("fragrance", t.fragrance)
        put("flavor", t.flavor)
        put("aftertaste", t.aftertaste)
        put("acidity", t.acidity)
        put("body", t.body)
        put("balance", t.balance)
        put("sweetness", t.sweetness)
        put("cleanCup", t.cleanCup)
        put("uniformity", t.uniformity)
        put("overall", t.overall)
        put("notes", t.notes)
    }

    private fun changes(x: List<SettingChange>) = JSONArray().apply {
        x.forEach {
            put(
                JSONObject()
                    .put("elapsedSec", it.elapsedSec)
                    .put("btAtChange", it.btAtChange)
                    .put("level", it.level)
            )
        }
    }

    /** Try main, bak, bak2 — return first valid JSONObject or null. */
    private fun tryLoadAnySnapshot(): JSONObject? {
        val candidates = listOf(
            file,
            File(filesDir, BACKUP),
            File(filesDir, BACKUP2)
        ) + filesDir.listFiles { f ->
            f.name.startsWith("coffeeroast_recovery_") && f.name.endsWith(".json")
        }?.sortedByDescending { it.lastModified() }?.toList().orEmpty()

        for (f in candidates) {
            if (!f.exists() || f.length() < 2) continue
            try {
                val root = JSONObject(f.readText())
                val v = root.optInt("schemaVersion", 1)
                if (v > SCHEMA) continue
                // Must have arrays (even empty)
                if (!root.has("beans") && !root.has("roasts")) continue
                return root
            } catch (_: Exception) {
                // quarantine corrupt
                try {
                    val bad = File(filesDir, "${f.name}.corrupt.${System.currentTimeMillis()}")
                    f.renameTo(bad)
                } catch (_: Exception) {
                }
            }
        }
        return null
    }

    @Synchronized
    private fun load() {
        val root = tryLoadAnySnapshot()
        if (root == null) {
            beans = mutableListOf()
            roasts = mutableListOf()
            settings = AppSettings()
            lastStatus = "fresh start (no valid snapshot on disk)"
            writeStatusFile()
            // Create an empty valid file so future loads work
            save()
            return
        }

        try {
            val v = root.optInt("schemaVersion", 1)
            parseRoot(root)
            lastStatus = "loaded schema $v · ${beans.size} beans · ${roasts.size} roasts"
            writeStatusFile()
            // Migrate / rewrite so main file is always current schema
            if (v < SCHEMA || !file.exists()) {
                save()
            }
        } catch (e: Exception) {
            beans = mutableListOf()
            roasts = mutableListOf()
            settings = AppSettings()
            lastStatus = "load parse failed: ${e.message} — starting empty (saves allowed)"
            writeStatusFile()
            save()
        }
    }

    private fun parseRoot(root: JSONObject) {
        val v = root.optInt("schemaVersion", 1)
        if (v > SCHEMA) throw IllegalStateException("Unsupported data schema: $v")

        nb = root.optLong("nextBeanId", 1)
        nr = root.optLong("nextRoastId", 1)
        ng = root.optInt("nextGlobalRoastNumber", 1)

        val s = root.optJSONObject("settings")
        if (s != null) {
            settings = AppSettings(
                s.optString("temperatureUnit", "C"),
                s.optString("weightUnit", "g"),
                s.optString("language", "en"),
                s.optInt("logIntervalSec", 30),
                s.optDouble("dryEndTargetC", 150.0),
                s.optDouble("firstCrackTargetC", 200.0),
                s.optDouble("lowRorWarning", 10.0),
                s.optDouble("dropTargetC", 205.0),
                s.optString("theme", "system"),
                s.optInt("defaultRestDays", 7)
            )
        }

        val loadedBeans = mutableListOf<GreenBean>()
        val ba = root.optJSONArray("beans")
        for (i in 0 until (ba?.length() ?: 0)) {
            val o = ba!!.getJSONObject(i)
            loadedBeans.add(
                GreenBean(
                    o.getLong("id"),
                    o.optString("name"),
                    o.optString("origin"),
                    o.optString("process"),
                    o.optString("notes"),
                    o.optString("supplier"),
                    o.optString("purchaseDate"),
                    o.optDouble("price"),
                    o.optString("harvestYear"),
                    if (o.isNull("altitudeMasl")) null else o.optDouble("altitudeMasl"),
                    o.optString("variety"),
                    o.optString("storageLocation"),
                    o.optDouble("stockGrams"),
                    o.optInt("totalBatches")
                )
            )
        }

        val loadedRoasts = mutableListOf<RoastSession>()
        val ra = root.optJSONArray("roasts")
        for (i in 0 until (ra?.length() ?: 0)) {
            val o = ra!!.getJSONObject(i)
            val r = RoastSession(
                o.getLong("id"),
                o.optInt("globalRoastNumber"),
                o.getLong("beanId"),
                o.optInt("beanBatchNumber"),
                o.optDouble("greenWeightG"),
                if (o.isNull("roastedWeightG")) null else o.optDouble("roastedWeightG"),
                if (o.isNull("densityGPerL")) null else o.optDouble("densityGPerL"),
                o.optInt("startFan"),
                o.optInt("startHeater")
            )
            r.dryEndSec = ni(o, "dryEndSec")
            r.turningPointSec = ni(o, "turningPointSec")
            r.firstCrackSec = ni(o, "firstCrackSec")
            r.secondCrackSec = ni(o, "secondCrackSec")
            r.dropSec = ni(o, "dropSec")
            r.startTimeMillis = o.optLong("startTimeMillis")
            r.startElapsedRealtime = o.optLong("startElapsedRealtime", 0L)
            r.isComplete = o.optBoolean("isComplete")
            r.isHistorical = o.optBoolean("isHistorical")
            r.stockReserved = if (o.has("stockReserved")) o.optBoolean("stockReserved")
            else !r.isComplete && !r.isHistorical
            r.targetStyle = o.optString("targetStyle", "specialty").ifBlank { "specialty" }
            r.roasterName = o.optString("roasterName")
            r.notes = o.optString("notes")
            r.referenceRoastId = nl(o, "referenceRoastId")
            r.restingDays = o.optInt("restingDays", settings.defaultRestDays)
            r.roastedRemainingG =
                if (o.isNull("roastedRemainingG")) null else o.optDouble("roastedRemainingG")
            val t = o.optJSONObject("tasting")
            if (t != null) {
                r.tasting = TastingScore(
                    t.optDouble("fragrance"),
                    t.optDouble("flavor"),
                    t.optDouble("aftertaste"),
                    t.optDouble("acidity"),
                    t.optDouble("body"),
                    t.optDouble("balance"),
                    t.optDouble("sweetness"),
                    t.optDouble("cleanCup"),
                    t.optDouble("uniformity"),
                    t.optDouble("overall"),
                    t.optString("notes")
                )
            }
            loadChanges(o.optJSONArray("fanChanges"), r.fanChanges)
            loadChanges(o.optJSONArray("heaterChanges"), r.heaterChanges)
            val ta = o.optJSONArray("tempLog")
            for (k in 0 until (ta?.length() ?: 0)) {
                val q = ta!!.getJSONObject(k)
                r.tempLog.add(
                    TempPoint(
                        q.optInt("elapsedSec"),
                        q.optDouble("bt"),
                        if (q.isNull("et") || !q.has("et")) null else q.optDouble("et")
                    )
                )
            }
            loadedRoasts.add(r)
        }

        beans = loadedBeans
        roasts = loadedRoasts

        nb = maxOf(nb, (beans.maxOfOrNull { it.id } ?: 0) + 1)
        nr = maxOf(nr, (roasts.maxOfOrNull { it.id } ?: 0) + 1)
        ng = maxOf(ng, (roasts.maxOfOrNull { it.globalRoastNumber } ?: 0) + 1)
        beans.forEach { it.totalBatches = roasts.count { r -> r.beanId == it.id } }
    }

    private fun ni(o: JSONObject, k: String) = if (o.isNull(k)) null else o.optInt(k)
    private fun nl(o: JSONObject, k: String) = if (o.isNull(k)) null else o.optLong(k)

    private fun loadChanges(a: JSONArray?, out: MutableList<SettingChange>) {
        for (i in 0 until (a?.length() ?: 0)) {
            val o = a!!.getJSONObject(i)
            out.add(SettingChange(o.optInt("elapsedSec"), o.optDouble("btAtChange"), o.optInt("level")))
        }
    }

    fun exportBackup(context: Context, out: File) {
        ZipOutputStream(out.outputStream()).use { z ->
            z.putNextEntry(ZipEntry(FILE))
            z.write(toJson().toString().toByteArray(Charsets.UTF_8))
            z.closeEntry()
        }
    }

    fun importBackup(context: Context, src: File) {
        val extracted = File(filesDir, "coffeeroast_import.json")
        try {
            ZipInputStream(src.inputStream()).use { z ->
                var e = z.nextEntry
                while (e != null) {
                    if (e.name == FILE || e.name.endsWith("coffeeroast_data.json")) {
                        extracted.outputStream().use { z.copyTo(it) }
                        break
                    }
                    e = z.nextEntry
                }
            }
            if (!extracted.exists()) throw IllegalArgumentException("Backup data not found in ZIP")
            val candidate = JSONObject(extracted.readText())
            parseRoot(candidate)
            if (!save()) throw IllegalStateException("Import loaded but save failed: $lastStatus")
            extracted.delete()
        } finally {
            extracted.delete()
        }
    }

    fun rawJson() = toJson().toString()

    /** Force a save and return status text for diagnostics. */
    fun forceSaveAndReport(): String {
        val ok = save()
        return if (ok) "OK: $lastStatus" else "FAIL: $lastStatus"
    }
}
