package com.amin1fighter.coffeeroast

import android.content.Context
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import kotlin.math.ceil
import kotlin.math.max

/** Roast chart: clear legend, BT/ET/RoR on main plot, roomy Fan/Heater strip. */
class RoastChartView @JvmOverloads constructor(c: Context, a: AttributeSet? = null) : View(c, a) {
    var session: RoastSession? = null
    var references: List<RoastSession> = emptyList()
    var smoothing: Int = 1
    var pdfTimeLabelStepSec: Int? = null

    private val isDark: Boolean
        get() = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES

    private fun stroke(color: String, width: Float) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = Color.parseColor(color)
        strokeWidth = width
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    private fun fill(color: String) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = Color.parseColor(color)
        style = Paint.Style.FILL
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val s = session ?: return
        val current = clean(s.tempLog)
        val refs = references.map { clean(it.tempLog) }.filter { it.size > 1 }
        if (current.size < 2 && refs.isEmpty()) return

        val btPaint = stroke(if (isDark) "#FFAB91" else "#E64A19", 4.5f)
        val etPaint = stroke(if (isDark) "#BCAAA4" else "#6D4C41", 3f)
        val refPaint = stroke(if (isDark) "#90A4AE" else "#9E9E9E", 2f)
        val gridPaint = stroke(if (isDark) "#424242" else "#E0E0E0", 1f)
        val eventPaint = stroke(if (isDark) "#BDBDBD" else "#616161", 1.5f)
        val fanPaint = stroke(if (isDark) "#64B5F6" else "#1565C0", 3f)
        val heaterPaint = stroke(if (isDark) "#FFB74D" else "#EF6C00", 3f)
        val rorPaint = stroke(if (isDark) "#A5D6A7" else "#2E7D32", 3f)
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (isDark) Color.parseColor("#EEEEEE") else Color.parseColor("#3E2723")
            textSize = 15f
        }
        val legendPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (isDark) Color.parseColor("#FAFAFA") else Color.parseColor("#212121")
            textSize = 16f
            isFakeBoldText = true
        }
        val smallText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (isDark) Color.parseColor("#BDBDBD") else Color.parseColor("#616161")
            textSize = 13f
        }
        val stripBg = fill(if (isDark) "#2C2C2C" else "#F5F5F5")
        val chipBg = fill(if (isDark) "#37474F" else "#ECEFF1")

        // Layout: more top margin for legend, more bottom for Fan/Heater
        val left = 52f
        val right = 52f
        val top = 56f
        val plotBottom = height * 0.62f
        val stripTop = plotBottom + 8f
        val stripH = (height - stripTop - 8f).coerceAtLeast(56f)
        val plotW = width - left - right
        if (plotW <= 0f || plotBottom <= top) return

        val logs = listOf(current) + refs
        val maxElapsed = logs.maxOfOrNull { it.lastOrNull()?.elapsedSec ?: 0 } ?: 0
        val maxTime = ceil(max(30, maxElapsed) / 30.0).toInt() * 30
        val highest = logs.flatMap { it.flatMap { p -> listOfNotNull(p.bt, p.et) } }.maxOrNull() ?: 220.0
        val maxTemp = if (highest <= 220.0) 220.0 else ceil(highest / 20.0) * 20.0

        fun x(sec: Int) = left + (sec.coerceIn(0, maxTime).toFloat() / maxTime) * plotW
        fun yt(v: Double): Float =
            plotBottom - (v.coerceIn(0.0, maxTemp) / maxTemp).toFloat() * (plotBottom - top)

        // Temperature grid
        var t = 0.0
        while (t <= maxTemp + 0.1) {
            c.drawLine(left, yt(t), left + plotW, yt(t), gridPaint)
            c.drawText("${t.toInt()}°", 4f, yt(t) + 5f, smallText)
            t += 20.0
        }

        // Legend row 1 — spaced chips so they never overlap
        var lx = left
        fun legendChip(label: String, colorPaint: Paint) {
            val tw = legendPaint.measureText(label)
            c.drawRoundRect(RectF(lx, 8f, lx + tw + 28f, 32f), 8f, 8f, chipBg)
            val sw = colorPaint.strokeWidth
            c.drawLine(lx + 8f, 20f, lx + 18f, 20f, colorPaint)
            colorPaint.strokeWidth = sw
            c.drawText(label, lx + 22f, 26f, legendPaint)
            lx += tw + 40f
        }
        legendChip("BT", btPaint)
        legendChip("ET", etPaint)
        if (refs.isNotEmpty()) legendChip("REF", refPaint)
        legendChip("RoR", rorPaint)

        refs.forEach { drawBt(c, it, ::x, ::yt, refPaint) }
        drawBt(c, current, ::x, ::yt, btPaint)
        drawEt(c, current, ::x, ::yt, etPaint)

        // RoR on same plot, right axis
        val rr = RoastMath.rorSeries(current, 60)
        if (rr.size >= 2) {
            val rrMax = maxOf(20.0, ceil((rr.maxOf { it.second }.coerceAtLeast(0.0) + 2.0) / 5.0) * 5.0)
            val rrMin = minOf(-5.0, kotlin.math.floor((rr.minOf { it.second }) / 5.0) * 5.0)
            fun yr(v: Double): Float =
                plotBottom - ((v - rrMin) / (rrMax - rrMin)).coerceIn(0.0, 1.0).toFloat() * (plotBottom - top)
            c.drawText("${rrMax.toInt()}", left + plotW + 4f, yt(maxTemp) + 5f, smallText)
            c.drawText("0", left + plotW + 4f, yr(0.0) + 5f, smallText)
            c.drawText("${rrMin.toInt()}", left + plotW + 4f, plotBottom + 5f, smallText)
            c.drawLine(left, yr(0.0), left + plotW, yr(0.0), gridPaint)
            for (i in 1 until rr.size) {
                c.drawLine(
                    x(rr[i - 1].first), yr(rr[i - 1].second),
                    x(rr[i].first), yr(rr[i].second), rorPaint
                )
            }
        }

        fun marker(sec: Int?, label: String) {
            if (sec == null || sec !in 0..maxTime) return
            c.drawLine(x(sec), top, x(sec), plotBottom, eventPaint)
            val labelText = "$label ${fmt(sec)}"
            val tw = smallText.measureText(labelText)
            val tx = (x(sec) + 4f).coerceAtMost(left + plotW - tw)
            c.drawText(labelText, tx, top + 14f, smallText)
        }
        marker(s.turningPointSec, "TP")
        marker(s.dryEndSec, "DE")
        marker(s.firstCrackSec, "FC")
        marker(s.secondCrackSec, "SC")
        marker(s.dropSec, "DROP")

        // Time axis
        val labelStep = pdfTimeLabelStepSec?.coerceAtLeast(30) ?: 30
        var sec = 0
        while (sec <= maxTime) {
            c.drawLine(x(sec), top, x(sec), plotBottom, gridPaint)
            if (sec % labelStep == 0) {
                val label = fmt(sec)
                val tw = smallText.measureText(label)
                c.drawText(label, x(sec) - tw / 2f, plotBottom + 16f, smallText)
            }
            sec += 30
        }

        // Fan / Heater strip — full width band
        c.drawRoundRect(RectF(left, stripTop, left + plotW, stripTop + stripH), 10f, 10f, stripBg)
        val midY = stripTop + stripH / 2f
        c.drawLine(left, midY, left + plotW, midY, gridPaint)

        c.drawText("FAN", 6f, stripTop + stripH * 0.32f, fanPaint.apply { style = Paint.Style.FILL; textSize = 13f })
        fanPaint.style = Paint.Style.STROKE
        fanPaint.textSize = 12f
        c.drawText("HEAT", 6f, stripTop + stripH * 0.78f, heaterPaint.apply { style = Paint.Style.FILL; textSize = 13f })
        heaterPaint.style = Paint.Style.STROKE
        heaterPaint.textSize = 12f

        val fanY = stripTop + stripH * 0.28f
        val heatY = stripTop + stripH * 0.72f
        s.fanChanges.sortedBy { it.elapsedSec }.forEach { q ->
            val xx = x(q.elapsedSec)
            c.drawLine(xx, stripTop + 4f, xx, midY - 2f, fanPaint)
            val label = "F${q.level}"
            c.drawText(label, xx + 3f, fanY + 4f, smallText)
        }
        s.heaterChanges.sortedBy { it.elapsedSec }.forEach { q ->
            val xx = x(q.elapsedSec)
            c.drawLine(xx, midY + 2f, xx, stripTop + stripH - 4f, heaterPaint)
            val label = "H${q.level}"
            c.drawText(label, xx + 3f, heatY + 4f, smallText)
        }
    }

    private fun clean(source: List<TempPoint>): List<TempPoint> {
        val sorted = source.sortedBy { it.elapsedSec }
        val filtered = sorted.filter {
            it.elapsedSec >= 0 && it.bt.isFinite() && it.bt in 0.0..300.0 &&
                (it.et == null || (it.et!!.isFinite() && it.et!! in 0.0..300.0))
        }
        return if (smoothing > 1) RoastMath.smooth(filtered, smoothing) else filtered
    }

    private fun drawBt(
        c: Canvas, log: List<TempPoint>,
        x: (Int) -> Float, y: (Double) -> Float, p: Paint
    ) {
        for (i in 1 until log.size) {
            c.drawLine(x(log[i - 1].elapsedSec), y(log[i - 1].bt), x(log[i].elapsedSec), y(log[i].bt), p)
        }
    }

    private fun drawEt(
        c: Canvas, log: List<TempPoint>,
        x: (Int) -> Float, y: (Double) -> Float, etPaint: Paint
    ) {
        for (i in 1 until log.size) {
            val a = log[i - 1].et
            val b = log[i].et
            if (a != null && b != null) {
                c.drawLine(x(log[i - 1].elapsedSec), y(a), x(log[i].elapsedSec), y(b), etPaint)
            }
        }
    }

    private fun fmt(sec: Int) = "${sec / 60}:${(sec % 60).toString().padStart(2, '0')}"
}
