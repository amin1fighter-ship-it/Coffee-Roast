# Coffee Roast Lab 0.4.16

## Critical fix: data persistence

Previous builds could set an internal `writeBlocked` flag after a failed load. After that, every `save()` became a silent no-op — beans and roasts only lived in RAM and vanished on full app exit.

### 0.4.16
- Removed permanent write-block.
- Saves always attempt disk write, verify file size + JSON parse.
- Backup rotation: `.json` → `.bak` → `.bak2` + recovery files on failure.
- Loads from main / bak / bak2 / recovery snapshots.
- UI shows storage status on home screen.
- "Force save + show storage status" on Backup screen.
- Toast on any failed save.

Version `0.4.16` / versionCode `41600`.
