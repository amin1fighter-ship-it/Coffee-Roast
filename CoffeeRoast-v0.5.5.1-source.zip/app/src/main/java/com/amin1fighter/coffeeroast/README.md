# Coffee Roast Lab v0.5.3

Local-first Android roast logging and analysis app.

## Integrated changes from v0.5.1
- Brew Intent is explicit: Filter / Espresso / Omni / Other. It is never inferred from DTR, Drop BT, or weight loss.
- Historical imports use `Not recorded` intent rather than silently becoming Filter.
- Roast Degree, Development, Brew Intent and Cupping are separate analytical layers.
- Weight loss is reported as an analytical indication against configurable working reference bands, not as a universal roast-color classifier.
- RoR is treated as temperature slope; Heater/Fan are control inputs, not direct energy measurements.
- Control-response analysis compares RoR before/after Fan or Heater events when sufficient data exists.
- Development analysis reports time, DTR, post-FC RoR pattern and end RoR without making a cup-quality verdict.
- ET coverage is reported so BT-only roasts remain valid while exposing the missing diagnostic signal.
- Bulk density is kept separate from particle/true density; bulk density is never used to claim bean volume expansion.
- Density measurement age is retained and the UI recommends a standardized ~24 h personal protocol; exact ISO compliance is not claimed.
- v0.5.0 starting Fan/Heater states are migrated into 0:00 timeline events when needed.
- Live chart architecture remains unchanged; control rows stay below the time axis.
- PDF/dashboard exports include Brew Intent and analytical development fields.
- Legacy roast import remains backward compatible.

## Storage safety
Schema 9 remains backward compatible. Saves use validated temporary JSON, backup/recovery copies and atomic/fallback replacement. Existing data is never intentionally replaced by an empty database after a load failure.

## Build
CI uses Gradle 8.9 + JDK 17. Release signing is supplied through GitHub Actions secrets. Version `0.5.3` / versionCode `50300`.

## v0.5.4
- Added post-roast editing for core roast metadata (green/roasted weights, initial fan/heater, notes).
- Added roast-event manager for TP, Dry End, FC, SC and Drop, including edit/remove actions.
- Existing event buttons now offer edit/remove when the event is already recorded, reducing accidental event lockout.
- Event-time edits validate timeline order before committing.
- Added no new schema fields; existing saved-roast format is retained.
