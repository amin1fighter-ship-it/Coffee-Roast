# Coffee Roast Lab v0.6.0

A local-first Android roast logging and analysis app for specialty coffee.

## Analytical model
- **Brew Intent:** Filter / Espresso / Omni / Other; user-selected and never inferred from roast data.
- **Roast Degree:** analyzed separately using weight-loss indication and, when available, roast-color measurement.
- **Development:** analyzed from FC→Drop time, DTR, post-FC RoR and thermal behavior; DTR alone is not a quality verdict.
- **Thermal controls:** Heater/Fan are recorded as control actions. RoR is a temperature slope, not direct energy.
- **Density:** green/roasted density, retention/reduction and true-density expansion when the method supports it. Bulk density is not treated as true bean-volume expansion.
- **Brew performance/Cupping:** kept separate from roast-curve inference.

## Data safety
Storage is local-first and schema 9. Existing v0.5.0/v0.5.1 data remains readable, with migration for old `specialty` intent and missing initial control events.

## Exports
Artisan-compatible TSV, CSV, dashboard CSV, PDF and JSON backup are supported.

## Build
Gradle 8.9 + JDK 17. Version `0.6.0` / versionCode `60000`.

## v0.5.5 fixes
- All AlertDialogs use a dedicated fixed dark roast theme, independent of the phone's light/dark mode.
- Cupping/tasting fields are inside a scrollable form so the Save/Cancel buttons remain reachable.
- Editing/removing roast events persists changes and rebuilds the relevant screen, chart, and derived calculations.
- Editing initial fan/heater values also updates the corresponding 0:00 chart events.
- Android system Back now navigates to the parent app screen; during a live roast it returns home without stopping the roast.


## v0.6.0 changes
- Added four primary-screen color palettes: Dark Roast, Light Lab, Forest, and Ember. Palette selection is stored in app settings.
- Added post-roast fan/heater event management: add, edit, delete, time/level validation, and chronological sorting. Completed roast summary includes access to control history.
- Added a locally saved Roast Plan editor and applying time-based fan/heater actions to the open roast. `mm:ss fan 12` / `mm:ss heater 10` rows are applied; BT-based rows are retained as reference text only and are not auto-triggered. This app does not control roaster hardware.
- Existing roast database schema is unchanged; roast plans are stored separately in app preferences.
