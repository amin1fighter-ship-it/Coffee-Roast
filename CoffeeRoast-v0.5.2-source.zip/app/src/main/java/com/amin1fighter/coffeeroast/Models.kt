package com.amin1fighter.coffeeroast

data class GreenBean(
    val id: Long,
    var name: String,
    var origin: String = "",
    var process: String = "",
    var notes: String = "",
    var supplier: String = "",
    var purchaseDate: String = "",
    var price: Double = 0.0,
    var harvestYear: String = "",
    var altitudeMasl: Double? = null,
    var variety: String = "",
    var storageLocation: String = "",
    var stockGrams: Double = 0.0,
    var totalBatches: Int = 0
)

data class TempPoint(val elapsedSec: Int, val bt: Double, val et: Double? = null)

data class SettingChange(val elapsedSec: Int, val btAtChange: Double, val level: Int)

data class TastingScore(
    var fragrance: Double = 0.0,
    var flavor: Double = 0.0,
    var aftertaste: Double = 0.0,
    var acidity: Double = 0.0,
    var body: Double = 0.0,
    var balance: Double = 0.0,
    var sweetness: Double = 0.0,
    var cleanCup: Double = 0.0,
    var uniformity: Double = 0.0,
    var overall: Double = 0.0,
    var notes: String = ""
) {
    fun total() =
        fragrance + flavor + aftertaste + acidity + body + balance + sweetness + cleanCup + uniformity + overall
}

data class RoastSession(
    val id: Long,
    var globalRoastNumber: Int,
    val beanId: Long,
    var beanBatchNumber: Int,
    var greenWeightG: Double,
    var roastedWeightG: Double? = null,
    /** Green-bean density measured before roasting (g/L). */
    var densityGPerL: Double? = null,
    /** Post-roast density measured after cooling/resting (g/L). */
    var roastedDensityGPerL: Double? = null,
    /** Density method: bulk or particle/true. */
    var densityType: String = "bulk",
    /** Wall-clock timestamp of the post-roast density measurement. */
    var densityMeasuredAtMillis: Long? = null,
    /** User-selected roast level used for weight-loss reference analysis. */
    var roastLevel: String = "medium",
    var startFan: Int = 0,
    var startHeater: Int = 0,
    val fanChanges: MutableList<SettingChange> = mutableListOf(),
    val heaterChanges: MutableList<SettingChange> = mutableListOf(),
    val tempLog: MutableList<TempPoint> = mutableListOf(),
    var dryEndSec: Int? = null,
    var turningPointSec: Int? = null,
    var firstCrackSec: Int? = null,
    var secondCrackSec: Int? = null,
    var dropSec: Int? = null,
    /** Wall-clock start for display/date only. */
    var startTimeMillis: Long = 0L,
    /** Monotonic base for live elapsed (SystemClock.elapsedRealtime at charge). */
    var startElapsedRealtime: Long = 0L,
    var isComplete: Boolean = false,
    var isHistorical: Boolean = false,
    /** True after green stock was reserved at roast start. */
    var stockReserved: Boolean = false,
    var roasterName: String = "",
    var notes: String = "",
    var referenceRoastId: Long? = null,
    var tasting: TastingScore? = null,
    var restingDays: Int = 0,
    var roastedRemainingG: Double? = null,
    /** Brew intent selected before roasting: filter | espresso | omni | other.
     * Historical imports may use not_recorded; it is never inferred from roast data. */
    var targetStyle: String = "filter"
)

data class AppSettings(
    var temperatureUnit: String = "C",
    var weightUnit: String = "g",
    var language: String = "en",
    var logIntervalSec: Int = 30,
    var dryEndTargetC: Double = 150.0,
    var firstCrackTargetC: Double = 200.0,
    var lowRorWarning: Double = 10.0,
    var dropTargetC: Double = 205.0,
    var theme: String = "system",
    var defaultRestDays: Int = 7
)
