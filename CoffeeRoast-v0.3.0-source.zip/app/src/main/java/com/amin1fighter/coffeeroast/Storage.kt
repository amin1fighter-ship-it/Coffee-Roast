package com.amin1fighter.coffeeroast

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Very small local persistence layer: everything is kept in memory and
 * mirrored to a single JSON file in the app's private storage. No network,
 * no database dependency - fine for a single-user roast log.
 */
object Storage {
    private const val FILE_NAME = "coffeeroast_data.json"

    var beans: MutableList<GreenBean> = mutableListOf()
    var roasts: MutableList<RoastSession> = mutableListOf()
    private var nextBeanId: Long = 1
    private var nextRoastId: Long = 1
    private var nextGlobalRoastNumber: Int = 1

    private lateinit var dataFile: File
    private var loaded = false

    fun init(context: Context) {
        if (loaded) return
        dataFile = File(context.filesDir, FILE_NAME)
        load()
        loaded = true
    }

    fun newBeanId(): Long = nextBeanId++
    fun newRoastId(): Long = nextRoastId++
    fun newGlobalRoastNumber(): Int = nextGlobalRoastNumber++

    fun addBean(bean: GreenBean) {
        beans.add(bean)
        save()
    }

    fun addRoast(roast: RoastSession) {
        roasts.add(roast)
        save()
    }

    fun beanById(id: Long): GreenBean? = beans.firstOrNull { it.id == id }

    fun save() {
        val root = JSONObject()
        root.put("nextBeanId", nextBeanId)
        root.put("nextRoastId", nextRoastId)
        root.put("nextGlobalRoastNumber", nextGlobalRoastNumber)

        val beansArr = JSONArray()
        for (b in beans) {
            val o = JSONObject()
            o.put("id", b.id)
            o.put("name", b.name)
            o.put("origin", b.origin)
            o.put("process", b.process)
            o.put("notes", b.notes)
            o.put("stockGrams", b.stockGrams)
            o.put("totalBatches", b.totalBatches)
            beansArr.put(o)
        }
        root.put("beans", beansArr)

        val roastsArr = JSONArray()
        for (r in roasts) {
            val o = JSONObject()
            o.put("id", r.id)
            o.put("globalRoastNumber", r.globalRoastNumber)
            o.put("beanId", r.beanId)
            o.put("beanBatchNumber", r.beanBatchNumber)
            o.put("greenWeightG", r.greenWeightG)
            o.put("roastedWeightG", r.roastedWeightG ?: JSONObject.NULL)
            o.put("densityGPerL", r.densityGPerL ?: JSONObject.NULL)
            o.put("startFan", r.startFan)
            o.put("startHeater", r.startHeater)
            o.put("dryEndSec", r.dryEndSec ?: JSONObject.NULL)
            o.put("firstCrackSec", r.firstCrackSec ?: JSONObject.NULL)
            o.put("dropSec", r.dropSec ?: JSONObject.NULL)
            o.put("startTimeMillis", r.startTimeMillis)
            o.put("isComplete", r.isComplete)
            o.put("isHistorical", r.isHistorical)

            val fanArr = JSONArray()
            for (c in r.fanChanges) {
                val co = JSONObject()
                co.put("elapsedSec", c.elapsedSec)
                co.put("btAtChange", c.btAtChange)
                co.put("level", c.level)
                fanArr.put(co)
            }
            o.put("fanChanges", fanArr)

            val heaterArr = JSONArray()
            for (c in r.heaterChanges) {
                val co = JSONObject()
                co.put("elapsedSec", c.elapsedSec)
                co.put("btAtChange", c.btAtChange)
                co.put("level", c.level)
                heaterArr.put(co)
            }
            o.put("heaterChanges", heaterArr)

            val tempArr = JSONArray()
            for (t in r.tempLog) {
                val to = JSONObject()
                to.put("elapsedSec", t.elapsedSec)
                to.put("bt", t.bt)
                if (t.et == null) to.put("et", JSONObject.NULL) else to.put("et", t.et)
                tempArr.put(to)
            }
            o.put("tempLog", tempArr)

            roastsArr.put(o)
        }
        root.put("roasts", roastsArr)

        dataFile.writeText(root.toString())
    }

    private fun load() {
        beans = mutableListOf()
        roasts = mutableListOf()
        if (!dataFile.exists()) return
        try {
            val root = JSONObject(dataFile.readText())
            nextBeanId = root.optLong("nextBeanId", 1)
            nextRoastId = root.optLong("nextRoastId", 1)
            nextGlobalRoastNumber = root.optInt("nextGlobalRoastNumber", 1)

            val beansArr = root.optJSONArray("beans")
            if (beansArr != null) {
                for (i in 0 until beansArr.length()) {
                    val o = beansArr.getJSONObject(i)
                    beans.add(
                        GreenBean(
                            id = o.getLong("id"),
                            name = o.optString("name", ""),
                            origin = o.optString("origin", ""),
                            process = o.optString("process", ""),
                            notes = o.optString("notes", ""),
                            stockGrams = o.optDouble("stockGrams", 0.0),
                            totalBatches = o.optInt("totalBatches", 0)
                        )
                    )
                }
            }

            val roastsArr = root.optJSONArray("roasts")
            if (roastsArr != null) {
                for (i in 0 until roastsArr.length()) {
                    val o = roastsArr.getJSONObject(i)
                    val session = RoastSession(
                        id = o.getLong("id"),
                        globalRoastNumber = o.optInt("globalRoastNumber", 0),
                        beanId = o.getLong("beanId"),
                        beanBatchNumber = o.optInt("beanBatchNumber", 0),
                        greenWeightG = o.optDouble("greenWeightG", 0.0),
                        roastedWeightG = if (o.isNull("roastedWeightG")) null else o.optDouble("roastedWeightG"),
                        densityGPerL = if (o.isNull("densityGPerL")) null else o.optDouble("densityGPerL"),
                        startFan = o.optInt("startFan", 0),
                        startHeater = o.optInt("startHeater", 0)
                    )
                    session.dryEndSec = if (o.isNull("dryEndSec")) null else o.optInt("dryEndSec")
                    session.firstCrackSec = if (o.isNull("firstCrackSec")) null else o.optInt("firstCrackSec")
                    session.dropSec = if (o.isNull("dropSec")) null else o.optInt("dropSec")
                    session.startTimeMillis = o.optLong("startTimeMillis", 0L)
                    session.isComplete = o.optBoolean("isComplete", false)
                    session.isHistorical = o.optBoolean("isHistorical", false)

                    val fanArr = o.optJSONArray("fanChanges")
                    if (fanArr != null) {
                        for (j in 0 until fanArr.length()) {
                            val co = fanArr.getJSONObject(j)
                            session.fanChanges.add(
                                SettingChange(co.getInt("elapsedSec"), co.optDouble("btAtChange", 0.0), co.getInt("level"))
                            )
                        }
                    }
                    val heaterArr = o.optJSONArray("heaterChanges")
                    if (heaterArr != null) {
                        for (j in 0 until heaterArr.length()) {
                            val co = heaterArr.getJSONObject(j)
                            session.heaterChanges.add(
                                SettingChange(co.getInt("elapsedSec"), co.optDouble("btAtChange", 0.0), co.getInt("level"))
                            )
                        }
                    }
                    val tempArr = o.optJSONArray("tempLog")
                    if (tempArr != null) {
                        for (j in 0 until tempArr.length()) {
                            val to = tempArr.getJSONObject(j)
                            session.tempLog.add(
                                run {
                                val et = if (to.isNull("et") || !to.has("et")) null else to.optDouble("et")
                                TempPoint(to.getInt("elapsedSec"), to.optDouble("bt", 0.0), if (et != null && et > 0.0) et else null)
                            }
                            )
                        }
                    }
                    roasts.add(session)
                }
            }
        } catch (e: Exception) {
            // Corrupt data file: start fresh instead of crashing the app.
            beans = mutableListOf()
            roasts = mutableListOf()
        }
    }
}
