package com.amin1fighter.coffeeroast

import kotlin.math.roundToInt

object RoastMath {

    // Reference thresholds used only for the live "estimated time to phase"
    // projection. These are generic defaults (roughly what shows up in most
    // fluid-bed logs, dry end ~150C, first crack ~200C) - not a claim about
    // your specific roaster or bean.
    const val DEFAULT_DRY_END_TARGET_C = 150.0
    const val DEFAULT_FIRST_CRACK_TARGET_C = 200.0

    /**
     * Rate of rise of BT, in degrees per minute, using the trailing point
     * closest to (now - windowSec) as the reference - the same idea Artisan
     * uses for its projected/instant RoR.
     */
    fun currentRor(tempLog: List<TempPoint>, windowSec: Int = 60): Double? {
        if (tempLog.size < 2) return null
        val last = tempLog.last()
        val targetSec = last.elapsedSec - windowSec

        var best: TempPoint? = null
        var bestDiff = Int.MAX_VALUE
        for (p in tempLog) {
            if (p.elapsedSec >= last.elapsedSec) continue
            val diff = kotlin.math.abs(p.elapsedSec - targetSec)
            if (diff < bestDiff) {
                bestDiff = diff
                best = p
            }
        }
        val ref = best ?: tempLog[tempLog.size - 2]
        val dtSec = last.elapsedSec - ref.elapsedSec
        if (dtSec <= 0) return null
        val dBt = last.bt - ref.bt
        return dBt * 60.0 / dtSec
    }

    /**
     * Simple linear projection: "if BT keeps rising at the current RoR,
     * when would it cross targetC?" Returns absolute elapsed seconds, or
     * null if we can't project (no RoR yet, or already past the target).
     */
    fun etaToTempSec(currentElapsedSec: Int, currentBt: Double, rorPerMin: Double?, targetC: Double): Int? {
        if (rorPerMin == null || rorPerMin <= 0.01) return null
        if (currentBt >= targetC) return null
        val minutesNeeded = (targetC - currentBt) / rorPerMin
        return currentElapsedSec + (minutesNeeded * 60.0).roundToInt()
    }

    fun weightLossPercent(greenG: Double, roastedG: Double): Double? {
        if (greenG <= 0.0) return null
        return (greenG - roastedG) / greenG * 100.0
    }

    data class PhasePercents(
        val dryingPercent: Double?,
        val maillardPercent: Double?,
        val developmentPercent: Double?
    )

    /**
     * Percentage breakdown of the roast timeline.
     * - dryingPercent: start -> dry end (only if dryEndSec was marked)
     * - maillardPercent: dry end (or start) -> first crack
     * - developmentPercent: first crack -> drop (the "development time ratio")
     */
    fun phasePercents(startSec: Int, dryEndSec: Int?, firstCrackSec: Int?, dropSec: Int?): PhasePercents {
        if (dropSec == null || dropSec <= startSec) {
            return PhasePercents(null, null, null)
        }
        val total = (dropSec - startSec).toDouble()

        var drying: Double? = null
        var maillard: Double? = null
        var development: Double? = null

        if (firstCrackSec != null) {
            development = (dropSec - firstCrackSec) / total * 100.0
            if (dryEndSec != null) {
                drying = (dryEndSec - startSec) / total * 100.0
                maillard = (firstCrackSec - dryEndSec) / total * 100.0
            } else {
                maillard = (firstCrackSec - startSec) / total * 100.0
            }
        }
        return PhasePercents(drying, maillard, development)
    }

    /**
     * Rule-of-thumb suggested drop range, NOT a validated formula. General
     * roasting guidance: denser green beans absorb/transfer heat efficiently
     * and tolerate a hotter, faster roast; lower-density beans scorch or tip
     * more easily and are usually pulled a bit cooler. Naturals are commonly
     * dropped a touch earlier/cooler than washed coffees at the same density.
     * Always cross-check against cup results for your own roaster.
     */
    fun suggestedDropRangeC(densityGPerL: Double, process: String): Pair<Double, Double> {
        var low: Double
        var high: Double
        when {
            densityGPerL >= 720.0 -> {
                low = 200.0; high = 206.0
            }
            densityGPerL >= 680.0 -> {
                low = 196.0; high = 202.0
            }
            else -> {
                low = 190.0; high = 197.0
            }
        }
        val p = process.lowercase()
        if (p.contains("natural")) {
            low -= 3.0; high -= 3.0
        } else if (p.contains("honey")) {
            low -= 1.5; high -= 1.5
        }
        return low to high
    }
}
