package com.amin1fighter.coffeeroast
import kotlin.math.abs
import kotlin.math.roundToInt
object RoastMath {
 const val DEFAULT_DRY_END_TARGET_C=150.0; const val DEFAULT_FIRST_CRACK_TARGET_C=200.0
 fun currentRor(log:List<TempPoint>,windowSec:Int=60):Double?{
  if(log.size<2)return null; val a=log.sortedBy{it.elapsedSec}; val last=a.last()
  val target=last.elapsedSec-windowSec; val ref=a.filter{it.elapsedSec<last.elapsedSec}.minByOrNull{abs(it.elapsedSec-target)}?:a[a.size-2]
  val dt=last.elapsedSec-ref.elapsedSec; if(dt<=0)return null
  if(windowSec>0 && abs(ref.elapsedSec-target)>windowSec*0.75 && a.last().elapsedSec-a.first().elapsedSec>windowSec*2)return null
  return (last.bt-ref.bt)*60.0/dt
 }
 fun rorSeries(log:List<TempPoint>,windowSec:Int=60)=log.sortedBy{it.elapsedSec}.mapNotNull{p->
  val r=currentRor(log.takeWhile{it.elapsedSec<=p.elapsedSec},windowSec); if(r==null)null else p.elapsedSec to r}
 fun deltaRor(log:List<TempPoint>,windowSec:Int=60):List<Pair<Int,Double>>{
  val rr=rorSeries(log,windowSec); return rr.mapIndexedNotNull{i,p->if(i==0)null else p.first to (p.second-rr[i-1].second)*60.0/(p.first-rr[i-1].first).coerceAtLeast(1)}
 }
 fun smooth(log:List<TempPoint>,window:Int)=if(window<=1)log else log.sortedBy{it.elapsedSec}.mapIndexed{ i,p->
  val a=maxOf(0,i-window+1); val xs=log.sortedBy{it.elapsedSec}.subList(a,i+1)
  TempPoint(p.elapsedSec,xs.map{it.bt}.average(),xs.mapNotNull{it.et}.takeIf{it.isNotEmpty()}?.average())
 }
 fun weightLossPercent(g:Double,r:Double)=if(g<=0)null else (g-r)/g*100
 fun dtr(start:Int,fc:Int?,drop:Int?)=if(fc!=null&&drop!=null&&drop>start)(drop-fc).toDouble()/(drop-start)*100 else null
 fun phasePercents(start:Int,de:Int?,fc:Int?,drop:Int?):Triple<Double?,Double?,Double?>{
  if(drop==null||drop<=start)return Triple(null,null,null); val total=(drop-start).toDouble()
  val dry=de?.let{(it-start)/total*100}; val dev=dtr(start,fc,drop); val mail=if(fc!=null)(fc-(de?:start))/total*100 else null
  return Triple(dry,mail,dev)
 }
 fun etaToTempSec(now:Int,bt:Double,ror:Double?,target:Double)=if(ror==null||ror<=.01||bt>=target)null else now+((target-bt)/ror*60).roundToInt()
 fun suggestedDropRangeC(d:Double,p:String):Pair<Double,Double>{var l=when{d>=720->200.0;d>=680->196.0;else->190.0};var h=when{d>=720->206.0;d>=680->202.0;else->197.0};if(p.lowercase().contains("natural")){l-=3;h-=3};if(p.lowercase().contains("honey")){l-=1.5;h-=1.5};return l to h}
 fun parseTime(s:String):Int?{val t=s.trim();if(t.isEmpty())return null;if(!t.contains(":"))return t.toIntOrNull();val p=t.split(":");if(p.size!=2)return null;val m=p[0].toIntOrNull()?:return null;val sec=p[1].toIntOrNull()?:return null;if(m<0||sec !in 0..59)return null;return m*60+sec}
}
